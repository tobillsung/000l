package sound;

import org.junit.Test;

public class TestSoundDrive extends Thread{

	@Test
	public void testPlaySound() {
		
		SoundDrive mySD = new SoundDrive();
		
		String[] mySoundFiles = new String[] {
				"sounddrive/execution/Cash.wav",
				"sounddrive/strategy/ST_LaunchStrategy.wav",
				"sounddrive/execution/Yes_LetsBurn.wav"};
		
		mySD.setAudioFile(mySoundFiles);
		mySoundTh = new Thread(mySD);
		
		mySoundTh.start();
		
		this.start();

		while (mySoundTh.isAlive()) {
			
		}
	}
	
	public void run() {
	}
	
	Thread mySoundTh;
}

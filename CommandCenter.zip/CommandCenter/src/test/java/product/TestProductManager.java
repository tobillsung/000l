package product;

import junit.framework.Assert;

import org.junit.Test;

import com.ib.client.Contract;
import com.ib.contracts.FutContract;
import com.ib.contracts.StkContract;

public class TestProductManager {
	
	@Test
	public void testViewContract() {
		ProductManager myProduct = new ProductManager("localhost", 7496, 1);
		FutContract myF = new FutContract("ES", "201403", "USD");
		myF.m_exchange = "GLOBEX";
		
		StkContract myS = new StkContract("IBM_WrongId");
		StkContract myS2 = new StkContract("AAPL");
		
		myProduct.viewContract(new Contract[] {myF, myS, myS2}, false);
	}
	
	@Test
	public void testInsertContract() {
		ProductManager myProduct = new ProductManager("localhost", 7496, 2);
		FutContract myF = new FutContract("ES", "201412", "USD");
		myF.m_exchange = "GLOBEX";
		
		FutContract myF2 = new FutContract("NQ", "201412", "USD");
		myF.m_exchange = "GLOBEX";
		
		StkContract myS = new StkContract("IBM");
		StkContract myS2 = new StkContract("AAPL");
		StkContract myS3 = new StkContract("GLD");
		StkContract myS4 = new StkContract("GDX");
		StkContract myS5 = new StkContract("IAU");
		StkContract myS6 = new StkContract("PSAU");
		StkContract myS7 = new StkContract("RING");
		StkContract myS8 = new StkContract("QQQ");
		StkContract myS9 = new StkContract("SPY");
		StkContract myS10 = new StkContract("IWM");
		
		
		myProduct.viewContract(new Contract[] {
				myF, myF2, myS, myS2, myS3, myS4, myS5, myS6, myS7, myS8, myS9, myS10}, true);
	}
	
	@Test
	public void testGetContractBySymbol() {
		try {
			ProductManager myProduct = new ProductManager("localhost", 7496, 3);
			Contract myContract = ProductManager.getContractBySymbol("ESH4.FUT.GLOBEX.USD");
			myProduct.viewContract(myContract, false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testSymbolByTicker() throws Exception{
		
		String mySymbol = ProductManager.getSymbolByTicker("ESM4");
		Assert.assertEquals(mySymbol, "ESM4.FUT.GLOBEX.USD");		
	}
	
	@Test
	public void testSymbolByContract() {
		
		FutContract myF = new FutContract("ES", "201403", "USD");
		myF.m_localSymbol = "ESH4";
		myF.m_exchange = "GLOBEX";
		String mySymbol = ProductManager.getSymbolByContract(myF);
		Assert.assertEquals(mySymbol, "ESH4.FUT.GLOBEX.USD");
	}
	
	@Test
	public void testGetContractByTicker() {
		try {
			ProductManager myProduct = new ProductManager("localhost", 7496, 4);
			Contract myContract = ProductManager.getContractByTicker("ESM4");
			myProduct.viewContract(myContract, false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
}

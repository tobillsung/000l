package product;

import org.junit.Test;

public class TestFeeManager {
	
	@Test
	public void testFutTotFee() {
		System.out.println(FeeManager.getFeeStructure("ESM4").getTotFee());
	}
	
	@Test
	public void testStkTotFee() {
		System.out.println(FeeManager.getFeeStructure("GLD").getTotFee());
	}

	@Test
	public void testTotPortfolioFee() {
		System.out.println(FeeManager.getTotFeeForPortfolioTrade(new String[] {"ESM4", "ESU4"}, new double[] {2, -2}));
	}
}

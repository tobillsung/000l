package order;

import order.OrderHandler.Status;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;

import product.ProductManager;

import com.ib.client.Contract;

public class TestOrderHandler extends Thread {
	
	@Test
	public void testOrderHandler() throws Exception{
		
		theOrderHandler = new OrderHandler();
		theOrderHandler.theLogger.setLevel(Level.DEBUG);
		theOrderHandler.init();
		
		Contract myContract = ProductManager.getContractByTicker("GDX");
		theOrderId = theOrderHandler.generateOrderId();
		theOrderHandler.placeOrder(theOrderId, "Test_Strategy", 
				myContract, new DummyOrder(), theOrderListener);
		this.start();
		theOrderHandler.run();
	}
	
	public class OrderListenerOne implements OrderListener {

		@Override
		public void newOrderManager(OrderManager aOrderManager) {
			// TODO Auto-generated method stub
			
		}
	}
	
	public void run() {
		synchronized (this) {
			try {
				this.wait(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		synchronized (theOrderHandler) {
			
			// After 2 sec, add another order
	
			theLogger.info("Main Thread: 2 Second passed. Cancelling the order");
			theOrderHandler.cancelOrder(theOrderId, theOrderListener);
		}

		// After 2 sec, close connection
		synchronized (this) {
			try {
				this.wait(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		synchronized (theOrderHandler) {
			theLogger.info("Main Thread: Another 2 Second passed. Stopping main thread");
			theOrderHandler.setStatus(Status.Done);
		}
	}

	private int theOrderId = 0;
	private Logger theLogger = LogManager.getLogger(getClass().getName());
	private OrderHandler theOrderHandler;
	private OrderListener theOrderListener;
}

package fit;

import org.apache.logging.log4j.Level;
import org.junit.Assert;
import org.junit.Test;

public class TestExpMovAvgFitter {
	
	@Test
	public void testFit() {
		
		EMAFitter myExpMovAvgFitter = new EMAFitter(2);
		myExpMovAvgFitter.theLogger.setLevel(Level.DEBUG);
		myExpMovAvgFitter.setAbsUpdateVal(0);
				
		double[][] myData = new double[][] {{1, 10}, {2, 20}, {3, 30}, {4, 40}, {5, 50}};
		
		double[] myCalcFromXls = new double[] {10, 12.92893219, 17.92893219, 24.39339828, 31.89339828};
		
		for (int i = 0 ; i < myData.length ; i++) {
			double myVal = myExpMovAvgFitter.fit(myData[i]);
			Assert.assertEquals(myCalcFromXls[i], myVal, 0.0001);
		}
	}
	
	@Test
	public void testFitWithAbsChange() {
		
		EMAFitter myExpMovAvgFitter = new EMAFitter(2);
		myExpMovAvgFitter.setAbsUpdateVal(6);
		myExpMovAvgFitter.theLogger.setLevel(Level.DEBUG);
				
		double[][] myData = new double[][] {{1, 10}, {2, 20}, {3, 30}, {4, 40}, {5, 50}};
		
		double[] myCalcFromXls = new double[] {10, 10, 20, 20, 35};
		
		for (int i = 0 ; i < myData.length ; i++) {
			double myVal = myExpMovAvgFitter.fit(myData[i]);
			Assert.assertEquals(myCalcFromXls[i], myVal, 0.0001);
		}
	}
	
	@Test
	public void testFitWithTimeInter() {
		
		EMAFitter myExpMovAvgFitter = new EMAFitter(2);
		myExpMovAvgFitter.setUpdateTimeInter(3);
		myExpMovAvgFitter.theLogger.setLevel(Level.DEBUG);
				
		double[][] myData = new double[][] {{1, 10}, {2, 20}, {3, 30}, {4, 40}, {5, 50}};
		
		double[] myCalcFromXls = new double[] {10, 10, 10, 29.39339828, 29.39339828};
		
		for (int i = 0 ; i < myData.length ; i++) {
			double myVal = myExpMovAvgFitter.fit(myData[i]);
			Assert.assertEquals(myCalcFromXls[i], myVal, 0.0001);
		}
	}
	
	@Test
	public void testUsingMarketData() {
		
	}

	
}

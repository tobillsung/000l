package strategy.spreadtrade;

import order.OrderHandler;
import order.SimOrderHandler;

import org.apache.logging.log4j.Level;
import org.junit.Test;

import com.ib.client.Contract;

import plot.DynamicXYPlot.PlotType;
import product.ProductManager;
import report.Reporter;
import strategy.PositionAdj;
import feed.FeedHandler;
import fit.EMAFitter;
import gui.report.ReporterMain;

public class TestSpreadTradeWithSim extends Thread{
	
	@Test
	public void testSpreadTrade_CalendarES_SIM() throws Exception{

		Contract myFrontES = ProductManager.getContractByTicker("ESH4");
		Contract myBackES = ProductManager.getContractByTicker("ESM4");
		
		Contract[] myContracts = new Contract[] {myFrontES, myBackES};
		
		theFeedHandler = new FeedHandler();
		theFeedHandler.init();
		new Thread(theFeedHandler).start();
		
		theSimOrderHandler = new SimOrderHandler();
		theSimOrderHandler.init();
		theSimOrderHandler.theLogger.setLevel(Level.DEBUG);
		new Thread(theSimOrderHandler).start();
		
		EMAFitter myFitter = new EMAFitter(60 * 1e3, 5000);
		myFitter.setAbsUpdateVal(10);
		
		PositionAdj myPositionAdj = new PositionAdj(30, 20, 12.5, 1);
		
		
		double [] myWeights = new double[] {1, -1};
		
		SpreadTradeBuilder mySTB = new SpreadTradeBuilder();
		theST = mySTB.contract(myContracts).weight(myWeights).volumePerTrade(1).build();
		theST.theLogger.setLevel(Level.DEBUG);
		theST.init(theFeedHandler, theSimOrderHandler, myFitter, myPositionAdj);
		theST.setOrderType(strategy.AbstractStrategy.Type.MKT);

		new Thread(theST).start();
		
		this.start();
	}
	
	
	public void run() {
		
		synchronized(this) {
			try {
				this.wait(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("Adding plot and reporter to the system");
		}
		
		synchronized (theST) {
			theST.setDynamicXYPlot(PlotType.SpreadTrade);
			theReporter = new Reporter();
			theReporter.addReporterListener(new ReporterMain("ES_Reporter", false));
			theST.setReporter(theReporter);
		}
		
		synchronized(this) {
			try {
				this.wait(3000000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		synchronized (theST) {
			theST.setStatus(strategy.AbstractStrategy.Status.Done);
		}
		
		synchronized (theSimOrderHandler) {
			theSimOrderHandler.setStatus(OrderHandler.Status.Done);
		}
		
		synchronized (theFeedHandler) {
			theFeedHandler.setStatus(FeedHandler.Status.Done);
		}
	}
	
	private FeedHandler theFeedHandler;
	private SimOrderHandler theSimOrderHandler;
	private SpreadTrade theST;
	Reporter theReporter;
	
}

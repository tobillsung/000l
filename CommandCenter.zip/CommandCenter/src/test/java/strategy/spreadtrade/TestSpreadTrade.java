package strategy.spreadtrade;

import order.OrderHandler;

import org.apache.logging.log4j.Level;
import org.junit.Test;

import plot.DynamicXYPlot;
import product.ProductManager;
import report.Reporter;
import strategy.AbstractStrategy.Type;
import strategy.PositionAdj;

import com.ib.client.Contract;

import feed.FeedHandler;
import fit.EMAFitter;
import gui.report.ReporterMain;

public class TestSpreadTrade extends Thread{
	
	@Test
	public void testSpreadTrade_CalendarES() throws Exception{
		
		theFeedHandler = new FeedHandler();
		theFeedHandler.init();
		new Thread(theFeedHandler).start();
		//theFeedHandler.theLogger.setLevel(Level.DEBUG);
		
		theOrderHandler = new OrderHandler();
		//theOrderHandler.theLogger.setLevel(Level.DEBUG);
		theOrderHandler.init();
		new Thread(theOrderHandler).start();
		
		EMAFitter myFitter = new EMAFitter(60 * 1e3, 5000);
		//theFitter.setAbsUpdateVal(10); 
		
		PositionAdj myPositionAdj = new PositionAdj(12.5, 12.5, 12.5, 1);
		
		Reporter myReporter = new Reporter();
		myReporter.addReporterListener(new ReporterMain("ES_Reporter", false));
		
		Contract myFrontES = ProductManager.getContractByTicker("ESH4");
		Contract myBackES = ProductManager.getContractByTicker("ESM4");
		
		Contract[] myContracts = new Contract[] {myFrontES, myBackES};
		double [] myWeights = new double[] {1, -1};
		
		SpreadTradeBuilder mySTB = new SpreadTradeBuilder();
		theST = mySTB.contract(myContracts).weight(myWeights).volumePerTrade(1).build();
		
		theST.setReporter(myReporter);
		theST.theLogger.setLevel(Level.DEBUG);
		theST.init(theFeedHandler, theOrderHandler, myFitter, myPositionAdj);
		theST.setDynamicXYPlot(DynamicXYPlot.PlotType.SpreadTrade);
		theST.setOrderType(Type.MKT);

		this.start();
		
		theST.run();
	}
	
	
	public void run() {
		synchronized(this) {
			try {
				System.out.println("Main thread is started");
				this.wait(1000 * 20);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("Main thread is finished");
		}
		
		synchronized (theST) {
			theST.setStatus(strategy.AbstractStrategy.Status.Done);
		}
		
		synchronized (theOrderHandler) {
			theOrderHandler.setStatus(OrderHandler.Status.Done);
		}
		
		synchronized (theFeedHandler) {
			theFeedHandler.setStatus(FeedHandler.Status.Done);
		}
	}
	
	private FeedHandler theFeedHandler;
	private OrderHandler theOrderHandler;
	private SpreadTrade theST;
	
}

package util;

import junit.framework.Assert;

import org.junit.Test;

import strategy.spreadtrade.SpreadTrade;
import feed.FeedHandler;

public class TestConfigManager {
	
	@Test
	public void testReadConfigFile() {
		Assert.assertEquals(ConfigManager.parseConfig(FeedHandler.class, "host", "hello"), "localhost");
		Assert.assertEquals(ConfigManager.parseConfig(MySqlHelper.class, "insertBatchSize", 12345), 300);
		Assert.assertEquals(ConfigManager.parseConfig(FeedHandler.class, "try_this", 1.2345), 1.2345);
		Assert.assertEquals(ConfigManager.parseConfig(SpreadTrade.class, "launchingSoundOn", false), true);
	}

}

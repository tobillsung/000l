package util;

import org.junit.Test;

public class TestCSVHelper {
	
	@Test
	public void testWrite() {
		
		init();
		for (int i = 0 ; i < 100 ; i++)
		{
			StringBuilder mySB = new StringBuilder();
			mySB.append(i + ",");
			mySB.append("test,CSVHelper,time,");
			mySB.append(System.currentTimeMillis() + "\n");
			CSVHelper.write(theFileName, mySB.toString(), true);
		}
	}

	
	@Test
	public void testRead() {
		init();
		
		CSVHelper.read(theFileName);
		
		
	}
	
	public void init() {
		double [] myDate = TimeConv.UnixT.toDateArray(System.currentTimeMillis());
		theFileName = "Order_" +  (int)myDate[0] + ".csv";
	}
	
	
	String theFileName = null;
}

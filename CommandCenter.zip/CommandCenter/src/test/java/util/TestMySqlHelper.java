package util;

import java.util.Arrays;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;

import product.ProductManager.SimpleDetail;

public class TestMySqlHelper {
	
	@Test
	public void testSelect() {
		MySqlHelper myHelper = new MySqlHelper();
		String[][] myRes = myHelper.select("MarketData", "BusinessDay", new String[] {"*"});
		
		for (String[] myEle : myRes)
			System.out.println(Arrays.toString(myEle));
	}

	@Test
	public void testGetBusinessDay() {
		MySqlHelper myHelper = new MySqlHelper();
		List<Integer> myBizDays = myHelper.getBusinessDay(20140112, 20140115);
		
		Assert.assertEquals(3, myBizDays.size());
	}
	
	@Test
	public void testGetProductDetail() {
		MySqlHelper myHelper = new MySqlHelper();
		List<SimpleDetail> myDetails = myHelper.getProductDetail("ESH4");
		
		for (SimpleDetail myDetail : myDetails) {
			System.out.println(myDetail.toString());
		}
		
	}
	
	@Test
	public void testGetHistDaily() {
		MySqlHelper myHelper = new MySqlHelper();
		double[][] myData = myHelper.getHistoricalDailyData("GLD", 20140103, 20140201, false);
		
		for (double[] myDataPerDay : myData) {
			System.out.println(Arrays.toString(myDataPerDay));
		}
	}
	
	@Test
	public void testGetRetailState() {
		MySqlHelper myHelper = new MySqlHelper();
		double[][] myData = myHelper.getTickRetailState(new String[] {"ESM4"}, 20140324, 83000.00, 83001.00);
		
		for (double[] myDataPerDay : myData) {
			System.out.println(Arrays.toString(myDataPerDay));
		}
	}
}

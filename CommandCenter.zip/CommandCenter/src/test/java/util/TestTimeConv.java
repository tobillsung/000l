package util;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

public class TestTimeConv {
	
	@Test
	public void testUnixTtoDateStr() {
		System.out.println(TimeConv.UnixT.toDateStr(System.currentTimeMillis()));
	}
	
	@Test
	public void testUnixTtoDateArray() {
		System.out.println(Arrays.toString(TimeConv.UnixT.toDateArray(System.currentTimeMillis())));
	}

	@Test
	public void testTimeNumToArray() {
		Assert.assertArrayEquals(new double[] {9, 30, 20, 234}, TimeConv.TimeNum.toArray(93020.234), 1e-3);
		Assert.assertArrayEquals(new double[] {0, 2, 59, 340}, TimeConv.TimeNum.toArray(259.34), 1e-3);
	}
}

package feed;

import java.util.Arrays;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;

import com.ib.client.Contract;

import product.ProductManager;
import feed.RetailState.Data;

public class TestSimFeedHandler {
	
	
	@Test
	public void testMultipleFeeds() throws Exception{
		theFH = new SimFeedHandler();
		theFH.init(20140324, 83000.00, 83001.00);
		theFH.theLogger.setLevel(Level.DEBUG);
		
		theFeedListenerOne = new FeedListenerOne();
		
		theFH.reqRetailStateUpdate(new Contract[] {ProductManager.getContractByTicker("ESM4"), 
				ProductManager.getContractByTicker("ESU4")}, theFeedListenerOne);
		theFH.run();
	}

	public class FeedListenerOne implements FeedListener {

		@Override
		public void newRetailState(String aSymbol, Data aNewData) {
			theLogger.info("FeedListener [" + aSymbol +"] " + Arrays.toString(aNewData.getTick()));
		}

		@Override
		public void newLastDone(String aSymbol, feed.LastDone.Data aNewData) {
			theLogger.info("FeedListener [" + aSymbol +"] " + Arrays.toString(aNewData.getTick()));
		}
	}
	
	SimFeedHandler theFH;
	private Logger theLogger = LogManager.getLogger(getClass().getName());
	private FeedListenerOne theFeedListenerOne;
}

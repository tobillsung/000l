package feed;

import junit.framework.Assert;

import org.junit.Test;

public class TestRetailState {
	
	@Test
	public void testAdd() {
		RetailState myRS = new RetailState("test");
		myRS.update(0, 0.0, 0, 100.0, 20);
		myRS.update(1, 99.0, 10, 100.0, 20);
		myRS.update(2, 99.0, 10, 100.0, 40);
		
		Assert.assertEquals(myRS.new Data(2, 99.0, 10, 100.0, 40), myRS.getLastUpdatedData());
	}
	
	
	@Test
	public void testMid() {
		RetailState myRS = new RetailState("test");
		myRS.update(2, 10.0, 8, 11, 2);
		
		Assert.assertEquals(10.5, myRS.getLastUpdatedData().getMid());
	}

	
	@Test
	public void testRWS() {
		RetailState myRS = new RetailState("test");
		myRS.update(2, 10.0, 8, 11, 2);
		
		double myRWS = myRS.getLastUpdatedData().getRWS();
		Assert.assertTrue(myRWS > 10.5 && myRWS < 11);
	}
}

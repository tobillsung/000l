package feed;

import java.util.Arrays;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;

import product.ProductManager;
import feed.FeedHandler.Status;
import feed.RetailState.Data;


public class TestFeedHandler extends Thread {
	
	@Test
	public void testMultipleFeeds() throws Exception{
		theFH = new FeedHandler();
		theFH.init();
		theFH.theLogger.setLevel(Level.DEBUG);
		
		theFeedListenerOne = new FeedListenerOne();
		
		theFH.reqRetailStateUpdate(ProductManager.getContractByTicker("ESH4"), theFeedListenerOne);
		
		this.start();
		theFH.run();
	}
	
	@Test
	public void testMultipleFeedsInsert() throws Exception {
		theFH = new FeedHandler();
		theFH.init(FeedHandler.InsertType.LoadCSV);
		theFeedListenerOne = new FeedListenerOne();
		theFH.reqRetailStateUpdate(ProductManager.getContractByTicker("ESM4"), theFeedListenerOne);
		this.start();
		theFH.run();
	}
	
	public void run() {
		synchronized (this) {
			try {
				this.wait(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		synchronized (theFH) {
			// After 5 sec, add GE to FeedHandler
			theLogger.info("Main Thread: 5 Second passed. Adding new symbol");
			try {
				//theFH.reqRetailStateUpdate(ProductManager.getContractByTicker("ESM4"), theFeedListenerOne);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		synchronized (this) {
			try {
				this.wait(30000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		synchronized (theFH) {
			// After 5 sec, add GE to FeedHandler
			theLogger.info("Main Thread: Another 5 Second passed. Stopping main thread");
			theFH.setStatus(Status.Done);
		}
	}
	
	public class FeedListenerOne implements FeedListener {

		@Override
		public void newRetailState(String aSymbol, Data aNewData) {
			theLogger.info("FeedListener [" + aSymbol +"] " + Arrays.toString(aNewData.getTick()));
		}

		@Override
		public void newLastDone(String aSymbol, feed.LastDone.Data aNewData) {
			theLogger.info("FeedListener [" + aSymbol +"] " + Arrays.toString(aNewData.getTick()));
		}
	}

	private Logger theLogger = LogManager.getLogger(getClass().getName());
	private FeedHandler theFH;
	private FeedListenerOne theFeedListenerOne;
}

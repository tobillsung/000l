package plot;

import java.util.Date;

import plot.DynamicXYPlot.PlotType;
import product.ProductManager;
import feed.FeedHandler;
import feed.FeedListener;
import feed.RetailState.Data;

public class TestDynamicXYPlot implements FeedListener{
	
	public TestDynamicXYPlot() {
		
		thePlot.init();
		FeedHandler myFH = new FeedHandler();
		myFH.init();
		try {
			myFH.reqRetailStateUpdate(ProductManager.getContractByTicker("SPY"), this);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		
		new TestDynamicXYPlot();
		
	}
	
	@Override
	public void newRetailState(String aSymbol, Data aNewData) {
		thePlot.addNewDataset(new Date(), new double[] {aNewData.getBidP(), aNewData.getAskP(), 
			aNewData.getBidP(), aNewData.getAskP(), Double.NaN, aNewData.getAskP()});
		
	}
	@Override
	public void newLastDone(String aSymbol, feed.LastDone.Data aNewData) {
		// TODO Auto-generated method stub
		
	}
	
	private DynamicXYPlot thePlot = new DynamicXYPlot(
			"Test chart", PlotType.SpreadTrade, new Date(System.currentTimeMillis()), 
			new double[] {0,0,0,0,0,0});
	
}

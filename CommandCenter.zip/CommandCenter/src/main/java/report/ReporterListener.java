package report;

import strategy.AbstractStrategy;

public interface ReporterListener {
	
	public void newRecord(AbstractStrategy aStrategy, Reporter.Summary aSummary);

}

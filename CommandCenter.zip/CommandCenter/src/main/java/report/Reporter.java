package report;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import strategy.AbstractStrategy;

public class Reporter {
	
	public Reporter() {
	}
	
	public void addReporterListener(ReporterListener aLister) {
		theReporterListeners.add(aLister);
	}
	
	public void addRecord(AbstractStrategy aStrategy, int aPortfolioPos, double aPnL, double aFeePerPortfolioTrade) {
		
		theFeePerPortfolioTrade = aFeePerPortfolioTrade;
		
		String myStrategyName = aStrategy.getStrategyName();
		Summary mySummary = null;
		if (theStrategySummaryMap.containsKey(myStrategyName)) {
			mySummary = theStrategySummaryMap.get(myStrategyName);
			mySummary.addNewItem(aPortfolioPos, theFeePerPortfolioTrade, aPnL);
		} else {
			mySummary = new Summary(aPortfolioPos, theFeePerPortfolioTrade, aPnL);
		}
		theStrategySummaryMap.put(myStrategyName, mySummary);
		
		for (ReporterListener myListenr : theReporterListeners) {
			myListenr.newRecord(aStrategy, mySummary);
		}
	}
	
	public Summary getSummary(AbstractStrategy aStrategy) {
		String myStrategyName = aStrategy.getStrategyName();
		Summary mySummary = null;
		if (theStrategySummaryMap.containsKey(myStrategyName)) {
			mySummary = theStrategySummaryMap.get(myStrategyName);
		} else {
			mySummary = new Summary(0, 0, 0);
		}
		
		return mySummary;
	}
	
	public class Summary {
		
		public Summary(int aCurrPos, double aFeePerPortfolioTrade, double aPnL) {
			
			theCumulativePos = aCurrPos;
			if (aCurrPos > 0)
				theCumulativeBuyN = aCurrPos;
			else
				theCumulativeSellN = Math.abs(aCurrPos);
			
			if (aCurrPos != 0) { // If it is not the Init state
				theCumulativeFee = aFeePerPortfolioTrade;
			}
			theRemainPnL = aPnL;
		}
		
		public void addNewItem(int aCurrPos, double aFeePerPortfolioTrade, double aPnL) {
			theCumulativePos = theCumulativePos + aCurrPos;
			if (aCurrPos > 0)
				theCumulativeBuyN = theCumulativeBuyN + aCurrPos;
			else
				theCumulativeSellN = theCumulativeSellN + Math.abs(aCurrPos);
			
			if (aCurrPos != 0) { // If it is not the Init state
				theCumulativeFee = theCumulativeFee + aFeePerPortfolioTrade;
			}
			
			// Calculate cumulative flat pnl
			if (theCumulativePos == 0) {
				theCumulativeFlatPnL = theCumulativeFlatPnL + theRemainPnL + aPnL;
				theRemainPnL = 0;
			} else
				theRemainPnL = theRemainPnL + aPnL;
		}
		
		
		public int theCumulativePos = 0;
		public int theCumulativeBuyN = 0;
		public int theCumulativeSellN = 0;
		public double theCumulativeFee = 0;
		public double theCumulativeFlatPnL = 0;
		private double theRemainPnL = 0;
		
	}
	
	private List<ReporterListener> theReporterListeners = new ArrayList<ReporterListener>();
	private Map<String, Summary> theStrategySummaryMap = new HashMap<String, Summary>();
	private double theFeePerPortfolioTrade = 0;
}

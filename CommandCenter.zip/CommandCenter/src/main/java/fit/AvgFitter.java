package fit;

public class AvgFitter extends AbstractFitter{
	
	public AvgFitter(long aInitFitTime) {
		theInitFitTime = aInitFitTime;
	}


	
	@Override
	public double fit(double[] aNewVal) {
		
		theCount++;
		
		theOldVal = (theOldVal * (theCount - 1) + aNewVal[Col_Val]) / theCount;
		
		return theOldVal;
	}
	
	public static int Col_Time = 0;
	public static int Col_Val = 1;
	
	private int theCount = 0;
}

package fit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

public class AbstractFitter implements Fittable{

	@Override
	public long initFitTime() {
		return theInitFitTime;
	}
	
	@Override
	public double initFitVal() {
		return theInitFitVal;
	}

	@Override
	public double fit(double[] aNewVal) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public void reset() {
		theOldTime = 0.0;
		theOldVal = 0.0;
	}
	
	@Override
	public void reset(double aTime, double aVal) {
		theOldTime = aTime;
		theOldVal = aVal;
	}
	
	public void setInitFitVal(double aInitFitVal) {
		theInitFitVal = aInitFitVal;
		if (theInitFitTime > 0) {
			theLogger.warn("InitFitTime is changed from {} to 0", theInitFitTime);
		}
		theInitFitTime = 0;
		theOldVal = aInitFitVal;
	}

	public void setAbsUpdateVal(double aAbsUpdateVal) {
		theAbsUpdateVal = aAbsUpdateVal;
	}
	
	public void setUpdateTimeInter(long aUpdateTimeInter) {
		theUpdateTimeInter = aUpdateTimeInter;
	}
	
	public boolean update(double aNewFitTime, double aNewFitVal) {
		
		if (theOldTime == 0) { // If running fitter for the first time
			return true;
		}
		
		double myTimeDiff = aNewFitTime - theOldTime;
		
		double myAbsValDiff = Math.abs(aNewFitVal - theOldVal);
		
		return theAbsUpdateVal <= myAbsValDiff || 
				theUpdateTimeInter <= myTimeDiff;
	}
	
	protected long theInitFitTime = 30000; // 30 seconds
	protected double theInitFitVal = 0;
	protected double theAbsUpdateVal = Double.MAX_VALUE;
	protected double theUpdateTimeInter = Double.MAX_VALUE;
	
	protected double theOldTime = 0.0;
	protected double theOldVal = 0.0;
	
	protected Logger theLogger = (Logger) LogManager.getLogger(getClass());

}

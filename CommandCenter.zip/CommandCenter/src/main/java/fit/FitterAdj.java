package fit;


public class FitterAdj extends AbstractFitter{
	
	public FitterAdj(AbstractFitter aBaseFitter) {
		theBaseFitter = aBaseFitter;
	}
	
	public void addAdjTrigger(double aAdjTrigger) {
		theAdjTrigger = aAdjTrigger;
	}
	
	public void addAdjMomentTrigger(double aAdjMomentTrigger, double aAdjMomentHalflife) {
		theAdjMomentTrigger = aAdjMomentTrigger;
		theAdjMomentHalflife = aAdjMomentHalflife;
	}
	
	@Override
	public double fit(double[] aNewVal) {
		return theBaseFitter.fit(aNewVal);
	}
	
	public void checkAdj(double aCurrTime, double aCurrVal, double aAdjMultiplier) {
		
		// Init the output
		theIsReset = false;
		theResetVal = aCurrVal;
		
		double myBaseFitterVal = theBaseFitter.theOldVal;
		
		double myCurrFitterValDiff = myBaseFitterVal - aCurrVal;
		double myTimeSinceLastCheck = aCurrTime - theLastCheckTime;
		
		if (theAdjTrigger > 0 && 
				Math.abs(myCurrFitterValDiff) >= theAdjTrigger) { // Check with AdjTrigger
			theIsReset = true;
			theResetVal = myBaseFitterVal;
			myCurrFitterValDiff = myBaseFitterVal - theResetVal;
			thePrevFitterValDiff = myCurrFitterValDiff;
		} else if (theAdjMomentTrigger > 0) {
			
			double myCurrMomentVal = (myCurrFitterValDiff - thePrevFitterValDiff) + 
					thePrevMomentVal * Math.pow(2, - myTimeSinceLastCheck / theAdjMomentHalflife);
			
			if (Math.abs(myCurrMomentVal) > theAdjMomentTrigger) {
				theIsReset = true;
				if (Math.signum(myCurrMomentVal) == Math.signum(aAdjMultiplier)) {
					theResetVal = aCurrVal + myCurrMomentVal * Math.abs(aAdjMultiplier);
				} else {
					theResetVal = aCurrVal + myCurrMomentVal;
				}
				
				myCurrMomentVal = 0.0;
				myCurrFitterValDiff = myBaseFitterVal - theResetVal;
			}
			
			if (Math.abs(myCurrFitterValDiff) >= 200) {
				System.out.println();
			}
			
			thePrevFitterValDiff = myCurrFitterValDiff;
			thePrevMomentVal = myCurrMomentVal;
			theLastCheckTime = aCurrTime;
		}
	}
	
	public boolean isReset() {return theIsReset;}
	
	public double getResetVal() {return theResetVal;}

	@Override
	public void reset() {
		thePrevFitterValDiff = 0.0;
		thePrevMomentVal = 0.0;
		theLastCheckTime = 0;
	}
	
	private AbstractFitter theBaseFitter = null;
	private double theAdjTrigger = 0.0;
	private double theAdjMomentTrigger = 0.0;
	private double theAdjMomentHalflife = 0.0;
	private double theLastCheckTime = 0.0;
	private double thePrevFitterValDiff = 0.0;
	private double thePrevMomentVal = 0.0;
	
	private double theResetVal = 0.0;
	private boolean theIsReset = false;
}

package fit;

public class TWAFitter extends AbstractFitter{
	
	public TWAFitter(long aInitFitTime) {
		theInitFitTime = aInitFitTime;
	}

	@Override
	public double fit(double[] aNewVal) {
		
		if (theOldTime == 0) {
			theOldTime = aNewVal[Col_Time];
			return 0;
		}
		
		double myTimeDiff = aNewVal[Col_Time] - theOldTime;
		
		theCumulativeTime = theCumulativeTime + myTimeDiff;
		if (myTimeDiff != 0) {
			theOldVal = ((theCumulativeTime - myTimeDiff) * theOldVal + aNewVal[Col_Val] * myTimeDiff) / theCumulativeTime;
		}
		theOldTime = aNewVal[Col_Time];
		return theOldVal;
	}
	
	public static int Col_Time = 0;
	public static int Col_Val = 1;
	
	private double theCumulativeTime = 0;

}

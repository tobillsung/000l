package fit;

public class EventEMAFitter extends AbstractFitter{
	
	public EventEMAFitter(double aEventMean) {
		theEventMean = aEventMean;
	}
	
	public EventEMAFitter(double aEventMean, long aInitFitTime) {
		theEventMean = aEventMean;
		theInitFitTime = aInitFitTime;
	}

	@Override
	public double fit(double[] aNewVal) {
		
		double myExpMovAvgVal = 0;
		if (theOldTime == 0.0) {
			myExpMovAvgVal = aNewVal[Col_Val];
		}
		else {
			double myDecayFactor = Math.pow(2, - 1 / theEventMean);
			myExpMovAvgVal = aNewVal[Col_Val] * (1 - myDecayFactor) + theOldVal * myDecayFactor;
		}
		
		if (update(aNewVal[Col_Time], myExpMovAvgVal)) {
			theLogger.debug("Fit is updated from {} to {}", 
					String.format("%.2f", theOldVal), String.format("%.2f", myExpMovAvgVal));
			theOldTime = aNewVal[Col_Time];
			theOldVal = myExpMovAvgVal;
		}
		
		return theOldVal;
		
	}
	
	public static int Col_Time = 0;
	public static int Col_Val = 1;
	
	private double theEventMean = 0;
	
}

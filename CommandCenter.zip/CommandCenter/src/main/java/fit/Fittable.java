package fit;

public interface Fittable {
	
	public long initFitTime();
	
	public double initFitVal();
	
	public double fit(double[] aNewVal);
	
	public void reset();
	
	public void reset(double aTime, double aVal);

}

package fit;

public class NullFitter extends AbstractFitter{

	public NullFitter() {
	}
	
	@Override
	public long initFitTime() {
		return 0;
	}

	@Override
	public double fit(double[] aNewVal) {
		return 0;
	}
	

}

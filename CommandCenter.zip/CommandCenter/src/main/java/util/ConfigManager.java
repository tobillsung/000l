package util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

public class ConfigManager {
	
	public static int parseConfig(String aFileName, Class<?> aClass, String aVarName, int aDefaultVal) {
		Properties myProp = getPropFromFile(aFileName);
		if (myProp == null)
			return 0;
		String myKey = ConfigManager.makeKey(aClass, aVarName);
		return Integer.valueOf(myProp.getProperty(myKey, Integer.toString(aDefaultVal)));
	}
	
	public static int parseConfig(Class<?> aClass, String aVarName, int aDefaultVal) {
		return parseConfig("config.properties", aClass, aVarName, aDefaultVal);
	}
	
	public static long parseConfig(String aFileName, Class<?> aClass, String aVarName, long aDefaultVal) {
		Properties myProp = getPropFromFile(aFileName);
		if (myProp == null)
			return 0l;
		String myKey = ConfigManager.makeKey(aClass, aVarName);
		return Long.valueOf(myProp.getProperty(myKey, Long.toString(aDefaultVal)));
	
	}
	
	public static long parseConfig(Class<?> aClass, String aVarName, long aDefaultVal) {
		return parseConfig("config.properties", aClass, aVarName, aDefaultVal);
	}
	
	public static double parseConfig(String aFileName, Class<?> aClass, String aVarName, double aDefaultVal) {
		Properties myProp = getPropFromFile(aFileName);
		if (myProp == null)
			return 0.0;
		
		String myKey = ConfigManager.makeKey(aClass, aVarName);
		return Double.valueOf(myProp.getProperty(myKey, Double.toString(aDefaultVal)));
	}
	
	public static double parseConfig(Class<?> aClass, String aVarName, double aDefaultVal) {
		return parseConfig("config.properties", aClass, aVarName, aDefaultVal);
	}
	
	public static boolean parseConfig(String aFileName, Class<?> aClass, String aVarName, boolean aDefaultVal) {
		Properties myProp = getPropFromFile(aFileName);
		if (myProp == null)
			return true;
		
		String myKey = ConfigManager.makeKey(aClass, aVarName);
		return Boolean.valueOf(myProp.getProperty(myKey, Boolean.toString(aDefaultVal)));
	}
	
	public static boolean parseConfig(Class<?> aClass, String aVarName, boolean aDefaultVal) {
		return parseConfig("config.properties", aClass, aVarName, aDefaultVal);
	}
	
	public static String parseConfig(String aFileName, Class<?> aClass, String aVarName, String aDefaultVal) {
		Properties myProp = getPropFromFile(aFileName);
		if (myProp == null)
			return null;
		
		String myKey = ConfigManager.makeKey(aClass, aVarName);
		return myProp.getProperty(myKey, aDefaultVal);
	}
	
	public static String parseConfig(Class<?> aClass, String aVarName, String aDefaultVal) {
		return parseConfig("config.properties", aClass, aVarName, aDefaultVal);
	}
	
	
	private static Properties getPropFromFile(String aFileName) {
		InputStream myInput = ConfigManager.class.getClassLoader().getResourceAsStream(aFileName);
		if (myInput == null) {
			if (myInput == null) {
				theLogger.error("Cannot find {} in root folder", aFileName);
				return null;
			}
		}
		
		Properties myProp = new Properties();
		try {
			myProp.load(myInput);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		return myProp;
	}
	
	public static String makeKey(Class<?> aClass, String aVarName) {
		return aClass.getName() + "." + aVarName;
	}
	
	public static Logger theLogger = (Logger) LogManager.getLogger(ConfigManager.class.getName());
}

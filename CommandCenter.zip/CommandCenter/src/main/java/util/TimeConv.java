package util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeConv {
	
	public static class UnixT {
		
		public static String toDateStr(long aUnixT) {
			Date myDate = new Date(aUnixT);
			SimpleDateFormat myDF = new SimpleDateFormat("yyyyMMdd HHmmss.SSS");
			return myDF.format(myDate);
		}
		
		public static double[] toDateArray(long aUnixT) {
			String myDateStr = TimeConv.UnixT.toDateStr(aUnixT);
			String[] myDateStrArray = myDateStr.split(" ");
			
			return new double[] {Double.valueOf(myDateStrArray[0]),
					Double.valueOf(myDateStrArray[1])};
		}
	}
	
	public static class TimeNum {
		
		public static double[] toArray(double aTimeNum) {
			
			double myHr = Math.floor(aTimeNum / 1e4);
			double myMin = Math.floor((aTimeNum - myHr * 1e4) / 1e2);
			double mySec = Math.floor(aTimeNum - myHr * 1e4 - myMin * 1e2);
			double myMillis = Math.round((aTimeNum - myHr * 1e4 - myMin * 1e2 - mySec) * 1000);
			
			return new double[] {myHr, myMin, mySec, myMillis};
		}
	}

}

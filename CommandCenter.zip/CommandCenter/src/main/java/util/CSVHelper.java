package util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CSVHelper {

	public static void read (String aFileName) {
		
		FileReader myFileReader = null;
		BufferedReader myReader = null;
		try {
			myFileReader = new FileReader(aFileName);
			
			myReader = new BufferedReader(myFileReader);
			String myLine = myReader.readLine();
			while(myLine != null)
			{
				System.out.println(myLine);
				myLine = myReader.readLine();
			}
		} catch (Exception io) {
			io.printStackTrace();
		} finally {
			
			try {
				myFileReader.close();
				myReader.close();
			} catch (Exception e){
				e.printStackTrace();
			}
		}
	}
	
	public static void write(String aFileName, String aString, boolean aAppend) {
		
		FileWriter myFileWritter = null;
		BufferedWriter myBufferedWriter = null;
		try {
			
			File myFile =new File(aFileName);
			 
			if(! myFile.exists()) {
				myFile.createNewFile();
			}

			//true = append file
			myFileWritter = new FileWriter(myFile.getName(), aAppend);
			myBufferedWriter = new BufferedWriter(myFileWritter);
			if (aString.contains("\n"))
				myBufferedWriter.write(aString);
			else
				myBufferedWriter.write(aString + "\n");
	        
		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			try {
				myBufferedWriter.close();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}

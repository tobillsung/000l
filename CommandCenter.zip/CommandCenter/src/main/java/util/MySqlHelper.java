package util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import order.OrderHandler;
import order.OrderHandler.Status;
import order.OrderManager;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import product.FeeManager;
import product.FeeManager.FeeStructure;
import product.ProductManager;
import product.ProductManager.SimpleDetail;

import com.mysql.jdbc.ResultSetMetaData;

import feed.LastDone;
import feed.RetailState;


public class MySqlHelper {
	
	public MySqlHelper() {
		this(theHost);
		theLogger.debug("Connected to MySql database: {}", theHost);
	}
	
	public MySqlHelper(String aHost) {
		
		try {		
			theBasicDataSource = new BasicDataSource();
			theBasicDataSource.setDriverClassName("com.mysql.jdbc.Driver");
			theBasicDataSource.setUsername("visitor");
			theBasicDataSource.setPassword("visitor");
			theBasicDataSource.setUrl("jdbc:mysql://" + aHost + ":3306?" + "user=visitor&password=visitor");
			theBasicDataSource.setInitialSize(4);
			theLogger.debug("Connected to MySql database: {}", theHost);
		} catch (Exception e) {
			theLogger.error(e.getMessage());
			e.printStackTrace();
		}
	}
	
	
	public List<Integer> getBusinessDay(int aSDate, int aEDate) {
		
		String myQuery = "Select Date from " + BizDayTable + " where Date between " 
				+ aSDate + " and " + aEDate + " order by Date ASC;";
		
		List<Integer> myBizDays = new ArrayList<Integer>();
		
		Connection myConn = null;
		Statement myStatement = null;
		ResultSet myResultSet = null;
		try {
			myConn = theBasicDataSource.getConnection();
			myStatement = myConn.createStatement();
			myResultSet = myStatement.executeQuery(myQuery);
			
			while(myResultSet.next()) {
				myBizDays.add(myResultSet.getInt("Date"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(myConn, myStatement, myResultSet);
		}
		
		return myBizDays;
	}
	
	public List<SimpleDetail> getProductDetail(String aTicker) {
		
		String myQuery = "Select * from " + ProductTable + " where Ticker ='" + aTicker + "';";
		
		ProductManager myPM = new ProductManager();
		SimpleDetail mySimpleDetail = myPM.new SimpleDetail();
		List<SimpleDetail> myProductDetailList = new ArrayList<SimpleDetail>();
		
		Connection myConn = null;
		Statement myStatement = null;
		ResultSet myResultSet = null;
		try {
			myConn = theBasicDataSource.getConnection();
			myStatement = myConn.createStatement();
			myResultSet = myStatement.executeQuery(myQuery);
			
			while(myResultSet.next()) {
				mySimpleDetail.theSymbol = myResultSet.getString("Symbol");
				mySimpleDetail.theSecType = myResultSet.getString("SecType");
				mySimpleDetail.theExch = myResultSet.getString("Exch");
				mySimpleDetail.thePrimExch = myResultSet.getString("PrimExch");
				mySimpleDetail.theCurr = myResultSet.getString("Currency");
				mySimpleDetail.theCategory = myResultSet.getString("Category");
				mySimpleDetail.theSubCategory = myResultSet.getString("SubCategory");
				mySimpleDetail.theMultiplier = myResultSet.getInt("Multiplier");
				mySimpleDetail.theExpMon = myResultSet.getString("ExpMon");
				mySimpleDetail.theMinTick = myResultSet.getDouble("MinTick");
				mySimpleDetail.theDescrption = myResultSet.getString("Description");
				myProductDetailList.add(mySimpleDetail);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(myConn, myStatement, myResultSet);
		}
		
		return myProductDetailList;
	}
	
	public void insertProductDetail (Collection<SimpleDetail> aSimpleDetails) {
		
		Connection myConn = null;
		PreparedStatement myStm = null;
		try {
			myConn = theBasicDataSource.getConnection();
			myStm = myConn.prepareStatement(
					"insert ignore into " + ProductTable + " values (?,?,?,?,?,?,?,?,?,?,?,?);");
			
			Iterator<SimpleDetail> myDetailIter = aSimpleDetails.iterator();
			
			int myCount = 0;
			while(myDetailIter.hasNext())
			{
				myCount ++;
				SimpleDetail myDetail = myDetailIter.next();
				myStm.setString(1, myDetail.theSymbol);		// Symbol
				myStm.setString(2, myDetail.theTicker);		// Ticker
				myStm.setString(3, myDetail.theSecType);	// Security type
				myStm.setString(4, myDetail.theExch);		// Exchange
				myStm.setString(5, myDetail.thePrimExch);	// Primary exchange
				myStm.setString(6, myDetail.theCurr);		// Currency
				myStm.setString(7, myDetail.theCategory);	// Category
				myStm.setString(8, myDetail.theSubCategory);// Subcategory
				myStm.setInt(9, myDetail.theMultiplier); // Multiplier
				myStm.setString(10, myDetail.theExpMon);	// Expiry month
				myStm.setDouble(11, myDetail.theMinTick);	// Minimum tick size
				myStm.setString(12, myDetail.theDescrption); // Description
				myStm.addBatch();
				
				if (myCount % theInsertBatchSize == 0)
				{
					theLogger.info("{} out {} are {} batch inserted", 
							myCount, aSimpleDetails.size(), ProductTable);
					myStm.executeBatch();
				}
			}
			myStm.executeBatch();
			theLogger.info("{} out {} are {} batch inserted", 
					myCount, aSimpleDetails.size(), ProductTable);
			
		} catch (Exception aException) {
			aException.printStackTrace();
		} finally {
			close(myConn, myStm, null);
		}
	}
	
	public FeeStructure getFeeStructure(String aShortTicker, String aSecType) {
		
		String myQuery = "Select * from " + FeeTable + " where ShortTicker ='" + aShortTicker + "'" + 
				" and SecType ='" + aSecType + "';";
		
		FeeManager myFM = new FeeManager();
		FeeStructure myFeeStructure = null;
		
		Connection myConn = null;
		Statement myStatement = null;
		ResultSet myResultSet = null;
		try {
			myConn = theBasicDataSource.getConnection();
			myStatement = myConn.createStatement();
			myResultSet = myStatement.executeQuery(myQuery);
			
			while(myResultSet.next()) {
				myFeeStructure = myFM.new FeeStructure(
						myResultSet.getDouble("Commission"), 
						myResultSet.getDouble("ExchangeFee"), 
						myResultSet.getDouble("RegulationFee"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(myConn, myStatement, myResultSet);
		}
		
		if (myFeeStructure == null)
			theLogger.warn("FeeStructure for Short ticker: {} is not available from {}", 
					aShortTicker, FeeTable);
		
		return myFeeStructure;
	}
		
	public double[][] getTickRetailState(String aTicker, int aDate, double aSTime, double aETime) {
		
		return getTickRetailState(new String[] {aTicker}, aDate, aSTime, aETime);
	}
	
	public double[][] getTickRetailState(String[] aTickers, int aDate, double aSTime, double aETime) {
		
		List<double[]> myDataList = new ArrayList<double[]>();
		double[][] myData = null;
		
		Connection myConn = null;
		Statement myStatement = null;
		ResultSet myResultSet = null;
		try {			
			StringBuilder mySymbolBuilder = new StringBuilder();
			for (String myTicker : aTickers) {
				mySymbolBuilder.append("'" + ProductManager.getSymbolByTicker(myTicker) + "',");
			}
			String mySymbols = mySymbolBuilder.toString();
			mySymbols = mySymbols.substring(0, mySymbols.length() - 1);	// Eliminate last comma
			
			String myQuery = "Select * from " + TickRSTable + " where Symbol in (" + mySymbols + 
					") and Date = " + aDate + " and Time between " + aSTime + " and " + aETime + " order by Timestamp;";
			myConn = theBasicDataSource.getConnection();
			myStatement = myConn.createStatement();
			myResultSet = myStatement.executeQuery(myQuery);
			
			while(myResultSet.next()) {
				myDataList.add(new double[] {
						myResultSet.getDouble("Timestamp"), myResultSet.getDouble("Date"), 
						myResultSet.getDouble("Time"), 
						myResultSet.getDouble("BidP"), myResultSet.getDouble("BidV"), 
						myResultSet.getDouble("AskP"), myResultSet.getDouble("AskV"), myResultSet.getInt("FeedId")
				});
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(myConn, myStatement, myResultSet);
		}
		
		myData = myDataList.size() > 0 ? myDataList.toArray(new double[myDataList.size()][8]) : null;
		return myData;
	}
	
	/**
	 * Using batch insert
	 */
	public void insertTickRetailState(
			String aSymbol, RetailState.Data aData, int aFeedId, boolean aBatch) {
		
		try {
			
			if (theInsertRSTickConn == null)
				theInsertRSTickConn = theBasicDataSource.getConnection();
			
			if (theInsertRSTickPStm == null) {
				theInsertRSTickPStm = theInsertRSTickConn.prepareStatement(
						"insert into " + TickRSTable + " values (?,?,?,?,?,?,?,?,?)");
			}
			
			// Release the connection and insert all
			if (aData == null && aBatch == true) {
				theInsertRSTickPStm.executeBatch();
				close(theInsertRSTickConn, theInsertRSTickPStm, null);
				return;
			}
				
			long myTime = aData.getTime();
			theInsertRSTickPStm.setString(1, aSymbol);								// Symbol
			theInsertRSTickPStm.setLong(2, myTime);									// Timestamp
			double[] myTimeArray = TimeConv.UnixT.toDateArray(myTime);
			theInsertRSTickPStm.setInt(3, (int)myTimeArray[0]);						// Date
			theInsertRSTickPStm.setDouble(4, myTimeArray[1]);							// Time
			theInsertRSTickPStm.setDouble(5, aData.getBidP());						// Bid price
			theInsertRSTickPStm.setLong(6, aData.getBidV());							// Bid volume
			theInsertRSTickPStm.setDouble(7, aData.getAskP());						// Ask price
			theInsertRSTickPStm.setLong(8, aData.getAskV());							// Ask volume
			theInsertRSTickPStm.setLong(9, aFeedId);								// FeedId
			theInsertRSTickPStm.addBatch();
			
			if (aBatch) {
				theLogger.info("{} batch inserted", TickRSTable);
				theInsertRSTickPStm.executeBatch();
			}
		} catch (Exception aException) {
			aException.printStackTrace();
		}
	}
	
	public double[][] getTickLastDone(String aTickers, int aDate, double aSTime, double aETime) {
		
		return getTickLastDone(new String[] {aTickers}, aDate, aSTime, aETime);
	}
	
	public double[][] getTickLastDone(String[] aTickers, int aDate, double aSTime, double aETime) {
		
		List<double[]> myDataList = new ArrayList<double[]>();
		double[][] myData = null;
		
		Connection myConn = null;
		Statement myStatement = null;
		ResultSet myResultSet = null;
		try {
			
			StringBuilder mySymbolBuilder = new StringBuilder();
			for (String myTicker : aTickers) {
				mySymbolBuilder.append("'" + ProductManager.getSymbolByTicker(myTicker) + "',");
			}
			String mySymbols = mySymbolBuilder.toString();
			mySymbols = mySymbols.substring(0, mySymbols.length() - 1);	// Eliminate last comma
			
			String myQuery = "Select * from " + TickLDTable + " where Symbol in (" + mySymbols + 
					") and Date = " + aDate + " and Time between " + aSTime + " and " + aETime + " order by Timestamp;";
			myConn = theBasicDataSource.getConnection();
			myStatement = myConn.createStatement();
			myResultSet = myStatement.executeQuery(myQuery);
			
			while(myResultSet.next()) {
				myDataList.add(new double[] {
						myResultSet.getDouble("Timestamp"), myResultSet.getDouble("Date"), 
						myResultSet.getDouble("Time"), 
						myResultSet.getDouble("LastP"), myResultSet.getDouble("LastV"),
						myResultSet.getInt("FeedId")
				});
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(myConn, myStatement, myResultSet);
		}
		
		myData = myDataList.size() > 0 ? myDataList.toArray(new double[myDataList.size()][6]) : null;
		
		return myData;
	}
	
	/**
	 * Using batch insert
	 */
	public void insertTickLastDone(String aSymbol, LastDone.Data aData, int aFeedId, boolean aBatch) {
		
		try {
			
			if (theInsertLDTickConn == null)
				theInsertLDTickConn = theBasicDataSource.getConnection();
			
			if (theInsertLDTickPStm == null) {
				theInsertLDTickPStm = theInsertLDTickConn.prepareStatement(
						"insert into " + TickLDTable + " values (?,?,?,?,?,?,?)");
			}
			
			// Release the connection and insert all
			if (aData == null && aBatch == true) {
				theInsertLDTickPStm.executeBatch();
				close(theInsertLDTickConn, theInsertLDTickPStm, null);
				return;
			}
			
			long myTime = aData.getTime();
			theInsertLDTickPStm.setString(1, aSymbol);		// Symbol
			theInsertLDTickPStm.setLong(2, myTime);			// Timestamp
			double[] myTimeArray = TimeConv.UnixT.toDateArray(myTime);		
			theInsertLDTickPStm.setInt(3, (int)myTimeArray[0]);			// Date
			theInsertLDTickPStm.setDouble(4, myTimeArray[1]);				// Time
			theInsertLDTickPStm.setDouble(5, aData.getLastP());			// Last price
			theInsertLDTickPStm.setLong(6, aData.getLastV());				// Last volume
			theInsertLDTickPStm.setLong(7, aFeedId);				// FeedId
			theInsertLDTickPStm.addBatch();
			
			if (aBatch) {
				theLogger.info("{} batch inserted", TickLDTable);
				theInsertLDTickPStm.executeBatch();
			}
		} catch (Exception aException) {
			aException.printStackTrace();
		}
	}
	
	
	public void insertOrderState(Map<Integer, List<OrderManager>> aOrderIdToManagerMap, String aStrategyName) {
		
		Connection myConn = null;
		PreparedStatement myStm = null;
		try {
			myConn = theBasicDataSource.getConnection();
			myStm = myConn.prepareStatement(
					"insert into " + OrderStateTable + " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			
			int myCount = 0;
			for (Map.Entry<Integer, List<OrderManager>> myMap : aOrderIdToManagerMap.entrySet()) {
				int myOrderId = myMap.getKey();
				List<OrderManager> myOrderManagers = myMap.getValue();
				
				for (OrderManager myOrderManager : myOrderManagers) {
					// If you have open order when the server is started, then the null order is
					// pushed from database
					if (myOrderManager.theStatus.equals(Status.Init) ||
							myOrderManager.theStrategy.equals(OrderHandler.InitStrategy))
						continue;
					
					// Only insert from Strategy
					if (myOrderManager.theStrategy.equals(aStrategyName)) {
					
						long myTimestamp = myOrderManager.theTime;
						double[] myTimeArray = TimeConv.UnixT.toDateArray(myTimestamp);
						
						// fill prepared statement
						myStm.setInt(1, (int)myTimeArray[0]); 				// Date
						myStm.setInt(2, myOrderId);							// OrderId
						myStm.setDouble(3, myTimeArray[1]);					// Time
						myStm.setString(4, myOrderManager.theStrategy);		// Strategy
						myStm.setString(5, myOrderManager.theSymbol);		// Symbol
						myStm.setDouble(6, myOrderManager.theOrder.m_lmtPrice);	// Price
						myStm.setInt(7, myOrderManager.theOrder.m_totalQuantity); // Volume
						myStm.setString(8, myOrderManager.theOrder.m_orderType); // Type
						myStm.setString(9, myOrderManager.theOrder.m_action); // Action
						myStm.setDouble(10 , myOrderManager.theFilledP);			// Filled price
						myStm.setInt(11 , myOrderManager.theFilledV);			// Filled volume
						myStm.setInt(12 , myOrderManager.theRemainingV);			// Remaining volume
						myStm.setString(13, myOrderManager.theStatus.name()); 	// Status 
						myStm.setLong(14, myTimestamp);							// Timestamp
						
						myStm.addBatch();
						myCount ++;
						if (myCount % theInsertBatchSize == 0)
							myStm.executeBatch();
					}
				}
			}
			theLogger.info("{} batch inserted", OrderStateTable);
			myStm.executeBatch();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(myConn, myStm, null);
		}
	}
	
	public double[][] getHistoricalDailyData(String aTicker, int aSDate, int aEDate, boolean aDescending) {
		
		String myOrderBy = "ASC";
		if (aDescending)
			myOrderBy = "DESC";

		String myQuery = "Select count(*) as count from " + HistDailyTable + " where Date between " 
				+ aSDate + " and " + aEDate + " and Ticker = '" + aTicker + "';";
		
		double[][] myData = null;
		
		Connection myConn = null;
		Statement myStm = null;
		ResultSet myResultSet = null;
		try {
			
			myConn = theBasicDataSource.getConnection();
			myStm = myConn.createStatement();
			myResultSet = myStm.executeQuery(myQuery);
			myResultSet.next();
			int myCount = myResultSet.getInt("count");
			
			if (myCount == this.getBusinessDay(aSDate, aEDate).size())
			{
				close(myConn, myStm, myResultSet);
				myData = new double[myCount][7];
				String myDataQuery = "Select Date, Open, High, Low, Volume, Close, AdjClose "
						+ "from " + HistDailyTable + " where Date between " + aSDate + " and " + aEDate 
						+ " and Ticker = '" + aTicker + "' order by Date " + myOrderBy + ";";
				
				myConn = theBasicDataSource.getConnection();
				myStm = myConn.createStatement();
				myResultSet = myStm.executeQuery(myDataQuery);
				int myRowN = 0;
				while(myResultSet.next())
				{
					myData[myRowN][0] = myResultSet.getInt("Date");
					myData[myRowN][1] = myResultSet.getDouble("Open");
					myData[myRowN][2] = myResultSet.getDouble("High");
					myData[myRowN][3] = myResultSet.getDouble("Low");
					myData[myRowN][4] = myResultSet.getDouble("Close");
					myData[myRowN][5] = myResultSet.getDouble("AdjClose");
					myData[myRowN][6] = myResultSet.getDouble("Volume");
					myRowN = myRowN + 1;
				}
			}
			else
			{
				if (myCount == 0)
					theLogger.warn("No data [{}] from MarketData.DailyData", aTicker);
										
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(myConn, myStm, myResultSet);
		}
		return myData;
	}
	
	public void loadCSVToTable(String aCSVFileName, String aTableName, 
			boolean aDeleteCSVFile, boolean aIgnoreHeader) {
		
		File myLoadFile = new File(aCSVFileName);
		Connection myConn = null;
		Statement myStm = null;
		try {
			
			myConn = theBasicDataSource.getConnection();
			myStm = myConn.createStatement();
			
			if (aIgnoreHeader) {
				myStm.executeUpdate(
						"LOAD DATA LOCAL INFILE '" + aCSVFileName + "' into table " 
								+ aTableName + " fields terminated by ',' IGNORE 1 LINES;");
			} else {
				myStm.executeUpdate(
						"LOAD DATA LOCAL INFILE '" + aCSVFileName + "' into table " 
								+ aTableName + " fields terminated by ',';");
			}
			if (aDeleteCSVFile) // Delete only load has been successful
				myLoadFile.delete();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(myConn, myStm, null);
		}
	}
	
	public void loadHistoricalDailyData(String aTicker, double[][] aData) {
		if (aData == null)
			return;
		
		theLogger.info("Loading data to table for {}", aTicker);
		
		try {
			File myLoadFile = new File("tempLoadFile");
			BufferedWriter myBW = new BufferedWriter(new FileWriter(myLoadFile));
			
			for (double[] myDataPerRow : aData)
			{
				myBW.write(String.format("%s,%d,%f,%f,%f,%f,%f,%f\n", 
						aTicker, (int)myDataPerRow[0], myDataPerRow[1], myDataPerRow[2],
						myDataPerRow[3], myDataPerRow[4], myDataPerRow[5], myDataPerRow[6]));
			}
			myBW.close();
			
			Connection myConn = null;
			Statement myStm = null;
			try {
				
				myConn = theBasicDataSource.getConnection();
				myStm = myConn.createStatement();
				myStm.executeUpdate(
						"LOAD DATA LOCAL INFILE 'tempLoadFile' into table MarketData.DailyData fields terminated by ',';");
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				close(myConn, myStm, null);
			}
			
			myLoadFile.delete();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public String[][] select(String aDatabase, String aTable, String[] aColName) {
		return select(aDatabase + "." + aTable, aColName, ""); 
	}
	
	public String[][] select(String aTable, String[] aColName) {
		return select(aTable, aColName, ""); 
	}
	
	public String[][] select(String aDatabase, String aTable, String[] aColName, String aWhere) {
		return select(aDatabase + "." + aTable, aColName, aWhere); 
	}
	
	public String[][] select(String aTable, String[] aColName, String aWhere) {
		String[][] myData = null;
		
		StringBuilder myQuery = new StringBuilder(); 
		myQuery.append("Select count(*) as count from " + aTable);
		if (! aWhere.equals(""))
			myQuery.append(" where " + aWhere + ";");
		else
			myQuery.append(";");
		
		Connection myConn = null;
		Statement myStm = null;
		ResultSet myResultset = null;
		try {
			myConn = theBasicDataSource.getConnection();
			myStm = myConn.createStatement();
			myResultset = myStm.executeQuery(myQuery.toString());
			myResultset.next();
			int myCount = myResultset.getInt("count");
			
			if (myCount > 0 ) {
				close(myConn, myStm, myResultset);
				
				StringBuilder myDataQuery = new StringBuilder();
				myDataQuery.append("Select ");
				
				for (int i = 0 ; i < aColName.length ; i++) {
					if (i == aColName.length - 1)
						myDataQuery.append(aColName[i] + " from ");
					else
						myDataQuery.append(aColName[i] + ", ");
				}
				myDataQuery.append(aTable);
				if (! aWhere.equals(""))
					myDataQuery.append(" where " + aWhere + ";");
				else
					myDataQuery.append(";");
				
				myConn = theBasicDataSource.getConnection();
				myStm = myConn.createStatement();
				myResultset = myStm.executeQuery(myDataQuery.toString());
				
				if (aColName.length == 1 && aColName[0].equals("*"))
					myData = new String[myCount][myResultset.getMetaData().getColumnCount()];
				else
					myData = new String[myCount][aColName.length];
				int myRowN = 0;
				
				while(myResultset.next()){
					for (int i = 0 ; i < myData[0].length ; i++)
						myData[myRowN][i] = myResultset.getString(i + 1); // Col index starts from 1
					
					myRowN = myRowN + 1;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(myConn, myStm, myResultset);
		}
		return myData;
		
	}
	
	public String[][] select(String aQuery) {
		
		String [][] myData = null;
		Connection myConn = null;
		Statement myStm = null;
		ResultSet myResultSet = null;
				
		try {
			myConn = theBasicDataSource.getConnection();
			myStm = myConn.createStatement();
			myResultSet = myStm.executeQuery(aQuery);
			
			ResultSetMetaData myMetaData = (ResultSetMetaData) myResultSet.getMetaData();
			
			List<String[]> myRes = new ArrayList<String[]>();
			
			String [] myDataPerRow = new String[myMetaData.getColumnCount()];
			while(myResultSet.next()) {
				for (int i = 0 ; i < myDataPerRow.length ; i++) {
					myDataPerRow[i] = myResultSet.getString(i + 1); // Col index starts from 1
				}
				myRes.add(myDataPerRow.clone());
			}
			
			if (myRes.size() > 0) {
				myData = new String[myRes.size()][myMetaData.getColumnCount()];
				for (int i = 0 ; i < myRes.size(); i++) {
					myData[i] = myRes.get(i);
				}
			}
		} catch (Exception e){
			e.printStackTrace();
		} finally {
			close(myConn, myStm, myResultSet);
		}
		
		return myData;
	}
	
	
	
	public void insert(String aInsertStatement) {
		
		Connection myConn = null;
		Statement myStm = null;
		try {
			myConn = theBasicDataSource.getConnection();
			myStm = myConn.createStatement();
			myStm.executeUpdate(aInsertStatement);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(myConn, myStm, null);
		}
	}
	
	public void delete(String aDelStatement) {
		
		Connection myConn = null;
		Statement myStm = null;
		try {
			myConn = theBasicDataSource.getConnection();
			myStm = myConn.createStatement();
			myStm.executeUpdate(aDelStatement);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(myConn, myStm, null);
		}
	}
	
	public void deleteHistoricData(String aTicker, int aSDate, int aEDate) {
		
		theLogger.info("Deleting data for {} from {} to {}", aTicker, aSDate, aEDate);
		Connection myConn = null;
		PreparedStatement myStm = null;
		try {
			myConn = theBasicDataSource.getConnection();
			myStm = myConn.prepareStatement(
					"Delete from  MarketData.DailyData where Ticker = ? and Date between ? and ?;");
				
			myStm.setString(1, aTicker);
			myStm.setInt(2, aSDate);
			myStm.setInt(3, aEDate);
				
			myStm.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(myConn, myStm, null);
		}
	}
	
	// You need to close the resultSet
	private void close(Connection aConn, Statement aStm, ResultSet aResultSet) {
		
		if (aResultSet != null) {
			try {
				aResultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if (aStm != null) {
			try {
				aStm.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if (aConn != null) {
			try {
				aConn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	// Fields
	public static String BizDayTable = 
			ConfigManager.parseConfig(MySqlHelper.class, "bizDayTable", "MarketData.BusinessDay");
	public static String HistDailyTable = 
			ConfigManager.parseConfig(MySqlHelper.class, "histDailyTable", "MarketData.DailyData");
	public static String TickRSTable = 
			ConfigManager.parseConfig(MySqlHelper.class, "tickRetailStateTable", "MarketData.TickRetailState");
	public static String TickLDTable = 
			ConfigManager.parseConfig(MySqlHelper.class, "tickLastDoneTable", "MarketData.TickLastDone");
	public static String ProductTable = 
			ConfigManager.parseConfig(MySqlHelper.class, "productTable", "Product.Detail");
	public static String FeeTable = 
			ConfigManager.parseConfig(MySqlHelper.class, "feeTable", "Product.FeeStructure");
	public static String OrderStateTable = 
			ConfigManager.parseConfig(MySqlHelper.class, "orderStateTable", "Trade.OrderState");
	public static String TradeTable = 
			ConfigManager.parseConfig(MySqlHelper.class, "tradeTable", "Trade.Detail");
	
	private static Logger theLogger = LogManager.getLogger(MySqlHelper.class.getName());
	private static String theHost = ConfigManager.parseConfig(MySqlHelper.class, "host", "localhost");
	
	private int theInsertBatchSize = ConfigManager.parseConfig(MySqlHelper.class, "insertBatchSize", 200);
	
	private BasicDataSource theBasicDataSource = null;
	private Connection theInsertRSTickConn = null;
	private Connection theInsertLDTickConn = null;
	
	private PreparedStatement theInsertLDTickPStm = null;
	private PreparedStatement theInsertRSTickPStm = null;
}

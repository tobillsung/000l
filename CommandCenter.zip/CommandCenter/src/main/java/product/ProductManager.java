package product;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

import util.ConfigManager;
import util.MySqlHelper;

import com.ib.client.Contract;
import com.ib.client.ContractDetails;
import com.ib.client.EClientSocket;

import core.CoreWrapper;

public class ProductManager extends CoreWrapper{
	
	
	public ProductManager() {
	}
	
	public ProductManager(String aHost, int aPort, int aClientId) {
		theHost = aHost;
		thePort = aPort;		
		theClientId = aClientId;
	}
	
	/**
	 * Product.Detail.Symbol is the primary key
	 * However, you have no the Symbol format (Ticker.SecType.Exch.Curr)
	 * @param aSymbol
	 * @return
	 * @throws Exception 
	 */
	public static Contract getContractBySymbol(String aSymbol) throws Exception {
		String myWhereStr = "Symbol = '" + aSymbol.toUpperCase() + "'";
		String[][] myRes = theMySqlHelper.select("Product", "Detail", 
				new String[] {"Symbol"}, myWhereStr);
		
		if (myRes == null)
			throw new Exception("No data from Product.Detail");
		
		Contract myContract = new Contract();
		String[] myEle = myRes[0][0].split("\\.");
		myContract.m_localSymbol = myEle[0];
		myContract.m_secType = myEle[1];
		myContract.m_exchange = myEle[2];
		myContract.m_currency = myEle[3];
		
		return myContract;
		
	}
	
	/**
	 * If you only look at the US equity or futures, this would work for most products
	 * If there are multiple results, it will print out symbols
	 * @param aTicker
	 * @return
	 * @throws Exception 
	 */
	public static Contract getContractByTicker(String aTicker) throws Exception {
		
		String mySymbol = getSymbolByTicker(aTicker);
		return getContractBySymbol(mySymbol);
	}
	
	public static String getSymbolByTicker(String aTicker) throws Exception{
		
		String myWhereStr = "Ticker = '" + aTicker.toUpperCase() + "'";
		String[][] myRes = theMySqlHelper.select("Product", "Detail", 
				new String[] {"Symbol"}, myWhereStr);
		
		if (myRes.length == 1) {
			return myRes[0][0];
		} else if (myRes.length > 1) {
			for (String[] myEle : myRes)
			{
				theLogger.warn("Multiple symbols [" + myEle[0] +"] for Ticker = " + aTicker );
				new Exception("Multiple symbols from Product.Detail");
			}
			return null;
		} else {
			new Exception("No data from Product.Detail");
			return null;
		}
	}
	
	public static String getSymbolByContract(Contract aContract) {
		
		String myLocalSymbol = 
				aContract.m_localSymbol != null ? aContract.m_localSymbol : aContract.m_symbol;
		String mySecType = aContract.m_secType != null ? aContract.m_secType : "NA";
		String myExchange = aContract.m_exchange != null ? aContract.m_exchange : "NA";
		String myCurrency = aContract.m_currency != null ? aContract.m_currency : "NA";
			
		
		return myLocalSymbol + "." + mySecType + "." + myExchange + "." + myCurrency;
	}
	
	public static String getTickerByContract(Contract aContract) {
		String myLocalSymbol = 
				aContract.m_localSymbol != null ? aContract.m_localSymbol : aContract.m_symbol;
		return myLocalSymbol;
	}
	
	public static String getTickerBySymbol(String aSymbol) {
		String[] mySplit = aSymbol.split("\\.");
		return mySplit[0];
	}
	
	public void viewContract(Contract aContract, boolean aInsert) {
		viewContract(new Contract[] {aContract}, aInsert);
	}
	
	public void viewContract(Contract[] aContract, boolean aInsert) {
		
		theContractNum = aContract.length;
		theContractDetailMap = new HashMap<Integer, SimpleDetail>();
		theClient = super.connect(theHost, thePort, theClientId);
		
		synchronized (this) {
			try {
				for (int i = 0 ; i < aContract.length ; i ++) {
					theClient.reqContractDetails(i, aContract[i]);
				}
				
				while (theStatus != Status.Done && theStatus != Status.Error) {
					this.wait();
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			if (theStatus == Status.Done) {
				theLogger.info("view Contract is done");
				if (aInsert) {
					theMySqlHelper.insertProductDetail(theContractDetailMap.values());
				}
				super.disconnect(theClientId);
			}
		}
	}
	
	
	
	@Override
	public void contractDetails(int reqId, ContractDetails contractDetails) {
		
		synchronized (this) {
			if (!theContractDetailMap.containsKey(reqId)) {
				SimpleDetail mySimpleDetail = new SimpleDetail(contractDetails);
				theContractDetailMap.put(reqId, mySimpleDetail);
				printSimpleDetail(mySimpleDetail);
			}
			checkReqStatus();
		}
		
	}
	
	@Override
	public void error(int id, int errorCode, String errorMsg) {
		synchronized (this) {
			if (errorCode != 2104) // Market data farm connection is OK:ibdemo
			{
				//playErrorSound();
				theLogger.error(errorMsg + " for ReqId: " + id);
				theErrorId.add(id);
				checkReqStatus();
			}
		}
	}
	
	
	
	public void printSimpleDetail(SimpleDetail mySimpleDetail) {
		
		System.out.println(mySimpleDetail.toString());
	}
	
	public class SimpleDetail {
		
		public SimpleDetail() {
		}
		
		public SimpleDetail(ContractDetails aContractDetails) {
			
			theTicker = aContractDetails.m_summary.m_localSymbol;
			theSecType = aContractDetails.m_summary.m_secType;
			theExch = aContractDetails.m_summary.m_exchange;
			thePrimExch = aContractDetails.m_summary.m_primaryExch;
			theCurr = aContractDetails.m_summary.m_currency;
			theCategory = aContractDetails.m_category;
			theSubCategory = aContractDetails.m_subcategory;
			theMultiplier = aContractDetails.m_summary.m_multiplier == null ? 
					1 : Integer.valueOf(aContractDetails.m_summary.m_multiplier);
			theExpMon = aContractDetails.m_contractMonth; 
			theMinTick = aContractDetails.m_minTick;
			theDescrption = aContractDetails.m_longName;
			
			// Assume this can be unique identifier
			theSymbol = theTicker + "." + theSecType + "." + theExch + "." + theCurr;
		}
		
		@Override
		public String toString() {
			
			StringBuilder mySB = new StringBuilder();
			mySB.append("Symbol: " + theSymbol + ", ");
			mySB.append("Ticker: " + theTicker + ", ");
			mySB.append("SecType: " + theSecType + ", ");
			mySB.append("Exch: " + theExch + ", ");
			mySB.append("PrimExch: " + thePrimExch + ", ");
			mySB.append("Curr: " + theCurr + ", ");
			mySB.append("Category: " + theCategory + ", ");
			mySB.append("SubCategory: " + theSubCategory + ", ");
			mySB.append("Multiplier: " + theMultiplier + ", ");
			mySB.append("ExpMon: " + theExpMon + ", ");
			mySB.append("MinTick: " + theMinTick + ", ");
			mySB.append("Description: " + theDescrption);

			return mySB.toString();
		}
		
		public String theSymbol;
		public String theTicker;
		public String theSecType;
		public String theExch;
		public String thePrimExch;
		public String theCurr;
		public String theCategory;
		public String theSubCategory;
		
		public int theMultiplier;
		public String theExpMon;
		public double theMinTick;
		public String theDescrption;
		
	}
	
	private void checkReqStatus() {
		if (theContractDetailMap.keySet().size() + theErrorId.size() == theContractNum) {
			theStatus = Status.Done;
			this.notify();
		}
		
	}
	
	
	public EClientSocket theClient;
	private enum Status {None, Done, Error};
	private Status theStatus = Status.None;
	private static MySqlHelper theMySqlHelper = new MySqlHelper();
	private static Logger theLogger = (Logger) LogManager.getLogger(CoreWrapper.class.getName());
	
	private int theContractNum = 0;
	private Map<Integer, SimpleDetail> theContractDetailMap = null;
	
	private String theHost = ConfigManager.parseConfig(getClass(), "host", "127.0.0.1");
	private int thePort = ConfigManager.parseConfig(getClass(), "port", 7496);
	private int theClientId = ConfigManager.parseConfig(getClass(), "clientid", 1);
}

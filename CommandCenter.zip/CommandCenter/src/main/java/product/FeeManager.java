package product;

import util.MySqlHelper;
/**
 * https://www.interactivebrokers.com/en/index.php?f=commission&p=futures1
 * https://www.interactivebrokers.com/en/accounts/fees/CME.php
 * @author bill
 *
 */
public class FeeManager {
	
	public static FeeStructure getFeeStructure(String aTicker) {
		
		String mySecType = "STK";
		if (aTicker.matches("^.*\\d$")) { // This is the case for US future
			mySecType = "FUT";
			aTicker = aTicker.substring(0, aTicker.length() - 2);
		}
		
		return theMySqlHelper.getFeeStructure(aTicker, mySecType);
	}
	
	public static double getTotFeeForPortfolioTrade(String[] aTickers, double[] aTradeVolume) {
		
		double myTotFee = 0;
		for (int i = 0 ; i  < aTickers.length ; i++) {
			myTotFee = myTotFee + getFeeStructure(aTickers[i]).getTotFee() * Math.abs(aTradeVolume[i]);
		}
		return myTotFee;
	}

	
	public class FeeStructure {
		public FeeStructure (double aCommision, double aExchFee, double aRegulationFee) {
			theCommision = aCommision;
			theExchFee = aExchFee;
			theRegulationFee = aRegulationFee;
		}
		
		public double getTotFee() {
			return theCommision + theExchFee + theRegulationFee;
		}
		
		public double theCommision;
		public double theExchFee;
		public double theRegulationFee;
		
		
	}
	
	private static MySqlHelper theMySqlHelper = new MySqlHelper();
}

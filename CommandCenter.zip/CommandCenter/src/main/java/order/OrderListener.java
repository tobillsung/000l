package order;

public interface OrderListener {
	
	public void newOrderManager(OrderManager aOrderManager);

}

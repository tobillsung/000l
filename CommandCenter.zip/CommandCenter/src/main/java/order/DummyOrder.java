package order;


public class DummyOrder extends BaseOrder{
	
	public DummyOrder() {
		m_lmtPrice = theSomeLargeNum;
		m_orderId = 1;
		m_orderType = "LMT";
		m_action = "SELL";
		m_totalQuantity = 1;
	}
	
	public DummyOrder (int aOrderId) {
		m_lmtPrice = theSomeLargeNum;
		m_orderId = aOrderId;
		m_orderType = "LMT";
		m_action = "SELL";
		m_totalQuantity = 1;
	}
	
	public DummyOrder (int aOrderId, int aVolume) {
		m_lmtPrice = theSomeLargeNum;
		m_orderId = aOrderId;
		m_orderType = "LMT";
		m_action = "SELL";
		m_totalQuantity = aVolume;
	}

	public DummyOrder (int aOrderId, String aAction, int aVolume) {
		m_lmtPrice = theSomeLargeNum;
		m_orderId = aOrderId;
		m_orderType = "LMT";
		m_action = aAction;
		m_totalQuantity = aVolume;
	}

	public DummyOrder (int aOrderId, String aType, String aAction, int aVolume) {
		m_lmtPrice = theSomeLargeNum;
		m_orderId = aOrderId;
		m_orderType = aType;
		m_action = aAction;
		m_totalQuantity = aVolume;
	}
	
	private double theSomeLargeNum = 999999.0; // but less than IB limit of 2000000 for price * volume 999999
}

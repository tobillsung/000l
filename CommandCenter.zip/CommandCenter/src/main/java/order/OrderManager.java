package order;

import order.OrderHandler.Status;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class OrderManager implements Cloneable{
	
	public OrderManager(long aTime, String aStrategy, String aSymbol, BaseOrder aOrder) {
		theTime = aTime;
		theStrategy = aStrategy;
		theSymbol = aSymbol;
		theOrder = aOrder;
		theRemainingV = theOrder.m_totalQuantity;
	}

	public OrderManager filledPrice(double aFilledPrice) {
		synchronized(this) {
		theFilledP = aFilledPrice;
		return this;
		}
	}
	
	public OrderManager filledVolume(int aFilledVolume) {
		synchronized(this) {
		theFilledV = aFilledVolume;
		return this;
		}
	}
	
	public OrderManager remainingVolume(int aRemainingVolume) {
		synchronized(this) {
		theRemainingV = aRemainingVolume;
		return this;
		}
	}
	
	public OrderManager status(Status aStatus) {
		synchronized(this) {
			theStatus = aStatus;
			return this;
		}
	}
	
	public Object clone(){  
	    try{  
	        return super.clone();  
	    }catch(Exception e){ 
	    	e.printStackTrace();
	        return null; 
	    }
	}
	
	@Override
	public int hashCode() {
        return new HashCodeBuilder(17, 31).
            append(theStrategy).append(theSymbol).append(theOrder).append(theFilledP).
            append(theFilledV).append(theRemainingV).append(theStatus).toHashCode();
    }

	@Override
    public boolean equals(Object aObj) {
        if (aObj == null)
            return false;
        if (aObj == this)
            return true;
        if (!(aObj instanceof OrderManager))
            return false;

        OrderManager myOrderManager = (OrderManager) aObj;
        return new EqualsBuilder().
            append(theStrategy, myOrderManager.theStrategy).
            append(theSymbol, myOrderManager.theSymbol).
            append(theOrder, myOrderManager.theOrder).
            append(theFilledP, myOrderManager.theFilledP).
            append(theFilledV, myOrderManager.theFilledV).
            append(theRemainingV, myOrderManager.theRemainingV).
            append(theStatus, myOrderManager.theStatus).
            isEquals();
    }
	
	public long theTime;
	public String theStrategy;
	public String theSymbol;
	public BaseOrder theOrder;
	public double theExpLiftP = 0;
	public double theFilledP = 0;
	public int theFilledV = 0;
	public int theRemainingV;
	public Status theStatus = Status.Init;

}

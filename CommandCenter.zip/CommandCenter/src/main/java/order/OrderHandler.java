package order;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

import product.ProductManager;
import sound.SoundDrive;
import util.ConfigManager;
import util.MySqlHelper;

import com.ib.client.Contract;
import com.ib.client.EClientSocket;
import com.ib.client.Order;
import com.ib.client.OrderState;

import core.CoreWrapper;

public class OrderHandler extends CoreWrapper implements Runnable{
	
	public OrderHandler() {
	}
	
	public OrderHandler(String aHost, int aPort, int aClientId) {
		theHost = aHost;
		thePort = aPort;		
		theClientId = aClientId;
	}
	
	public void init() {
		
		synchronized(this) {
			
			if (theIsLaunchingSoundOn) {
				SoundDrive mySD = new SoundDrive();
				mySD.setAudioFile("sounddrive/order/OH_Launch.wav");
				new Thread(mySD).start();
			}
			theMySqlHelper = new MySqlHelper();
			theClient = super.connect(theHost, thePort, theClientId);
		}

	}
	
	@Override
	public void run() {
		
		synchronized(this) {

			while (theStatus != Status.Done && theStatus != Status.Error) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			if (theStatus == Status.Done || theStatus == Status.Error) {
				theLogger.info("Order handler is closed");
				super.disconnect(theClientId);
			}
		}
	}
	
	/**
	 * Use this method to insert orderstate from AbstractStrategy
	 * You call this when theStatus == Status.Done
	 */
	public void insertOrderState(String aStrategyName) {
		theMySqlHelper.insertOrderState(theOrderIdToManagerMap, aStrategyName);
	}
	
	/**
	 * Use this method to place order 
	 * @param aOrderId
	 * @param aStrategy
	 * @param aContract
	 * @param aOrder
	 * @param aOrderListener
	 */
	public void placeOrder(
			int aOrderId, String aStrategy, Contract aContract, 
			BaseOrder aOrder, OrderListener aOrderListener) {
		
		synchronized(this) {
			String mySymbol = ProductManager.getSymbolByContract(aContract);
			List<OrderManager> myOrderManagers = new ArrayList<OrderManager>();
			aOrder.m_orderId = aOrderId;
			OrderManager myOM = new OrderManager(
					System.currentTimeMillis(), aStrategy, mySymbol, aOrder);
			myOM.status(Status.Submitted);
			myOrderManagers.add(myOM);
			
			theOrderIdToManagerMap.put(aOrderId, myOrderManagers);
			
			theOrderIdToListenerMap.put(aOrderId, aOrderListener);
			theClient.placeOrder(aOrderId, aContract, aOrder);
		}
		
	}
	
	public void cancelOrder(int aOrderId, OrderListener aOrderListener) {
		synchronized(this) {
			theClient.cancelOrder(aOrderId);
		}
		
	}
	
	public void reqOpenOrders() {
		// req open order placed from this api client
		// fed into openOrder() and orderStatus()
		synchronized (this) {
			theClient.reqOpenOrders();
		}
	}
	
	public void reqAllOpenOrders() {
		// right now, I'm only using one client
		theClient.reqAllOpenOrders();
	}
	
	public void setStatus(Status aStatus) {
		synchronized(this) {
			theStatus = aStatus;
			this.notify();
		}
	}
	
	
	@Override
	public void orderStatus(int orderId, String status, int filled,
			int remaining, double avgFillPrice, int permId, int parentId,
			double lastFillPrice, int clientId, String whyHeld) {
		synchronized (this) {
			
			List<OrderManager> myOrderManagers = theOrderIdToManagerMap.get(orderId);
			OrderManager myLastOrderManager = myOrderManagers.get(myOrderManagers.size() - 1);
			OrderManager myNewOrderManager = (OrderManager) myLastOrderManager.clone(); // Init new OrderManager
			
			// Somehow filled event is created when price / volume is zero
			// So, I ignore this message
			if (filled == 0 && avgFillPrice == 0 && status.equals("Filled")) { 
				return;
			}
			
			// Possible updates are from status, filled price, filled volume, remaining volume
			myNewOrderManager.status(Status.valueOf(status))
				.filledPrice(avgFillPrice).filledVolume(filled).remainingVolume(remaining);
			
			// Only add if the new one is different
			if (! myLastOrderManager.equals(myNewOrderManager)) {
				// Update the timestamp
				myNewOrderManager.theTime = System.currentTimeMillis();
				myOrderManagers.add(myNewOrderManager);
				theOrderIdToManagerMap.put(orderId, myOrderManagers);
				
				// Log info for any fills (full fill or partial fill)
				if (status.equals(Status.Filled.name())) {
					theLogger.debug("[{}] order status: {}, filled: {}, remaining: {}",
							orderId, status, filled, remaining);
				}
				// Publish event to OrderListener only for full fills
				if (remaining == 0)
					theOrderIdToListenerMap.get(orderId).newOrderManager(myNewOrderManager);
			}
		}	
	}

	
	/**
	 * If you have any open order
	 * This will trigger first then go to orderStatus
	 */
	@Override
	public void openOrder(int orderId, Contract contract, Order order,
			OrderState orderState) {
		
		// TODO: for modifying the open order
		
	}
	
	// Retrieving next available order id when connect to TWS
	@Override
	public void nextValidId(int orderId) {
		synchronized (this) {
			theOrderId = orderId;
		}
		
	}
	
	/**
	 * When you create new order, you should use this to generate the unique one
	 * This is similar to reqIds() but it store the id number if you only have one client using OrderHandler
	 * @return
	 */
	public int generateOrderId() {
		synchronized(this){
			return theOrderId++;
		}
	}
	
	// Fields
	public static String InitStrategy = "InitStrategy"; // Open order tends to create dummy order
	public EClientSocket theClient;
	public enum Status {Init, PendingSubmit, PendingCancel, PreSubmitted, Submitted, Cancelled, Filled, Inactive, Error, Done};
	public Status theStatus = Status.Init;
	
	private Map<Integer, List<OrderManager>> theOrderIdToManagerMap = new HashMap<Integer, List<OrderManager>>();
	private Map<Integer, OrderListener> theOrderIdToListenerMap = new HashMap<Integer, OrderListener>();
	public Logger theLogger = (Logger) LogManager.getLogger(getClass().getName());
	private boolean theIsLaunchingSoundOn = 
			ConfigManager.parseConfig(OrderHandler.class, "launchingSoundOn", true);
	
	private MySqlHelper theMySqlHelper = null;
	private int theOrderId = 0;
	private String theHost = ConfigManager.parseConfig(getClass(), "host", "127.0.0.1");
	private int thePort = ConfigManager.parseConfig(getClass(), "port", 7496);
	private int theClientId = ConfigManager.parseConfig(getClass(), "clientid", 200);
	
		
}

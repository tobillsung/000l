package order;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

import product.ProductManager;

import com.ib.client.Contract;

public class SimOrderHandler extends OrderHandler{
	
	public SimOrderHandler() {
	}
	
	public void init() {
	}
	
	@Override
	public void run() {
		
		synchronized(this) {

			while (theStatus != Status.Done && theStatus != Status.Error) 
			{
				try {
					this.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			if (theStatus == Status.Done || theStatus == Status.Error) {
				theLogger.info("SimOrderHandler is close");
			}
		}
	}
	
	/**
	 * Sim does not put any data into MySql
	 */
	@Override
	public void insertOrderState(String aStrategyName) {
		// Do nothing.
	}
	
	/**
	 * Assume immediate execution
	 */
	@Override
	public void placeOrder(
			int aOrderId, String aStrategy, Contract aContract, 
			BaseOrder aOrder, OrderListener aOrderListener) {
		
		synchronized(this) {
			String mySymbol = ProductManager.getSymbolByContract(aContract);
			aOrder.m_orderId = aOrderId;
			
			// Since this is sim, get the current price
			
			double myAssumedFilledPrc = aOrder.m_placedPrice;
			theLogger.debug("Filled at {}", myAssumedFilledPrc);
			OrderManager myOM =	new OrderManager(aOrder.m_placeTime, 
					aStrategy, mySymbol, aOrder);
			myOM.filledPrice(myAssumedFilledPrc);
			aOrderListener.newOrderManager(myOM);
		}
		
	}
	
	
	// Fields
	public enum Status {Init, PendingSubmit, PendingCancel, PreSubmitted, Submitted, Cancelled, Filled, Inactive, Error, Done};
	public Status theStatus = Status.Init;
	
	public Logger theLogger = (Logger) LogManager.getLogger(getClass().getName());
		
}

package order;

import com.ib.client.Order;

public class BaseOrder extends Order{

	public BaseOrder() {
		
	}
	
	public long m_placeTime = 0l;
	public String m_descrption = null;
	public double m_placedPrice = 0;
	public double m_marketVolumeOnSide = 0;
}

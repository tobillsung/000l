package plot;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.renderer.xy.XYStepRenderer;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.util.ShapeUtilities;

public class DynamicXYPlot extends JFrame{
	
	private static final long serialVersionUID = 1L;

	public DynamicXYPlot(String aTitle, PlotType aPlotType, Date aInitDate, double[] aInitData) {
	
		super(aTitle);
		
		thePlotType = aPlotType;
		
		JFreeChart myChart = ChartFactory.createTimeSeriesChart(
				"", "Time", "Value", null, 
				true, true, false);
		
		
		final XYPlot myPlot = myChart.getXYPlot();
		myPlot.setDomainPannable(true);
		myPlot.setRangePannable(true);
		
		Millisecond myMillis = new Millisecond(aInitDate);
		switch(thePlotType)
		{
			case SpreadTrade:
				
				// Spread, ReqLong, ReqShort dataset
				TimeSeriesCollection myDatasetSpread = new TimeSeriesCollection();
				myDatasetSpread.addSeries(new TimeSeries("BuySpread"));
				myDatasetSpread.addSeries(new TimeSeries("SellSpread"));
				myDatasetSpread.addSeries(new TimeSeries("ReqLong"));
				myDatasetSpread.addSeries(new TimeSeries("ReqShort"));
				
				for (int i = 0 ; i < 4 ; i++) {// init
					myDatasetSpread.getSeries(i).add(myMillis, aInitData[i]);
					myDatasetSpread.getSeries(i).setMaximumItemCount(200000);
				}
				
				theDatasetMap.put("BuySpread", myDatasetSpread);
				theDatasetMap.put("SellSpread", myDatasetSpread);
				theDatasetMap.put("ReqLong", myDatasetSpread);
				theDatasetMap.put("ReqShort", myDatasetSpread);
				
				
				// Buy, sell dataset
				TimeSeriesCollection myDatasetSpreadTrade = new TimeSeriesCollection();
				myDatasetSpreadTrade.addSeries(new TimeSeries("Buy"));
				myDatasetSpreadTrade.addSeries(new TimeSeries("Sell"));
				
				for (int i = 0 ; i < 2 ; i++) {// init
					myDatasetSpreadTrade.getSeries(i).add(myMillis, aInitData[i + 4]);
					myDatasetSpreadTrade.getSeries(i).setMaximumItemCount(200000);
				}
				
				
				theDatasetMap.put("Buy", myDatasetSpreadTrade);
				theDatasetMap.put("Sell", myDatasetSpreadTrade);
				
				// Set dataset
				myPlot.setDataset(0, myDatasetSpread);
				myPlot.setDataset(1, myDatasetSpreadTrade);
				
				// Set renderer for each dataset
				// 1. Spread, ReqLong, ReqShort dataset
				XYStepRenderer myRendererSpread = new XYStepRenderer();
				myRendererSpread.setSeriesPaint(0, new Color(0, 0, 128));
				myRendererSpread.setSeriesPaint(1, new Color(176, 48, 96));
				myRendererSpread.setSeriesPaint(2, new Color(70, 130, 180));
				myRendererSpread.setSeriesPaint(3, new Color(219, 112, 147));
				
				myRendererSpread.setSeriesStroke(2, new BasicStroke(
			                2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,
			                1.0f, new float[] {2.0f, 6.0f}, 0.0f));
				myRendererSpread.setSeriesStroke(3, new BasicStroke(
			                2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,
			                1.0f, new float[] {2.0f, 6.0f}, 0.0f));
				myPlot.setRenderer(0, myRendererSpread);
				
				// Buy sell dataset
				XYLineAndShapeRenderer myRendererSpreadTrade = new XYLineAndShapeRenderer();
				myRendererSpreadTrade.setSeriesLinesVisible(0, false);
				myRendererSpreadTrade.setSeriesShape(0, ShapeUtilities.createDiamond(5));
				myRendererSpreadTrade.setSeriesPaint(0, new Color(34, 139, 34));
				
				myRendererSpreadTrade.setSeriesLinesVisible(1, false);
				myRendererSpreadTrade.setSeriesShape(1, ShapeUtilities.createDiagonalCross(5, 1));
				myRendererSpreadTrade.setSeriesPaint(1, new Color(255, 0, 0));
				
				myPlot.setRenderer(1, myRendererSpreadTrade);
				myPlot.getDomainAxis().setAutoRange(true);

				break;
				
			case Premium:
				
				// Premium
				TimeSeriesCollection myDatasetPremium = new TimeSeriesCollection();
				myDatasetPremium.addSeries(new TimeSeries("BuyPremium"));
				myDatasetPremium.addSeries(new TimeSeries("SellPremium"));
				myDatasetPremium.addSeries(new TimeSeries("Fitted"));
				
				for (int i = 0 ; i < 3 ; i++) {// init
					myDatasetPremium.getSeries(i).add(myMillis, aInitData[i]);
					myDatasetPremium.getSeries(i).setMaximumItemCount(200000);
				}
				
				theDatasetMap.put("BuyPremium", myDatasetPremium);
				theDatasetMap.put("SellPremium", myDatasetPremium);
				theDatasetMap.put("Fitted", myDatasetPremium);
				
				
				// Buy, sell dataset
				TimeSeriesCollection myDatasetPremiumTrade = new TimeSeriesCollection();
				myDatasetPremiumTrade.addSeries(new TimeSeries("Buy"));
				myDatasetPremiumTrade.addSeries(new TimeSeries("Sell"));
				
				for (int i = 0 ; i < 2 ; i++) {// init
					myDatasetPremiumTrade.getSeries(i).add(myMillis, aInitData[i + 3]);
					myDatasetPremiumTrade.getSeries(i).setMaximumItemCount(200000);
				}
				
				
				theDatasetMap.put("Buy", myDatasetPremiumTrade);
				theDatasetMap.put("Sell", myDatasetPremiumTrade);
				
				// Set dataset
				myPlot.setDataset(0, myDatasetPremium);
				myPlot.setDataset(1, myDatasetPremiumTrade);
				
				// Set renderer for each dataset
				// 1. BuyPremium, SellPremium, Fitted dataset
				XYStepRenderer myRendererPremium = new XYStepRenderer();
				myRendererPremium.setSeriesPaint(0, new Color(0, 0, 128));
				myRendererPremium.setSeriesPaint(1, new Color(176, 48, 96));
				myRendererPremium.setSeriesPaint(2, new Color(70, 130, 180));
				
				myRendererPremium.setSeriesStroke(2, new BasicStroke(
			                2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,
			                1.0f, new float[] {2.0f, 6.0f}, 0.0f));
				myPlot.setRenderer(0, myRendererPremium);
				
				// Buy sell dataset
				XYLineAndShapeRenderer myRendererPremiumTrade = new XYLineAndShapeRenderer();
				myRendererPremiumTrade.setSeriesLinesVisible(0, false);
				myRendererPremiumTrade.setSeriesShape(0, ShapeUtilities.createDiamond(5));
				myRendererPremiumTrade.setSeriesPaint(0, new Color(34, 139, 34));
				
				myRendererPremiumTrade.setSeriesLinesVisible(1, false);
				myRendererPremiumTrade.setSeriesShape(1, ShapeUtilities.createDiagonalCross(5, 1));
				myRendererPremiumTrade.setSeriesPaint(1, new Color(255, 0, 0));
				
				myPlot.setRenderer(1, myRendererPremiumTrade);
				myPlot.getDomainAxis().setAutoRange(true);
				
				break;
				
			case RetailState:
				
				// RetailState
				TimeSeriesCollection myDatasetRS = new TimeSeriesCollection();
				myDatasetRS.addSeries(new TimeSeries("BidP"));
				myDatasetRS.addSeries(new TimeSeries("AskP"));
				myDatasetRS.addSeries(new TimeSeries("NextTradeP"));
				
				for (int i = 0 ; i < 3 ; i++) {// init
					myDatasetRS.getSeries(i).add(myMillis, aInitData[i]);
					myDatasetRS.getSeries(i).setMaximumItemCount(200000);
				}
				
				theDatasetMap.put("BidP", myDatasetRS);
				theDatasetMap.put("AskP", myDatasetRS);
				theDatasetMap.put("NextTradeP", myDatasetRS);
				
				
				// Buy, sell dataset
				TimeSeriesCollection myDatasetRSTrade = new TimeSeriesCollection();
				myDatasetRSTrade.addSeries(new TimeSeries("Buy"));
				myDatasetRSTrade.addSeries(new TimeSeries("Sell"));
				
				for (int i = 0 ; i < 2 ; i++) {// init
					myDatasetRSTrade.getSeries(i).add(myMillis, aInitData[i + 3]);
					myDatasetRSTrade.getSeries(i).setMaximumItemCount(200000);
				}
				
				theDatasetMap.put("Buy", myDatasetRSTrade);
				theDatasetMap.put("Sell", myDatasetRSTrade);
				
				// Set dataset
				myPlot.setDataset(0, myDatasetRS);
				myPlot.setDataset(1, myDatasetRSTrade);
				
				// Set renderer for each dataset
				// 1. BidP, AskP, NextTradeP
				XYStepRenderer myRendererRS= new XYStepRenderer();
				myRendererRS.setSeriesPaint(0, new Color(0, 0, 128));
				myRendererRS.setSeriesPaint(1, new Color(176, 48, 96));
				myRendererRS.setSeriesPaint(2, new Color(70, 130, 180));
				
				myRendererRS.setSeriesStroke(2, new BasicStroke(
			                2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,
			                1.0f, new float[] {2.0f, 6.0f}, 0.0f));
				
				myPlot.setRenderer(0, myRendererRS);
				
				// Buy sell dataset
				XYLineAndShapeRenderer myRendererRSTrade = new XYLineAndShapeRenderer();
				myRendererRSTrade.setSeriesLinesVisible(0, false);
				myRendererRSTrade.setSeriesShape(0, ShapeUtilities.createDiamond(5));
				myRendererRSTrade.setSeriesPaint(0, new Color(34, 139, 34));
				
				myRendererRSTrade.setSeriesLinesVisible(1, false);
				myRendererRSTrade.setSeriesShape(1, ShapeUtilities.createDiagonalCross(5, 1));
				myRendererRSTrade.setSeriesPaint(1, new Color(255, 0, 0));
				
				myPlot.setRenderer(1, myRendererRSTrade);
				myPlot.getDomainAxis().setAutoRange(true);
				
				break;
			
		}
		
		ChartPanel chartPanel = new ChartPanel(myChart, false);
		chartPanel.setPreferredSize(new java.awt.Dimension(600, 370));
		chartPanel.setMouseZoomable(true, false);
		chartPanel.setMouseWheelEnabled(true);
		setContentPane(chartPanel);
		
	}
	
	public void addNewDataset(Date aDate, double[] aNewValue) {

		Millisecond myMillis = new Millisecond(aDate);
		
		switch(thePlotType)
		{
			case SpreadTrade:
				
				TimeSeriesCollection mySpreadSeriesCollection = theDatasetMap.get("BuySpread");
				for (int i = 0 ; i < 4 ; i++) {
					if (mySpreadSeriesCollection.getSeries(i).getDataItem(myMillis) == null) {
						mySpreadSeriesCollection.getSeries(i).addOrUpdate(myMillis, aNewValue[i]);
					} else {
						mySpreadSeriesCollection.getSeries(i).addOrUpdate(myMillis.next(), aNewValue[i]);
					}
				}
				
				TimeSeriesCollection mySpreadTradeSeriesCollection = theDatasetMap.get("Buy");
				if (aNewValue.length == 5) {
					if (mySpreadTradeSeriesCollection.getSeries(0).getDataItem(myMillis) == null) {
						mySpreadTradeSeriesCollection.getSeries(0).addOrUpdate(myMillis, aNewValue[4]);
					} else {
						mySpreadTradeSeriesCollection.getSeries(0).addOrUpdate(myMillis.next(), aNewValue[4]);
					}
				} else if (aNewValue.length == 6) {
					if (mySpreadTradeSeriesCollection.getSeries(1).getDataItem(myMillis) == null) {
						mySpreadTradeSeriesCollection.getSeries(1).addOrUpdate(myMillis, aNewValue[5]);
					} else {
						mySpreadTradeSeriesCollection.getSeries(1).addOrUpdate(myMillis.next(), aNewValue[5]);
					}
				}
				break;
				
			case Premium:
				TimeSeriesCollection myPremiumSeriesCollection = theDatasetMap.get("BuyPremium");
				for (int i = 0 ; i < 3 ; i++) {
					if (myPremiumSeriesCollection.getSeries(i).getDataItem(myMillis) == null) {
						myPremiumSeriesCollection.getSeries(i).addOrUpdate(myMillis, aNewValue[i]);
					} else {
						myPremiumSeriesCollection.getSeries(i).addOrUpdate(myMillis.next(), aNewValue[i]);
					}
				}
				
				TimeSeriesCollection myPremiumTradeSeriesCollection = theDatasetMap.get("Buy");
				if (aNewValue.length == 4) {
					if (myPremiumTradeSeriesCollection.getSeries(0).getDataItem(myMillis) == null) {
						myPremiumTradeSeriesCollection.getSeries(0).addOrUpdate(myMillis, aNewValue[3]);
					} else {
						myPremiumTradeSeriesCollection.getSeries(0).addOrUpdate(myMillis.next(), aNewValue[3]);
					}
				} else if (aNewValue.length == 5) {
					if (myPremiumTradeSeriesCollection.getSeries(1).getDataItem(myMillis) == null) {
						myPremiumTradeSeriesCollection.getSeries(1).addOrUpdate(myMillis, aNewValue[4]);
					} else {
						myPremiumTradeSeriesCollection.getSeries(1).addOrUpdate(myMillis.next(), aNewValue[4]);
					}
				}
				break;
				
			case RetailState:
				TimeSeriesCollection myRSSeriesCollection = theDatasetMap.get("BidP");
				
				for (int i = 0 ; i < 2 ; i++) {
					if (myRSSeriesCollection.getSeries(i).getDataItem(myMillis) == null) {
						myRSSeriesCollection.getSeries(i).addOrUpdate(myMillis, aNewValue[i]);
					} else {
						myRSSeriesCollection.getSeries(i).addOrUpdate(myMillis.next(), aNewValue[i]);
					}
				}
				
				if (aNewValue.length == 3) {
					if (myRSSeriesCollection.getSeries(2).getDataItem(myMillis) == null) {
						myRSSeriesCollection.getSeries(2).addOrUpdate(myMillis, aNewValue[2]);
					} else {
						myRSSeriesCollection.getSeries(2).addOrUpdate(myMillis.next(), aNewValue[2]);
					}
				}
				
				TimeSeriesCollection myRSTradeSeriesCollection = theDatasetMap.get("Buy");
				if (aNewValue.length == 4) {
					if (myRSTradeSeriesCollection.getSeries(0).getDataItem(myMillis) == null) {
						myRSTradeSeriesCollection.getSeries(0).addOrUpdate(myMillis, aNewValue[3]);
					} else {
						myRSTradeSeriesCollection.getSeries(0).addOrUpdate(myMillis.next(), aNewValue[3]);
					}
				} else if (aNewValue.length == 5) {
					if (myRSTradeSeriesCollection.getSeries(1).getDataItem(myMillis) == null) {
						myRSTradeSeriesCollection.getSeries(1).addOrUpdate(myMillis, aNewValue[4]);
					} else {
						myRSTradeSeriesCollection.getSeries(1).addOrUpdate(myMillis.next(), aNewValue[4]);
					}
				}
				break;
				
				
			default:
		}
	}
	
	public void init() {
		initToRelative(null);
	}
	
	public void initToRelative(Component aComp) {
		this.pack();
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		if (aComp != null) {
			this.setLocation(aComp.getX(), aComp.getY() + 25);
		} else {
			this.setLocationRelativeTo(aComp);
		}
        //RefineryUtilities.centerFrameOnScreen(this);
        this.setVisible(true);
        theStatus = Status.Running;
        this.addWindowListener(new WindowAdapter() {
        	@Override
            public void windowClosing(WindowEvent e) {
                int myConfirm = JOptionPane.showConfirmDialog(null, 
                		"Are you sure to close? All plot data would be removed", 
                		"Exit Confirmation", JOptionPane.YES_NO_OPTION);
                if (myConfirm == JOptionPane.YES_OPTION) {
                	dispose();
                	theStatus = Status.Disposed;
                }
            }
		});
		
	}
	
	public static enum Status {Running, Disposed}; 
	
	public static enum PlotType {SpreadTrade, Premium, RetailState};
	
	public Status theStatus;
	private PlotType thePlotType = null;
	
	private Map<String, TimeSeriesCollection> theDatasetMap = new HashMap<String, TimeSeriesCollection>();
}

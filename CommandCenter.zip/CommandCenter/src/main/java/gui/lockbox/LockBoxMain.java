package gui.lockbox;

import java.awt.BorderLayout;

import javax.swing.JFrame;

public class LockBoxMain extends JFrame {

	public LockBoxMain(String aName) {
		
		super(aName);
		
		this.pack();
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(600, 150);
	}
	
	public void init() {
		
		theLockBoxPanel.init();
		getContentPane().setLayout(new BorderLayout(0, 0));
		getContentPane().add(theLockBoxPanel, BorderLayout.CENTER);
	}

	
	
	public static void main(String[] args) {
		LockBoxMain myLockBoxMain = new LockBoxMain("LockBox");
		myLockBoxMain.init();
	}
	
	
	private static final long serialVersionUID = 1L;
	private LockBoxPanel theLockBoxPanel = new LockBoxPanel();
}

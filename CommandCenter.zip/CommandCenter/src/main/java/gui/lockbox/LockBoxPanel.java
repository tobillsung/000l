package gui.lockbox;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

public class LockBoxPanel extends JPanel implements ActionListener {

	public LockBoxPanel() {
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
	}
	
	
	public void init() {
		
		JPanel myCodePanel = new JPanel();
		myCodePanel.add(new JLabel("Code: "));
		myCodePanel.add(theCodeText);
		myCodePanel.add(thePassText);
		
		theRunBt.addActionListener(this);
		
		myCodePanel.add(theRunBt);
		this.add(myCodePanel, BorderLayout.CENTER);
		
		this.add(theLogText, BorderLayout.CENTER);
		
		
		//this.getRootPane().setDefaultButton(theRunBt);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == theRunBt) {			
			String myInputPass = new String(thePassText.getPassword());
			if (myInputPass.equals("lsmilel")) {
				String[] myCode = theCodeText.getText().split(" ");
				if (myCode.length == 2) {
					theLogText.setText(theLockMap.getVal(myCode[0]) + " " +
							theLockMap.getVal(myCode[1]));
				} else {
					theLogText.setText("Code is not in the right format");
				}
			} else {
				theLogText.setText("Pass is wrong");
			}
		}
		
	}
	
	
	private static final long serialVersionUID = 1L;
	private JTextField theCodeText = new JTextField(7);
	private JPasswordField thePassText = new JPasswordField(15);
	private JTextArea theLogText = new JTextArea();
	private JButton theRunBt = new JButton("Run");
	
	private LockMap theLockMap = new LockMap();
}

package gui.strategy;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

import util.ConfigManager;

public class SpreadTradePanel extends JPanel {
	
	public SpreadTradePanel() {
		
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
	}
	
	public void init() {
		
		// Menu bar
		JMenu myMenuFile = new JMenu("File");
		
		JMenuItem myMenuItemLoad = new JMenuItem("Load");
		myMenuItemLoad.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent aEvent) {
				
				JFileChooser myFileChooser = new JFileChooser();
				try {
					String myDirName = "gui/strategy/";
					myFileChooser.setCurrentDirectory(new java.io.File(SpreadTradePanel.class.getClassLoader().getResource(myDirName).toURI()));
					myFileChooser.setDialogTitle("Select config file");
					myFileChooser.setAcceptAllFileFilterUsed(false);
					myFileChooser.setMultiSelectionEnabled(false);
					myFileChooser.setFileFilter(new FileNameExtensionFilter("config file (*.conf)", "conf"));
					int returnVal = myFileChooser.showOpenDialog(null);

				    if (returnVal == JFileChooser.APPROVE_OPTION) {
				        String myCofigFileName = myDirName + myFileChooser.getSelectedFile().getName();
				        theLogger.info("Loading: " + myCofigFileName);
				        
				        theStatus = Status.Loading;
				        try {
				        	
				        	if (theSymbols != null) {
				        		for (int i = 0 ; i < theSymbols.length ; i++)
				        			theInputTableModel.removeRow(0);
				        	}
				        	
				        	theSymbols = ArrayUtils.addAll(theSymbols, ConfigManager.parseConfig(
					        		myCofigFileName, SpreadTradePanel.class, "symbol", null).replace(" ","").split(";"));
				        	theWeights = ArrayUtils.addAll(theWeights, ConfigManager.parseConfig(
					        		myCofigFileName, SpreadTradePanel.class, "weight", null).replace(" ","").split(";"));
				        	theVolume = ArrayUtils.addAll(theVolume, ConfigManager.parseConfig(
					        		myCofigFileName, SpreadTradePanel.class, "volume", null).replace(" ","").split(";"));
				        	theOrderType = ArrayUtils.addAll(theOrderType, ConfigManager.parseConfig(
					        		myCofigFileName, SpreadTradePanel.class, "orderType", null).replace(" ","").split(";"));
				        	theFitterSetting = ArrayUtils.addAll(theFitterSetting, ConfigManager.parseConfig(
					        		myCofigFileName, SpreadTradePanel.class, "fitter", null).replace(" ","").split(";"));
				        	thePositionAdjSetting = ArrayUtils.addAll(thePositionAdjSetting, ConfigManager.parseConfig(
					        		myCofigFileName, SpreadTradePanel.class, "positionAdj", null).replace(" ","").split(";"));
					        
				        } catch (Exception e) {
				        	e.printStackTrace();
				        }

				        insertToInputTable();
				        
				        theStatus = Status.Ready;
				    } else {
				    	theLogger.info("Load is cancelled");
				    }
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		});
		myMenuFile.add(myMenuItemLoad);
		
		JMenuItem myMenuItemSave = new JMenuItem("Save");
		myMenuItemSave.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent aEvent) {
				
				JFileChooser myFileChooser = new JFileChooser();
				try {
					String myDirName = "gui/strategy/";
					myFileChooser.setCurrentDirectory(new java.io.File(SpreadTradePanel.class.getClassLoader().getResource(myDirName).toURI()));
					myFileChooser.setDialogTitle("Save config file");
					myFileChooser.setAcceptAllFileFilterUsed(false);
					myFileChooser.setMultiSelectionEnabled(false);
					myFileChooser.setFileFilter(new FileNameExtensionFilter("config file (*.conf)", "conf"));
					int returnVal = myFileChooser.showSaveDialog(null);

				    if (returnVal == JFileChooser.APPROVE_OPTION) {
				        String myCofigFileName = myDirName + myFileChooser.getSelectedFile().getName();
				        theLogger.info("Saved: " + myCofigFileName);
				        
				        theStatus = Status.Saved;
				        try {
				        	
				        	if (theSymbols != null) {
				        		
				        		FileWriter myFileWriter = new FileWriter(myFileChooser.getSelectedFile() + ".config");
				        		
				        		//myFileWriter.write(sb.toString());
				        	}
				        		
				        	for (int i = 0 ; i < theSymbols.length ; i++) {

				        	}
				        		
				        	
					        
				        } catch (Exception e) {
				        	e.printStackTrace();
				        }

				        insertToInputTable();
				        
				    } else {
				    	theLogger.info("Load is cancelled");
				    }
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		});
		myMenuFile.add(myMenuItemSave);
		
		JMenuBar myMenubar = new JMenuBar();
		myMenubar.add(myMenuFile);
		myMenubar.setAlignmentX(Component.LEFT_ALIGNMENT);
		this.add(myMenubar);
		this.add(Box.createRigidArea(new Dimension(0,5)));
		
		// Spread Trade Input table
		theInputTableModel = new InputTableModel();
		theInputTableModel.addColumn(InputColumn.Symbols.name());
		theInputTableModel.addColumn(InputColumn.Weights.name());
		theInputTableModel.addColumn(InputColumn.Volume.name());
		theInputTableModel.addColumn(InputColumn.PlotSpread.name());
		theInputTableModel.addColumn(InputColumn.OrderType.name());
		theInputTableModel.addColumn(InputColumn.Status.name());

		theInputTable = new JTable(theInputTableModel);
		
		// Combo box for column OrderType
		JComboBox<String> myOrderTypeComboBox = new JComboBox<String>();
		myOrderTypeComboBox.addItem("Limit");
		myOrderTypeComboBox.addItem("Market");
		
		DefaultTableCellRenderer myCellRendererOrderType  = 
				new DefaultTableCellRenderer();
		myCellRendererOrderType.setToolTipText("Click for order type");
		theInputTable.getColumnModel().getColumn(InputColumn.OrderType.val()).setCellRenderer(myCellRendererOrderType);
		theInputTable.getColumnModel().getColumn(InputColumn.OrderType.val()).setCellEditor(new DefaultCellEditor(myOrderTypeComboBox));
		// Combo box for column Status
		JComboBox<String> myStatusComboBox = new JComboBox<String>();		
		myStatusComboBox.addItem("Ready");
		myStatusComboBox.addItem("Running");
		myStatusComboBox.addItem("Error");
		myStatusComboBox.setEditable(false);
		
		DefaultTableCellRenderer myStatusCellRenderer  = 
				new DefaultTableCellRenderer() {

					private static final long serialVersionUID = 1L;
			
					public Component getTableCellRendererComponent(JTable table, Object value,
				            boolean isSelected, boolean hasFocus, int rowIndex, int vColIndex) {
				        String myValue = (String) value;
				        // Set the colors as per the value in the cell...
				        if (myValue.equals("Ready")) {
				        	setBackground(Color.lightGray);
				            setToolTipText("Ready");
				        } else if (myValue.equals("Running")) {
				            setBackground(Color.GREEN);
				            setToolTipText("Running");
				        } else if (myValue.equals("Error")) {
				            setBackground(Color.RED);
				            setToolTipText("Error");
				        }
				        return this;
				    }
			
		};
		
		myStatusCellRenderer.setToolTipText(myStatusComboBox.getSelectedItem().toString());
		theInputTable.getColumnModel().getColumn(InputColumn.Status.val()).setCellRenderer(myStatusCellRenderer);
		theInputTable.getColumnModel().getColumn(InputColumn.Status.val()).setCellEditor(new DefaultCellEditor(myStatusComboBox));

		JScrollPane myInputTableScrollPanel = new JScrollPane(theInputTable);
		theInputTable.setFillsViewportHeight(true);
		
		theInputTable.getModel().addTableModelListener(new TableModelListener() {
			
			@Override
			public void tableChanged(TableModelEvent aEvent) {
				if (theStatus != Status.Loading) {
					highlightForSave();
				}
			}
		});
		
		theInputTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent aEvent) {
				
				if (! aEvent.getValueIsAdjusting()) {
					try {
						// Update fitter setting
						String[] myFitterSetting = theFitterSetting[theInputTable.getSelectedRow()].split(",");
						theHalflifeText.setText(myFitterSetting[0]);
						theInitFitTimeText.setText(myFitterSetting[1]);

						// Update positionadj setting
						String[] myPositionAdjSetting = thePositionAdjSetting[theInputTable.getSelectedRow()].split(",");
						theMinProfitText.setText(myPositionAdjSetting[0]);
						theAdjustmentText.setText(myPositionAdjSetting[1]);
						theMaxPosText.setText(myPositionAdjSetting[2]);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
					
			}
		});

		myInputTableScrollPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		this.add(myInputTableScrollPanel);
		this.add(Box.createRigidArea(new Dimension(0,5)));
		
		// Fitter panel
		JLabel myHalflifeLabel = new JLabel("Halflife (s)");
		JLabel myInitFitLabel = new JLabel("InitFitTime (s)");
		theHalflifeText.addActionListener(new TextValueChanged());
		theInitFitTimeText.addActionListener(new TextValueChanged());
		theFitterPanel.setLayout(new GridLayout(2, 2));
		theFitterPanel.add(myHalflifeLabel);
		theFitterPanel.add(theHalflifeText);
		theFitterPanel.add(myInitFitLabel);
		theFitterPanel.add(theInitFitTimeText);
		
		theFitterPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		
		theFitterPanel.setBorder(
				BorderFactory.createTitledBorder(
						BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "Fitter"));
		this.add(theFitterPanel);
		this.add(Box.createRigidArea(new Dimension(0,5)));
		
		// Position Adjustment
		JLabel myMinProfitLabel = new JLabel("MinProfit ($)");
		JLabel myAdjustmentLabel = new JLabel("Adjustment ($)");
		JLabel myMaxPosLabel = new JLabel("MaxPos");
		
		theMinProfitText.addActionListener(new TextValueChanged());
		theAdjustmentText.addActionListener(new TextValueChanged());
		theMaxPosText.addActionListener(new TextValueChanged());

		thePositionAdjPanel.setLayout(new GridLayout(3, 2));
		thePositionAdjPanel.add(myMinProfitLabel);
		thePositionAdjPanel.add(theMinProfitText);
		thePositionAdjPanel.add(myAdjustmentLabel);
		thePositionAdjPanel.add(theAdjustmentText);
		thePositionAdjPanel.add(myMaxPosLabel);
		thePositionAdjPanel.add(theMaxPosText);
		
		thePositionAdjPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		
		thePositionAdjPanel.setBorder(
				BorderFactory.createTitledBorder(
						BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "PositionAdj"));
		this.add(thePositionAdjPanel);
		this.add(Box.createRigidArea(new Dimension(0,5)));
		
		// Highlight panel
		theHighlightPanel = new JPanel();
		JLabel myHighLightLabel = new JLabel("");
		myHighLightLabel.setAlignmentX(CENTER_ALIGNMENT);
		myHighLightLabel.setFont(new Font("Arial", Font.PLAIN, 10));
		myHighLightLabel.setForeground(Color.BLUE);
		theHighlightPanel.add(myHighLightLabel);
		theHighlightPanel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
		theHighlightPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		this.add(theHighlightPanel);
		// Run button
		JButton myRunButton = new JButton("Run");
		this.add(myRunButton);
		myRunButton.setAlignmentX(Component.LEFT_ALIGNMENT);
	}
	
	
	
	public class InputTableModel extends DefaultTableModel {

		private static final long serialVersionUID = 1L;

		public Class<?> getColumnClass(int c) {
			return getValueAt(0, c).getClass();
		}
	}
	
	public class TextValueChanged implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			if (theStatus != Status.Loading) {
				
				int myIdx = theInputTable.getSelectedRow();
				
				if (e.getSource() == theHalflifeText) {
					String[] myFitterSetting = theFitterSetting[myIdx].split(",");
					myFitterSetting[0] = theHalflifeText.getText().replace(" ", "");
					theFitterSetting[myIdx] = StringUtils.join(myFitterSetting, ",");
					highlightForSave();
				}  else if (e.getSource() == theInitFitTimeText) {
					String[] myFitterSetting = theFitterSetting[myIdx].split(",");
					myFitterSetting[1] = theHalflifeText.getText().replace(" ", "");
					theFitterSetting[myIdx] = StringUtils.join(myFitterSetting, ",");
					highlightForSave();
				} else if (e.getSource() == theMinProfitText) {
					String[] myPositionAdjSetting = thePositionAdjSetting[myIdx].split(",");
					myPositionAdjSetting[0] = theHalflifeText.getText().replace(" ", "");
					thePositionAdjSetting[myIdx] = StringUtils.join(myPositionAdjSetting, ",");
					highlightForSave();
				} else if (e.getSource() == theAdjustmentText) {
					String[] myPositionAdjSetting = thePositionAdjSetting[myIdx].split(",");
					myPositionAdjSetting[1] = theHalflifeText.getText().replace(" ", "");
					thePositionAdjSetting[myIdx] = StringUtils.join(myPositionAdjSetting, ",");
					highlightForSave();
				} else if (e.getSource() == theMaxPosText) {
					String[] myPositionAdjSetting = thePositionAdjSetting[myIdx].split(",");
					myPositionAdjSetting[2] = theHalflifeText.getText().replace(" ", "");
					thePositionAdjSetting[myIdx] = StringUtils.join(myPositionAdjSetting, ",");
					highlightForSave();
				} 
			}
		}
	}
	
	
	private void insertToInputTable() {
		if (theSymbols != null) {
			
			for (int i = 0 ; i < theSymbols.length ; i++) {
				theInputTableModel.insertRow(i, 
						new Object[] {theSymbols[i], theWeights[i], theVolume[i], new Boolean(false), 
						theOrderType[i], "Ready"});
			}
			theStatus = Status.Ready;
			theInputTable.setRowSelectionInterval(0, 0);
		}
	}
	
	private void highlightForSave() {
		
		JLabel myHighlightLabel = (JLabel) theHighlightPanel.getComponent(0);
		if (theStatus == Status.Saved) {
			myHighlightLabel.setText("File saved");
			theHighlightPanel.setBackground(new Color(176, 196, 222));
			theStatus = Status.Ready;
		} else {
			myHighlightLabel.setText("Input is changed. File > Save");
			theHighlightPanel.setBackground(Color.YELLOW);
		}
		
	}
	
	private enum InputColumn { 
		Symbols(0), Weights(1), Volume(2), PlotSpread(3), OrderType(4), Status(5);
		
		private InputColumn(int aVal) {
			theVal = aVal;
		}
		
		public int val() {
			return theVal;
		}
		
		private int theVal;
		
	}
	
	private JTable theInputTable;
	private DefaultTableModel theInputTableModel;
	private JPanel theFitterPanel = new JPanel();;
	private JTextField theHalflifeText = new JTextField();
	private JTextField theInitFitTimeText = new JTextField();
	private JPanel thePositionAdjPanel = new JPanel();;
	private JTextField theMinProfitText = new JTextField();
	private JTextField theAdjustmentText = new JTextField();
	private JTextField theMaxPosText = new JTextField();
	
	private JPanel theHighlightPanel;
	
	private String[] theSymbols = null;
	private String[] theWeights = null;
	private String[] theVolume = null;
	private String[] theOrderType = null;
	private String[] theFitterSetting = null;
	private String[] thePositionAdjSetting = null;
	private enum Status {Init, Loading, Saved, Ready}; 

	private Status theStatus = Status.Init;
	private static final long serialVersionUID = 1L;
	
	private Logger theLogger = (Logger) LogManager.getLogger();

}

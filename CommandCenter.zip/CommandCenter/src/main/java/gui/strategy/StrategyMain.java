package gui.strategy;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;

public class StrategyMain extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public StrategyMain(String aTitle) {
		super(aTitle);
		getContentPane().setLayout(new BorderLayout(0, 0));
		
		JTabbedPane theStrategyTabbedPane = new JTabbedPane(JTabbedPane.TOP);
		getContentPane().add(theStrategyTabbedPane, BorderLayout.CENTER);
		
		
		// Add Spread Trade panel
		SpreadTradePanel mySTPanel = new SpreadTradePanel();
		mySTPanel.init();
		
		theStrategyTabbedPane.addTab("SpreadTrade", null, mySTPanel, null);
		
		this.pack();
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}
	
	
	
	public static void main(String[] args) {
		new StrategyMain("Strategy");
	}
	
}

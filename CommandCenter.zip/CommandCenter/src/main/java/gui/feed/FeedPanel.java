package gui.feed;

public class FeedPanel {
	
	public FeedPanel(){
		
	}
	
	public void temp() {
		/*
		theInputTable = new JTable(myInputTableModel) {

			private static final long serialVersionUID = 1L;

			@Override
	        public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
	            Component c = super.prepareRenderer(renderer, row, column);
	            if (!isRowSelected(row)) { //  Alternate row color
	                c.setBackground(row % 2 == 0 ? getBackground() : Color.LIGHT_GRAY);
	            }
	            return c;
	        }
		};
		*/
	}

}

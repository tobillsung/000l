package gui.controller;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractCellEditor;
import javax.swing.BoxLayout;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;

import org.apache.commons.collections.BidiMap;
import org.apache.commons.collections.bidimap.DualHashBidiMap;

import strategy.AbstractStrategy;
import strategy.PositionAdj;

public class ControllerTablePanel extends JPanel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ControllerTablePanel() {
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
	}
	
	public void init() {
		theControllerTableModel.addColumn("<html>Strategy<br>Name");
		theControllerTableModel.addColumn("Pos");
		theControllerTableModel.addColumn("ReqProfit");
		theControllerTableModel.addColumn("<html>Manual<br>Trade");
		theControllerTableModel.addColumn("Status");
		
		theControllerTable = new JTable(theControllerTableModel);
		theControllerTable.setFillsViewportHeight(true);
		
		// Pos column
		theControllerTable.getColumnModel().getColumn(1).setPreferredWidth(5);
		
		// ReqProfit column
		theControllerTable.getColumnModel().getColumn(2).setCellEditor(new ReqProfitAdjuster());
		
		// ManualTrade column 
		final JComboBox<String> myManualTradeComboBox = new JComboBox<String>();
		myManualTradeComboBox.addItem("");
		myManualTradeComboBox.addItem("CloseOut");
		myManualTradeComboBox.addItem("Buy");
		myManualTradeComboBox.addItem("Sell");
		myManualTradeComboBox.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == myManualTradeComboBox) {

					int myRowN = theControllerTable.getSelectedRow();
					AbstractStrategy myStrategy = (AbstractStrategy) theStrategyIdxMap.inverseBidiMap().get(myRowN);
					int mySelectedIdx = myManualTradeComboBox.getSelectedIndex();
					switch (mySelectedIdx) {
					case 1:
						int myCurrPos = (Integer) theControllerTable.getValueAt(myRowN, 1);
						myStrategy.placeManualOrder(-myCurrPos);
						break;
					case 2:
						myStrategy.placeManualOrder(1);
						break;
					case 3:
						myStrategy.placeManualOrder(-1);
						break;
					}
				}
			}

		});
		theControllerTable.getColumnModel().getColumn(3).setCellEditor(new DefaultCellEditor(myManualTradeComboBox));
		
		// Status column
		final JComboBox<String> myStatusComboBox = new JComboBox<String>();
		myStatusComboBox.addItem(AbstractStrategy.Status.Init.name());
		myStatusComboBox.addItem(AbstractStrategy.Status.Running.name());
		myStatusComboBox.addItem(AbstractStrategy.Status.Pause.name());
		myStatusComboBox.addItem(AbstractStrategy.Status.FinalTrade.name());
		myStatusComboBox.addItem(AbstractStrategy.Status.Done.name());
		myStatusComboBox.addItem(AbstractStrategy.Status.Error.name());
		
		myStatusComboBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == myStatusComboBox) {
					int myRowN = theControllerTable.getSelectedRow();
					if (myRowN == -1) {
						return;
					}
					AbstractStrategy myStrategy = (AbstractStrategy) theStrategyIdxMap.inverseBidiMap().get(myRowN);
					synchronized (myStrategy) {
						myStrategy.setStatus(
								AbstractStrategy.Status.valueOf((String)myStatusComboBox.getSelectedItem()));
						myStrategy.notify();
					}
				}
				
			}
		});
		theControllerTable.getColumnModel().getColumn(4).setCellEditor(new DefaultCellEditor(myStatusComboBox));
		
		JScrollPane myTableScrollPanel = new JScrollPane(theControllerTable);
		myTableScrollPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		
		this.add(myTableScrollPanel, BorderLayout.CENTER);
	}
	
	public void updateItem(AbstractStrategy aStrategy) {
		
		synchronized (this) {
			int myInsertRow = 0;
			
			String myStrategyName = aStrategy.getStrategyName();
			int myCumulativePos = aStrategy.getCumulativePos();
			PositionAdj.Profit myProfit = aStrategy.thePositionAdj.getReqProfit();
			String myProfitStr = myProfit.reqLong() + "," + myProfit.reqShort();
			String myStatusStr = aStrategy.theStatus.name();
			
			if (! theStrategyIdxMap.containsKey(aStrategy)) {
				myInsertRow = theStrategyIdxMap.entrySet().size();
				theStrategyIdxMap.put(aStrategy, myInsertRow);
				
				theControllerTableModel.insertRow(myInsertRow, 
						new Object[] {myStrategyName, myCumulativePos, myProfitStr,
						"", myStatusStr});
				
			} else {
				myInsertRow = (Integer) theStrategyIdxMap.get(aStrategy);
				
				theControllerTableModel.setValueAt(myCumulativePos, myInsertRow, 1);
				theControllerTableModel.setValueAt(myProfitStr, myInsertRow, 2);
				theControllerTableModel.setValueAt("", myInsertRow, 3);
				theControllerTableModel.setValueAt(myStatusStr, myInsertRow, 4);
			}
		}
	}
		
	
	public class ControllerTableModel extends DefaultTableModel {

		private static final long serialVersionUID = 1L;

		public Class<?> getColumnClass(int c) {
			return getValueAt(0, c).getClass();
		}
		
	}

	
	public class ReqProfitAdjuster extends AbstractCellEditor implements TableCellEditor, ActionListener {
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		JButton button;
		JDialog dialog;
		String theProfitStr;
		protected static final String EDIT = "edit";

		public ReqProfitAdjuster() {
			button = new JButton();
			button.setActionCommand(EDIT);
			button.addActionListener(this);
			button.setBorderPainted(false);
		}

		public void actionPerformed(ActionEvent e) {
			if (EDIT.equals(e.getActionCommand())) {
				//The user has clicked the cell, so
				//bring up the dialog.
				
				String myNewReqProfit = (String)JOptionPane.showInputDialog(null, "ReqLongProfit, ReqShortProtfit",
				                    "Set required profit",JOptionPane.PLAIN_MESSAGE);

				//If a string was returned, say so.
				if ((myNewReqProfit != null) && (myNewReqProfit.length() > 0)) {
					
					try {
						String[] mySplit = myNewReqProfit.trim().split("\\s*,\\s*");
						theProfitStr = mySplit[0] + ","+ mySplit[1];
						int mySelectedRow = theControllerTable.getSelectedRow();
						AbstractStrategy myStrategy = 
								(AbstractStrategy) theStrategyIdxMap.inverseBidiMap().get(mySelectedRow);
						myStrategy.manuallyUpdateReqProfit(Double.valueOf(mySplit[0]), Double.valueOf(mySplit[1]));
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				}
				fireEditingStopped(); //Make the renderer reappear.
			} 
		}

		//Implement the one method defined by TableCellEditor.
		public Component getTableCellEditorComponent(JTable table,
				Object value,
				boolean isSelected,
				int row,
				int column) {
			theProfitStr = (String) value;
			return button;
		}

		@Override
		public Object getCellEditorValue() {
			return theProfitStr;
		}
	}
	
	private DefaultTableModel theControllerTableModel = new ControllerTableModel();
	private BidiMap theStrategyIdxMap = new DualHashBidiMap();
	private JTable theControllerTable;
	
}

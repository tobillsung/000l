package gui.controller;

import java.awt.BorderLayout;

import javax.swing.JFrame;

import strategy.AbstractStrategy;
import control.ControllerListener;

public class ControllerMain extends JFrame implements ControllerListener{

	public ControllerMain(String aName) {
		super(aName);
		
		this.init();
		
		this.pack();
		this.setLocation(0, 175);
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(600, 150);
	}
	
	public void init() {
		theControllerTable = new ControllerTablePanel();
		theControllerTable.init();
		getContentPane().setLayout(new BorderLayout(0, 0));
		getContentPane().add(theControllerTable, BorderLayout.CENTER);
	}
	
	@Override
	public void updateItem(AbstractStrategy aStrategy) {
		theControllerTable.updateItem(aStrategy);
	}
	
		
	private static final long serialVersionUID = 1L;
	private ControllerTablePanel theControllerTable;
	
	
}

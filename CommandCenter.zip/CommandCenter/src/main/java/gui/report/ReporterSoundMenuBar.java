package gui.report;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ReporterSoundMenuBar extends JMenuBar implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ReporterSoundMenuBar() {
	}

	public void init(boolean aSoundOn) {
		theSoundOn = aSoundOn;
		// Menu bar
		JMenu myMenu = new JMenu("Sound");
		theMenuItemSetting.addActionListener(this);
		myMenu.add(theMenuItemSetting);
		
		theMenuItemMute.addActionListener(this);
		myMenu.add(theMenuItemMute);
		
		this.add(myMenu);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
		if (e.getSource() == theMenuItemMute && theMenuItemMute.getState()) {
			System.out.println("sound is off");
			theSoundOn = false;
		} else if (e.getSource() == theMenuItemSetting) {
			
			if (theSoundSettingPanel == null) {
				theSoundSettingPanel = new JPanel();
				
				JTextField myTradeSoundField = new JTextField(5);
				myTradeSoundField.setText(String.valueOf(thePerTradeSound));
				
				JTextField myProfitSoundField = new JTextField(5);
				myProfitSoundField.setText(String.valueOf(thePerProfitSound));
				
				JTextField myLossSoundField = new JTextField(5);
				myLossSoundField.setText(String.valueOf(thePerLossSound));
				
				theSoundSettingPanel.add(new JLabel("Trade: "));
				theSoundSettingPanel.add(myTradeSoundField);
				theSoundSettingPanel.add(Box.createHorizontalStrut(15)); // a spacer
				
				theSoundSettingPanel.add(new JLabel("Profit: "));
				theSoundSettingPanel.add(myProfitSoundField);
				theSoundSettingPanel.add(Box.createHorizontalStrut(15)); // a spacer
				
				theSoundSettingPanel.add(new JLabel("Loss: "));
				theSoundSettingPanel.add(myLossSoundField);
			}
			
			int myResult = JOptionPane.showConfirmDialog(null, theSoundSettingPanel, 
					"Please Enter sound configuration", JOptionPane.OK_CANCEL_OPTION);
			if (myResult == JOptionPane.OK_OPTION) {
				thePerTradeSound = Integer.valueOf("profit value: " + ((JTextField) theSoundSettingPanel.getComponent(1)).getText());
				thePerProfitSound = Integer.valueOf(((JTextField) theSoundSettingPanel.getComponent(4)).getText());
				thePerLossSound = Integer.valueOf(((JTextField) theSoundSettingPanel.getComponent(7)).getText());
			}

		}
	}
	
	public boolean theSoundOn = true;
	public int thePerProfitSound = 50; // In $ term
	public int thePerTradeSound = 4;  // count 
	public int thePerLossSound = - 50; // In $ term
	
	private JMenuItem theMenuItemSetting = new JMenuItem("Setting");
	private JCheckBoxMenuItem theMenuItemMute = new JCheckBoxMenuItem("Mute");
	
	private JPanel theSoundSettingPanel = null;
	
	
	

}

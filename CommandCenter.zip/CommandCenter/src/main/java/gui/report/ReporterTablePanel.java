package gui.report;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import org.apache.commons.collections.BidiMap;
import org.apache.commons.collections.bidimap.DualHashBidiMap;

import report.Reporter.Summary;
import sound.SoundDrive;
import strategy.AbstractStrategy;

public class ReporterTablePanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ReporterTablePanel(ReporterSoundMenuBar aReporterSoundMenuBar) {
		theSoundMenuBar = aReporterSoundMenuBar;
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
	}
	
	public void init() {
		
		theReporterTableModel.addColumn("<html>Strategy<br>Name");
		theReporterTableModel.addColumn("Pos");
		theReporterTableModel.addColumn("BuyN");
		theReporterTableModel.addColumn("SellN");
		theReporterTableModel.addColumn("FlatPnL");
		theReporterTableModel.addColumn("Fee");
		theReporterTableModel.addColumn("<html>FlatPnL<br>WithFee");

		theReporterTable = new JTable(theReporterTableModel);
		theReporterTable.setFillsViewportHeight(true);
		
		
		// Set cell renderer
		theReporterTable.getColumnModel().getColumn(4).setCellRenderer(new PnLCellRenderer());
		theReporterTable.getColumnModel().getColumn(5).setCellRenderer(new FeeCellRenderer());
		theReporterTable.getColumnModel().getColumn(6).setCellRenderer(new PnLCellRenderer());
		
		// Set the column width
		for (int i = 1 ; i <= 3 ; i++) {
			theReporterTable.getColumnModel().getColumn(i).setPreferredWidth(5);
		}
		
		JScrollPane myTableScrollPanel = new JScrollPane(theReporterTable);
		myTableScrollPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		
		this.add(myTableScrollPanel, BorderLayout.CENTER);
	}

	public void newRecord(AbstractStrategy aStrategy, Summary aSummary) {
		
		int myCumulativePos = aSummary.theCumulativePos;
		int myCumulativeBuyN = aSummary.theCumulativeBuyN;
		int myCumulativeSellN = aSummary.theCumulativeSellN;
		double myCumulativeFee = aSummary.theCumulativeFee;
		double myCumulativeFlatPnL = aSummary.theCumulativeFlatPnL;
		double myCumulativeFlatPnLWithFee = myCumulativeFlatPnL - myCumulativeFee;
		
		synchronized (this) {
			int myInsertRow = 0;
			if (! theStrategyIdxMap.containsKey(aStrategy)) {
				myInsertRow = theStrategyIdxMap.entrySet().size();
				theStrategyIdxMap.put(aStrategy, myInsertRow);

				theReporterTableModel.insertRow(myInsertRow, 
						new Object[] {aStrategy.getStrategyName(), myCumulativePos, myCumulativeBuyN, myCumulativeSellN, 
						myCumulativeFlatPnL, -myCumulativeFee, myCumulativeFlatPnLWithFee});

			} else {
				myInsertRow = (Integer) theStrategyIdxMap.get(aStrategy);

				theReporterTableModel.setValueAt(myCumulativePos, myInsertRow, 1);
				theReporterTableModel.setValueAt(myCumulativeBuyN, myInsertRow, 2);
				theReporterTableModel.setValueAt(myCumulativeSellN, myInsertRow, 3);
				theReporterTableModel.setValueAt(myCumulativeFlatPnL, myInsertRow, 4);
				theReporterTableModel.setValueAt(-myCumulativeFee, myInsertRow, 5);
				theReporterTableModel.setValueAt(myCumulativeFlatPnLWithFee, myInsertRow, 6);
			}
		}
		// Init state
		if (myCumulativePos == 0 && myCumulativeBuyN == 0 && myCumulativeSellN == 0)
			return;
		
		if (theSoundMenuBar.theSoundOn) {
			
			List<String> mySoundFileList = new ArrayList<String>();
			
			mySoundFileList.add("sounddrive/execution/Cash.wav");
						
			int myTotalTrade = myCumulativeBuyN + myCumulativeSellN;
			if (myTotalTrade % theSoundMenuBar.thePerTradeSound == 0) {
				mySoundFileList.add("sounddrive/execution/Yes_LetsBurn.wav");
			}
			
			if (myCumulativeFlatPnLWithFee >= theSoundMenuBar.thePerProfitSound) {
				theSoundMenuBar.thePerProfitSound = theSoundMenuBar.thePerProfitSound * 2;
				mySoundFileList.add("sounddrive/pnl/Profit_1.wav");
			}
			
			if (myCumulativeFlatPnLWithFee <= theSoundMenuBar.thePerLossSound) {
				theSoundMenuBar.thePerLossSound = theSoundMenuBar.thePerLossSound * 2;
				mySoundFileList.add("sounddrive/pnl/Loss_0.wav");
			}
			theSD.setAudioFile(mySoundFileList.toArray(new String[mySoundFileList.size()]));
			
			new Thread(theSD).start();
		}
		
	}
	
	public class ReporterTableModel extends DefaultTableModel {

		private static final long serialVersionUID = 1L;

		public Class<?> getColumnClass(int c) {
			return getValueAt(0, c).getClass();
		}
	}
	
	public class PnLCellRenderer extends DefaultTableCellRenderer {

		private static final long serialVersionUID = 1L;
		
		@Override
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int col) {
			
			if ((Double) value >= 0) {
				setForeground(new Color(34, 139, 34));
			} else {
				setForeground(new Color(255, 0, 0));
			}
			setHorizontalAlignment(JLabel.RIGHT);
			value = new DecimalFormat( "#.##" ).format((Number)value);
			return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
		}
	}
	
	public class FeeCellRenderer extends DefaultTableCellRenderer {

		private static final long serialVersionUID = 1L;
		
		@Override
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int col) {
			setForeground(new Color(255, 0, 0));
			setHorizontalAlignment(JLabel.RIGHT);
			value = new DecimalFormat( "#.##" ).format((Number)value);
			return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
		}
	}
	
	private ReporterSoundMenuBar theSoundMenuBar;
	private SoundDrive theSD = new SoundDrive();
	private BidiMap theStrategyIdxMap = new DualHashBidiMap();
	private DefaultTableModel theReporterTableModel = new ReporterTableModel();
	private JTable theReporterTable;
}

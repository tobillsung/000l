package gui.report;

import java.awt.BorderLayout;

import javax.swing.JFrame;

import report.Reporter.Summary;
import report.ReporterListener;
import strategy.AbstractStrategy;

public class ReporterMain extends JFrame implements ReporterListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ReporterMain(String aName, boolean aSoundOn) {
		super(aName);
		this.init(aSoundOn);
		
		this.pack();
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(600, 150);
	}
	
	public void init(boolean aSoundOn) {
		
		theReporterSoundMenuBar = new ReporterSoundMenuBar();
		theReporterSoundMenuBar.init(aSoundOn);
		this.setJMenuBar(theReporterSoundMenuBar);
		
		theReporterTable = new ReporterTablePanel(theReporterSoundMenuBar);
		theReporterTable.init();
		getContentPane().setLayout(new BorderLayout(0, 0));
		getContentPane().add(theReporterTable, BorderLayout.CENTER);
	}
	
	
	public static void main(String[] args) {
		new ReporterMain("Reporter", true);
	}

	@Override
	public void newRecord(AbstractStrategy aStrategy, Summary aSummary) {
		theReporterTable.newRecord(aStrategy, aSummary);
	}
	
	private ReporterSoundMenuBar theReporterSoundMenuBar;
	private ReporterTablePanel theReporterTable;
	
}

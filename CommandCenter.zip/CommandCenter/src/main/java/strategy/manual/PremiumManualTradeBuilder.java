package strategy.manual;

import com.ib.client.Contract;

public class PremiumManualTradeBuilder {
	public PremiumManualTradeBuilder() {
	}
	
	public PremiumManualTradeBuilder contract(Contract[] aContract) {
		theContract = aContract;
		return this;
	}
	
	public PremiumManualTradeBuilder weight(double[] aWeights) {
		theWeight = aWeights;
		return this;
	}
	
	public PremiumManualTradeBuilder volumePerTrade(int aVolumePerTrade) {
		theVolumePerTrade = aVolumePerTrade;
		return this;
	}
	
	public PremiumManualTradeBuilder minMarketVolume(int[] aMinMarketValume) {
		theMinMarketVolume = aMinMarketValume;
		return this;
	}
	
	public PremiumManualTrade build () throws Exception{
		return new PremiumManualTrade(theContract, theWeight, theVolumePerTrade, theMinMarketVolume);
	}
	
	private Contract[] theContract;
	private double[] theWeight;
	private int theVolumePerTrade = 10;
	private int[] theMinMarketVolume = null;

}

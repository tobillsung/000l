package strategy.manual;

import java.util.Date;

import plot.DynamicXYPlot;
import product.ProductManager;
import strategy.PositionAdj;
import strategy.spreadtrade.SpreadTrade;

import com.ib.client.Contract;

public class PremiumManualTrade extends SpreadTrade{

	public PremiumManualTrade(Contract[] aContracts, double[] aWeights,
			int aVolumePerTrade, int[] aMinMarketVolume) throws Exception {
		super(aContracts, aWeights, aVolumePerTrade, aMinMarketVolume);
		
		theFitOnlyOnFlat = false;
	}
	
	/**
	 * Only close profit is checked
	 */
	@Override
	public void checkOpportunity() {
		
		PositionAdj.Profit myReqProfit = thePositionAdj.getReqProfit();
		double myReqLongProfit = myReqProfit.reqLong();
		double myReqShortProfit = myReqProfit.reqShort(); 
		
		if (theCumulativePos > 0) { // Portfolio is long
			double myCurrSellPremium = theCurrSpread.sell() + theFittedPremium;
			if (myCurrSellPremium >= theLastTradePremium + myReqShortProfit && theCurrSpread.isSellTradeable()) {
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Sell;
				thePlaceOrderName = PlaceOrderName.Algo;
				placePortfolioOrder(-1);
				theFitter.reset();
			} 
		} else if (theCumulativePos < 0) { // Portfolio is short
			double myCurrBuyPremium = theCurrSpread.buy() + theFittedPremium;
			myReqLongProfit = - myReqLongProfit;
			if (myCurrBuyPremium <= theLastTradePremium + myReqLongProfit && theCurrSpread.isBuyTradeable()) { // Spread becomes cheaper
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Buy;
				thePlaceOrderName = PlaceOrderName.Algo;
				placePortfolioOrder(1);
				theFitter.reset();
			} 
		}
		
		if (thePremiumPlot != null && thePremiumPlot.theStatus == DynamicXYPlot.Status.Running) {
			thePremiumPlot.addNewDataset(new Date((long)theCurrSpread.timestamp()),
					new double[] {theCurrSpread.buy() + theFittedPremium, 
				theCurrSpread.sell() + theFittedPremium, theFittedPremium});
		}
	}

	
	@Override
	public void placeManualOrder(int aPortfolioVolume) {
		synchronized (this) {
			
			int myMaxPos = (int)thePositionAdj.getMaxPos();
			if (aPortfolioVolume > 0) { // try to long
				if (theCumulativePos < myMaxPos) { 
					thePortfolioAction = Action.Buy;
					theLastTradePremium = theCurrSpread.buy() + theFittedPremium;
					theNextCumulativePos = theCumulativePos + aPortfolioVolume;
					theStatus = Status.Running;
					thePlaceOrderName = PlaceOrderName.Manual;
					placePortfolioOrder(aPortfolioVolume);
					if (theNextCumulativePos == 0)
						theFitter.reset(); // Reset is important to recenter the spread
				} else
					theLogger.warn("CumulativePos({}) is at the Max position({})", theCumulativePos, myMaxPos);
			} else { // try to short
				if (theCumulativePos > - myMaxPos) { // 
					thePortfolioAction = Action.Sell;
					theLastTradePremium = theCurrSpread.sell() + theFittedPremium;
					theNextCumulativePos = theCumulativePos + aPortfolioVolume;
					theStatus = Status.Running;
					thePlaceOrderName = PlaceOrderName.Manual;
					placePortfolioOrder(aPortfolioVolume);
					if (theNextCumulativePos == 0)
						theFitter.reset();
				} else
					theLogger.warn("CumulativePos({}) is at the Max position({})", theCumulativePos, myMaxPos);
			}
		}
	}
	@Override
	public String getStrategyName() {
		synchronized (this) {
			String[] mySymbols = theSymbolContractMap.keySet().toArray(
					new String[theSymbolContractMap.size()]);
			
			String myStrategyName = "PremManual_";
			for (String mySymbol : mySymbols) {
				myStrategyName = myStrategyName + ProductManager.getTickerBySymbol(mySymbol) + "-";
			}
			return myStrategyName.substring(0, myStrategyName.length() - 1);
		}
	}
	
	
	private double theLastTradePremium = 0.0;
	
}

package strategy.manual.optimized;

import order.OrderHandler;

import com.ib.client.Contract;

import control.Controller;
import feed.FeedHandler;
import fit.EMAFitter;
import report.Reporter;
import strategy.PositionAdj;
import strategy.AbstractStrategy.Type;
import strategy.manual.PremiumManualTrade;
import strategy.manual.PremiumManualTradeBuilder;

public class OptimizedPremiumManual {
	
	public static PremiumManualTrade OpeningHour_ES_NQ(
			Contract[] aContracts, FeedHandler aFeedHandler, OrderHandler aOrderHandler,
			Reporter aReporter, Controller aController) throws Exception{
		
		// Fitter
		EMAFitter myFitter = new EMAFitter(300 * 1e3, 30000);
		myFitter.setAbsUpdateVal(0);

		// PositionAdj
		double myOpenMinProfit = 100;
		double myCloseMinProfit = 50;
		double myAdjustment = 50;
		double myStopLossTrigger = 50;
		double myStopLoss = 0;
		int myMaxPos = 1;
		PositionAdj myPositionAdj = new PositionAdj(myOpenMinProfit, myCloseMinProfit, 
				myAdjustment, myMaxPos);
		myPositionAdj.setStrategy(PositionAdj.Strategy.MomentTrade);
		myPositionAdj.setStopLoss(myStopLossTrigger, myStopLoss);

		// SpreadTrade
		double [] myWeights = new double[] {2, -1};
		int myPortfolioVolume = 1;
		PremiumManualTradeBuilder myPMTB = new PremiumManualTradeBuilder();
		PremiumManualTrade myPremiumManualTrade = myPMTB.contract(aContracts).weight(myWeights)
				.volumePerTrade(myPortfolioVolume)
				.minMarketVolume(new int[] {50, 5}).build();
		
		myPremiumManualTrade.init(aFeedHandler, aOrderHandler, myFitter, myPositionAdj);
		myPremiumManualTrade.setReporter(aReporter);
		myPremiumManualTrade.setController(aController);
		myPremiumManualTrade.setShowPremiumPlot(true);
		myPremiumManualTrade.setOrderType(Type.LMT); // Limit order to cross
		myPremiumManualTrade.setCloseOutPosTime(103000.0);
		myPremiumManualTrade.setFitterResetOnClose(true);
		myPremiumManualTrade.setFitOnlyOnFlat(false);
		
		return myPremiumManualTrade;
	}
	
	public static PremiumManualTrade MidHour_ES_NQ(
			Contract[] aContracts, FeedHandler aFeedHandler, OrderHandler aOrderHandler,
			Reporter aReporter, Controller aController) throws Exception{
		
		// Fitter
		EMAFitter myFitter = new EMAFitter(300 * 1e3, 30000);
		myFitter.setAbsUpdateVal(0);

		// PositionAdj
		double myOpenMinProfit = 100;
		double myCloseMinProfit = 50;
		double myAdjustment = 50;
		double myStopLossTrigger = 50;
		double myStopLoss = 0;
		int myMaxPos = 1;
		PositionAdj myPositionAdj = new PositionAdj(myOpenMinProfit, myCloseMinProfit, 
				myAdjustment, myMaxPos);
		myPositionAdj.setStrategy(PositionAdj.Strategy.MomentTrade);
		myPositionAdj.setStopLoss(myStopLossTrigger, myStopLoss);

		// SpreadTrade
		double [] myWeights = new double[] {1, -1};
		int myPortfolioVolume = 2;
		PremiumManualTradeBuilder myPMTB = new PremiumManualTradeBuilder();
		PremiumManualTrade myPremiumManualTrade = myPMTB.contract(aContracts).weight(myWeights)
				.volumePerTrade(myPortfolioVolume)
				.minMarketVolume(new int[] {50, 5}).build();
		
		myPremiumManualTrade.init(aFeedHandler, aOrderHandler, myFitter, myPositionAdj);
		myPremiumManualTrade.setReporter(aReporter);
		myPremiumManualTrade.setController(aController);
		myPremiumManualTrade.setShowPremiumPlot(true);
		myPremiumManualTrade.setOrderType(Type.LMT); // Limit order to cross
		myPremiumManualTrade.setCloseOutPosTime(133000.0);
		myPremiumManualTrade.setFitterResetOnClose(true);
		myPremiumManualTrade.setFitOnlyOnFlat(false);
		
		return myPremiumManualTrade;
	}

}

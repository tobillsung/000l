package strategy.spreadtrade;

import java.util.Date;

import order.OrderHandler;
import order.OrderManager;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

import plot.DynamicXYPlot;
import product.FeeManager;
import product.ProductManager;
import report.Reporter;
import strategy.AbstractStrategy;
import strategy.PositionAdj;
import util.CSVHelper;
import util.MySqlHelper;
import util.TimeConv;

import com.ib.client.Contract;

import feed.FeedHandler;
import feed.RetailState.Data;
import fit.Fittable;
import fit.FitterAdj;

public class SpreadTrade extends AbstractStrategy{
	
	public SpreadTrade() {
		// For inheritence purpose
	}
	
	public SpreadTrade(Contract[] aContracts, double[] aWeights, int aVolumePerTrade, int[] aMinMarketVolume) throws Exception {
		
		theWeights = aWeights;
		theVolumePerTrade = aVolumePerTrade;
		theMinMarketVolume = aMinMarketVolume;
		
		if (aContracts.length != aWeights.length)
			throw new IllegalArgumentException("length of aContracts and aWeights should be same");
		
		if (theMinMarketVolume == null) {
			theMinMarketVolume = new int[aWeights.length];
			for(int i = 0 ; i < aWeights.length ; i++) {
				theMinMarketVolume[i] = 1;
			}
		}
		
		// Init all maps
		theMySqlHelper = new MySqlHelper();
		for (int i = 0 ; i < aContracts.length ; i++) {
			String mySymbol = ProductManager.getSymbolByContract(aContracts[i]);
			theSymbolContractMap.put(mySymbol, aContracts[i]);
			
			String[][] myRes = theMySqlHelper.select("Product", "Detail", 
					new String[] {"Multiplier"}, "Symbol = '" + mySymbol +"';" );
			
			theContractSizeMap.put(mySymbol, Double.valueOf(myRes[0][0]));
			
			// theSymbolDataMap(timestamp, time, bidP, bidV, askP, askV, midP)
			// bidP, askP, midP are with the contract size
			theSymbolDataMap.put(mySymbol, new double[] {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0});
			theOrderFilled.add(true);
			theSymbolOrderFilledMap.put(mySymbol, false);
			
			theRoundTradeVolumeMap.put(mySymbol, (double) Math.round(theWeights[i] * theVolumePerTrade));
			if (theRoundTradeVolumeMap.get(mySymbol) == 0) {
				theLogger.error("Volume for contract #{} is rounded to zero", i);
				System.exit(0); // Stop everything !!!!
			}
			
			double myFeePerTrade = FeeManager.getFeeStructure(
					ProductManager.getTickerBySymbol(mySymbol)).getTotFee() * Math.abs(theRoundTradeVolumeMap.get(mySymbol));
			theFeePerPortfolioTrade = theFeePerPortfolioTrade + myFeePerTrade; 
			theSymbolFeeMap.put(mySymbol, myFeePerTrade);
			
			// Logs
			theLogger.info("{} - TradeVolume: {}", mySymbol, theRoundTradeVolumeMap.get(mySymbol));
			theLogger.info("{} - MinMarketVolume: {}", mySymbol, theMinMarketVolume[i]);
			theLogger.info("{} - Contract size: {}", mySymbol, theContractSizeMap.get(mySymbol));
			theLogger.info("{} - Fee per trade: {}", mySymbol, myFeePerTrade);
		}
		
	}
	
	public void setShowPremiumPlot(boolean aShowPremiumPlot) {
		theShowPremiumPlot = aShowPremiumPlot;
	}
	
	public void setFitterAdj(FitterAdj aFitterAdj) {
		setFitterAdj(aFitterAdj, 2.0);
	}
	
	public void setFitterAdj(FitterAdj aFitterAdj, double aMaxMultiplier) {
		theFitterAdj = aFitterAdj;
		theMaxMultiplier = aMaxMultiplier;
	}
	
	
	@Override
	public void init(FeedHandler aFeedHandler, 
			OrderHandler aOrderHandler, Fittable aFitter, PositionAdj aPositionAdj) {
		
		synchronized (this) {
			
			theFeedHandler = aFeedHandler;
			theOrderHandler = aOrderHandler;	
			theStrategyName = getStrategyName();
			
			// Request data from FeedHandler
			theFeedHandler.reqRetailStateUpdate(
					theSymbolContractMap.values().toArray(new Contract[theSymbolContractMap.size()]), this);
			
			theFitter = aFitter;
			thePositionAdj = aPositionAdj;

			CSVHelper.write(getCSVFileName(), "Date,Time,Strategy,Pos,Ticker,"
					+ "MarketT,MarketP,MarketV,TradeP,TradeV,RealizedPnL,Fee,RealizedPnLWithFee", true);
			
		}
	}
	
	@Override
	public void run() {
		
		synchronized(this) {
			
			addNewItemToReporter(0, 0);
			updateItemToController();
			
			synchronized (this) {
				
				long myInitFitTime = theFitter.initFitTime();
				if (theFitter.initFitVal() == 0 && myInitFitTime > 0) {
					theLogger.info("Wait {} second for fitting", myInitFitTime / 1e3);
				} else {
					theFittedPremium = theFitter.initFitVal();
					theStatus = Status.Running;
					theLogger.info("InitFit is finished with FitVal: {}", String.format("%.2f", theFittedPremium));
					theLogger.info("Status: {}", Status.Running.name());
					updateItemToController();
				}
			}
			while (theStatus != Status.Done && theStatus != Status.Error) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	
		if (theStatus == Status.Done) {
			updateItemToController();
			theLogger.info(theStrategyName + " is done");
			theOrderHandler.insertOrderState(theStrategyName);
			if (theLoadTradeToDatabase) {
				theLogger.info("Loading trade csv file into database");
				theMySqlHelper.loadCSVToTable(getCSVFileName(), MySqlHelper.TradeTable, false, true);
			}
			
			Reporter.Summary mySummary = getTradeSummary();
			
			theLogger.info("Trading summary");
			theLogger.info("Remaining BuyN: {}", mySummary.theCumulativeBuyN);
			theLogger.info("Remaining SellN: {}", mySummary.theCumulativeSellN);
			theLogger.info("Remaining Pos: {}", mySummary.theCumulativePos);
			theLogger.info("FlatPnLWithFee: {}", mySummary.theCumulativeFlatPnL - mySummary.theCumulativeFee);
		}
			
	}
	
	@Override
	/* 
	 * Fit is only for weights. Therefore it is normalized for aVolumePerTrade
	 * (non-Javadoc)
	 * @see strategy.AbstractStrategy#fit()
	 */
	protected double fit(Fittable aFitter) {
		synchronized (this) {
			double myActualPremium = 0;
			double myTime = 0;
			int myCount = 0;
			for (double[] myData : theSymbolDataMap.values()) {
				if (myData[COL_BidP] == 0 || myData[COL_AskP] == 0) // Invalid data
					return 0;
				
				myTime = Math.max(myTime, myData[Col_Timestamp]);
				myActualPremium = myActualPremium + myData[COL_MidP] * theWeights[myCount];
				myCount ++;
			}
			double myFittedVal = aFitter.fit(new double[] {myTime, myActualPremium});
			return myFittedVal;
		}
	}
	
	
	// ------------------------------------------------------------------------------
	// FeedListener
	@Override
	public void newRetailState(String aSymbol, Data aNewData) {
		synchronized (this) {
			
			if (thePlotType != null) {
				if (theDynamicXYPlot == null) {
					double[] myDateArray = TimeConv.UnixT.toDateArray(aNewData.getTime());
					theDynamicXYPlot = new DynamicXYPlot("Spread_" + theStrategyName + " [" + (int) myDateArray[0] + "]", 
							thePlotType, new Date(aNewData.getTime() - 1000), 
							new double[] {1e-4, 1e-4, 1e-4, 1e-4, 1e-4, 1e-4});
					theDynamicXYPlot.init();
					theLogger.info("SpreadPlot is initialized");
				} else if (theDynamicXYPlot.theStatus == DynamicXYPlot.Status.Disposed) {
					thePlotType = null; // If you want to reopen the plot rerun setPlotType
				}
			}
			
			double myContractSize = theContractSizeMap.get(aSymbol);
			double[] myDateArray = TimeConv.UnixT.toDateArray(aNewData.getTime());
			theSymbolDataMap.put(aSymbol, 
					new double[] {
					aNewData.getTime(), myDateArray[1],
					aNewData.getBidP() * myContractSize,
					aNewData.getBidV(),
					aNewData.getAskP() * myContractSize,
					aNewData.getAskV(),
					aNewData.getMid() * myContractSize});
			theLogger.debug("{} : {}", aSymbol, aNewData.getTick());
			
			if (theStatus == Status.Done || theStatus == Status.Error) {
				return;
			}
			
			// Run FitterAdj
			if (theFitterAdj != null) {
				fit(theFitterAdj);
			}
			
			// Even though I have order working, I update the fit with new data
			if (thePlaceOrderStatus == PlaceOrderStatus.Close) { 
				fit(theFitter); // Run fit but don't update the theFittedConst
				
				return; // PlaceOrderStatus is closed, so don't send any orders
			}
			
			// Update fit based on theStatus
			if (theStatus == Status.Init) {
				long myCurrTime = aNewData.getTime();
				if (theInitFitStopTime == 0) {
					theInitFitStopTime = aNewData.getTime() + theFitter.initFitTime();
				} 
				// Run initFit
				if (myCurrTime <= theInitFitStopTime){
					theFittedPremium = fit(theFitter);
					return; // This is init phase, so don't send any orders
				} else {
					if (theStatus == Status.Init) {
						theStatus = Status.Running;
						theLogger.info("InitFit is finished with FitVal: {}", String.format("%.2f", theFittedPremium));
						theLogger.info("Status: {}", Status.Running.name());
						updateItemToController();
					}
				}
			} else { // Status is Running or Pause or FinalTrade
				if (theFitOnlyOnFlat) {
					if (theCumulativePos == 0) {
						theFittedPremium = fit(theFitter); // Run fit and also update the fit val
					} else {
						fit(theFitter); // Run fit but don't update the theFittedConst
					}
				} else { // Always fit
					theFittedPremium = fit(theFitter);
				}
			}
			
			// Check fitter adjustment
			if (theFitterAdj != null) {
				
				if ((theFitOnlyOnFlat && theCumulativePos == 0) || ! theFitOnlyOnFlat) {
					double myAdjMultiplier = 1.0;
					if (thePrevSpread != null) {
						double myPrevMidSpread = thePrevSpread.theMidSpread;
						PositionAdj.Profit myReqProfit = thePositionAdj.getReqProfit();
						double myReqLongSpread = - myReqProfit.reqLong();
						double myReqShortSpread = myReqProfit.reqShort();

						if (Math.abs(myPrevMidSpread - myReqLongSpread) >= Math.abs(myPrevMidSpread - myReqShortSpread)) {
							myAdjMultiplier = theMaxMultiplier * myPrevMidSpread / (myReqShortSpread - myReqLongSpread)
									- theMaxMultiplier * myReqLongSpread / (myReqShortSpread- myReqLongSpread);
						} else { // PrevSpread is closer to longSpread
							myAdjMultiplier = theMaxMultiplier * myPrevMidSpread / (myReqShortSpread - myReqLongSpread)
									- theMaxMultiplier * myReqShortSpread / (myReqShortSpread - myReqLongSpread);
						}
					}
				
					theFitterAdj.checkAdj(aNewData.getTime(), theFittedPremium, myAdjMultiplier);
				
					if (theFitterAdj.isReset()) {
					
						theLogger.info("Fitter is adjusted from {} to {} @ {}", 
								String.format("%.2f", theFittedPremium), 
								String.format("%.2f", theFitterAdj.getResetVal()),
								TimeConv.UnixT.toDateStr(aNewData.getTime()));
						theFittedPremium = theFitterAdj.getResetVal();
						theFitter.reset(aNewData.getTime(), theFittedPremium);
					}
				} else { // FitterAdj is not updated because the position is not flat
					// FitterAdj is reset, so next time fitter adjustment does not have previous history
					theFitterAdj.reset();
				}
			}
			
			if (theShowPremiumPlot) {
				if (thePremiumPlot == null) {
					double[] myPDateArray = TimeConv.UnixT.toDateArray(aNewData.getTime());
					thePremiumPlot = new DynamicXYPlot("Premium_" + theStrategyName + " [" + (int) myPDateArray[0] + "]", 
							DynamicXYPlot.PlotType.Premium, new Date(aNewData.getTime() - 1000), 
							new double[] {theFittedPremium, theFittedPremium, theFittedPremium, theFittedPremium, theFittedPremium});
					thePremiumPlot.initToRelative(theDynamicXYPlot);
					theLogger.info("PremiumPlot is initialized");
				} else if (thePremiumPlot.theStatus == DynamicXYPlot.Status.Disposed) {
					theShowPremiumPlot = false;
				}
			}

			// Check for CloseOutPos
			checkCloseOutPosTime(aNewData);
			if (theStatus == Status.FinalTrade) {
				if (theCumulativePos == 0) {
					theLogger.info("Cumulative position is flat and stopping trade at {}", theCloseOutPosTime);
					setStatus(Status.Done);
					this.notify();
				} else if (theNotifyCloseOut){
					theLogger.info("Starting to close out position at {} for remaining position [{}]", 
							theCloseOutPosTime, theCumulativePos);
					theNotifyCloseOut = false;
					updateItemToController();
				}
			}

			// Calculate spread
			theCurrSpread = getSpread();

			// Check for opportunity
			checkOpportunity();

			// Assign thePrevSpread
			thePrevSpread = (Spread) theCurrSpread.clone();
		}
	}

	@Override
	public void newLastDone(String aSymbol, feed.LastDone.Data aNewData) {
		// ST does not use last dones
	}

	// ------------------------------------------------------------------------------
	// OrderListener
	// Only get this message when your open order is fully filled
	@Override
	public void newOrderManager(OrderManager aOrderManager) {
		synchronized (this) {
			
			if (aOrderManager.theStatus == OrderHandler.Status.Inactive || 
					aOrderManager.theStatus == OrderHandler.Status.Error) {
				theLogger.error("Order status: {}", aOrderManager.theStatus.name());
				this.setStatus(Status.Error);
				this.notify();
				return;
			}
			
			theSymbolOrderFilledMap.put(aOrderManager.theSymbol, true);
			
			String mySymbol = aOrderManager.theSymbol;
			int myVolume = 0;			
			double myFilledPrice = aOrderManager.theFilledP;
			Action myAction = Action.valueOf(aOrderManager.theOrder.m_action);
			
			if (myAction == Action.Buy) {
				myVolume = aOrderManager.theOrder.m_totalQuantity;
			} else {
				myVolume = - aOrderManager.theOrder.m_totalQuantity;
			}
			
			int myCurrPortPos = theNextCumulativePos - theCumulativePos;
			
			double[] myData = theSymbolDataMap.get(mySymbol);
			int myPortfolioPos = myVolume / theRoundTradeVolumeMap.get(mySymbol).intValue();
				
			theLogger.info("[{}] filled: {} @ {}", mySymbol, myVolume, myFilledPrice);
			
			double[] myDateTime = TimeConv.UnixT.toDateArray(aOrderManager.theTime);
			
			// Realized PnL from TradeP and TradeV
			double myRealizedPnLPerSymbol = myFilledPrice * (- myVolume) * theContractSizeMap.get(mySymbol);
			thePortfolioRealizedPnL = thePortfolioRealizedPnL + myRealizedPnLPerSymbol; // This gives portfolio trade
			
			// Fee
			double myFeePerSymbol = theSymbolFeeMap.get(mySymbol);
			
			StringBuilder myCSVSb = new StringBuilder(); 
			myCSVSb.append(myDateTime[0] + ",");
			myCSVSb.append(myDateTime[1] + ",");
			myCSVSb.append(theStrategyName + ",");
			myCSVSb.append(myPortfolioPos + ",");
			myCSVSb.append(ProductManager.getTickerBySymbol(mySymbol) + ",");
			myCSVSb.append(myData[COL_Time] + ",");
			myCSVSb.append(aOrderManager.theOrder.m_placedPrice + ",");
			myCSVSb.append(aOrderManager.theOrder.m_marketVolumeOnSide + ",");
			myCSVSb.append(myFilledPrice + ",");
			myCSVSb.append(myVolume + ",");
			myCSVSb.append(myRealizedPnLPerSymbol + ",");
			myCSVSb.append(myFeePerSymbol + ",");
			myCSVSb.append(myRealizedPnLPerSymbol - myFeePerSymbol + "\n");
							
			CSVHelper.write(getCSVFileName(), myCSVSb.toString(), true);
			
			// Check for all filled
			if (CollectionUtils.isEqualCollection(theOrderFilled, theSymbolOrderFilledMap.values())) {
				for (String mySymbolElem : theSymbolOrderFilledMap.keySet()) 
					theSymbolOrderFilledMap.put(mySymbolElem, false);
				
				// Plot for spread
				PositionAdj.Profit myReqProfit = thePositionAdj.getReqProfit();
				
				double myReqLongSpread = - myReqProfit.reqLong();
				double myReqShortSpread = myReqProfit.reqShort();
				
				if (theDynamicXYPlot != null && theCurrSpread.mid() != 0 && 
						theDynamicXYPlot.theStatus == DynamicXYPlot.Status.Running) {
					
					// This spread would be different from realized pnl
					// due to filled price is better than bid / ask when we place order
					// However, this approximated spread is good for plotting
					double myOrderPlacedSpread = thePortfolioAction == Action.Buy ? theCurrSpread.buy() : theCurrSpread.sell();
					
					if (thePortfolioAction == Action.Buy) {
						theDynamicXYPlot.addNewDataset(new Date(aOrderManager.theTime),
								new double[] {theCurrSpread.buy(), theCurrSpread.sell(), myReqLongSpread, 
							myReqShortSpread, myOrderPlacedSpread});
					} else {
						theDynamicXYPlot.addNewDataset(new Date(aOrderManager.theTime),
								new double[] {theCurrSpread.buy(), theCurrSpread.sell(), myReqLongSpread, 
							myReqShortSpread, Double.NaN, myOrderPlacedSpread});
					}
				}
				
				if (thePremiumPlot != null && thePremiumPlot.theStatus == DynamicXYPlot.Status.Running) {
					if (thePortfolioAction == Action.Buy) {
						thePremiumPlot.addNewDataset(new Date(aOrderManager.theTime), 
								new double[] {theCurrSpread.buy() + theFittedPremium, theCurrSpread.sell() + theFittedPremium, 
							theFittedPremium, theCurrSpread.buy() + theFittedPremium});
					} else {
						thePremiumPlot.addNewDataset(new Date(aOrderManager.theTime),
								new double[] {theCurrSpread.buy() + theFittedPremium, theCurrSpread.sell() + theFittedPremium,
							theFittedPremium, Double.NaN, theCurrSpread.sell() + theFittedPremium});
					}
				}
				
				
				// Update the current cumulative portfolio position
				theCumulativePos = theNextCumulativePos; 
				
				// Add new item to reporter
				addNewItemToReporter(myCurrPortPos, thePortfolioRealizedPnL);
				
				thePortfolioRealizedPnL = 0; // Reset the portfolio realized pnl
				thePositionAdj.setReqProfit(theCumulativePos); // Update the req profit
				
				// Update Status
				if (theStatus == Status.FinalTrade) {
					theLogger.info("Closing out the position and stopping trade");
					theStatus = Status.Done;
					thePlaceOrderStatus = PlaceOrderStatus.Close;
					this.notify();
				} else {
					thePlaceOrderStatus = PlaceOrderStatus.Open;
					if (thePlaceOrderName == PlaceOrderName.Algo_StopLoss) {
						theStatus = Status.Pause;
					} else {
						theStatus = Status.Running;
					}
				}
				
				// Update controller (Controller needs theStatus and theCumulativePos)
				updateItemToController();
				
				// This allows to recenter after the closing position
				if (theFitterResetOnClose && theCumulativePos == 0) {
					theFitter.reset(); 
				}
			}
		}
	}
	
	@Override
	public String getStrategyName() {
		synchronized (this) {
			String[] mySymbols = theSymbolContractMap.keySet().toArray(
					new String[theSymbolContractMap.size()]);
			
			String myStrategyName = "ST_";
			for (String mySymbol : mySymbols) {
				myStrategyName = myStrategyName + ProductManager.getTickerBySymbol(mySymbol) + "-";
			}
			return myStrategyName.substring(0, myStrategyName.length() - 1);
		}
	}
	
	@Override
	public void placeManualOrder(int aPortfolioVolume) {
		synchronized (this) {
			
			int myMaxPos = (int)thePositionAdj.getMaxPos();
			if (aPortfolioVolume > 0) { // try to long
				if (theCumulativePos < myMaxPos) { 
					thePortfolioAction = Action.Buy;
					theNextCumulativePos = theCumulativePos + aPortfolioVolume;
					theStatus = Status.Running;
					thePlaceOrderName = PlaceOrderName.Manual;
					placePortfolioOrder(aPortfolioVolume);
				} else
					theLogger.warn("CumulativePos({}) is at the Max position({})", theCumulativePos, myMaxPos);
			} else { // try to short
				if (theCumulativePos > - myMaxPos) { // 
					thePortfolioAction = Action.Sell;
					theNextCumulativePos = theCumulativePos + aPortfolioVolume;
					theStatus = Status.Running;
					thePlaceOrderName = PlaceOrderName.Manual;
					placePortfolioOrder(aPortfolioVolume);
				} else
					theLogger.warn("CumulativePos({}) is at the Max position({})", theCumulativePos, myMaxPos);
			}
		}
	}
	
	public class Spread implements Cloneable {
		
		public Spread(double aTimestamp, double aBuySpread, double aSellSpread, double aMidSpread,
				boolean aIsBuyTradeable, boolean aIsSellTradeable) {
			theTimestamp = aTimestamp;
			theBuySpread = aBuySpread;
			theSellSpread = aSellSpread;
			theMidSpread = aMidSpread;
			theIsBuyTradeable = aIsBuyTradeable;
			theIsSellTradeable = aIsSellTradeable;
		}
		
		public boolean isBuyTradeable() {
			return theIsBuyTradeable;
		}
		
		public boolean isSellTradeable() {
			return theIsSellTradeable;
		}
		
		public Object clone(){  
		    try{  
		        return super.clone();  
		    }catch(Exception e){ 
		        return null; 
		    }
		}
		
		@Override
		public int hashCode() {
	        return new HashCodeBuilder(17, 31).
	            append(theTimestamp).append(theBuySpread).append(theSellSpread).
	            append(theMidSpread).toHashCode();
	    }

		@Override
	    public boolean equals(Object aObj) {
	        if (aObj == null)
	            return false;
	        if (aObj == this)
	            return true;
	        if (!(aObj instanceof Spread))
	            return false;

	        Spread mySpread = (Spread) aObj;
	        return new EqualsBuilder().
	            append(theTimestamp, mySpread.theTimestamp).
	            append(theBuySpread, mySpread.theBuySpread).
	            append(theSellSpread, mySpread.theSellSpread).
	            append(theMidSpread, mySpread.theMidSpread).isEquals();
	    }
		
		public double timestamp() {return theTimestamp;}
		public double buy() {return theBuySpread;}
		public double sell() {return theSellSpread;}
		public double mid() {return theMidSpread;}
		
		private double theTimestamp;
		private double theBuySpread;
		private double theSellSpread;
		private double theMidSpread;
		private boolean theIsBuyTradeable = true;
		private boolean theIsSellTradeable = true;
	}
	
	// ------------------------------------------------------------------------------
	// protected
	/**
	 * This is the protected method for checking trading opportunity
	 * You may override this methods if you extends SpreadTrade
	 */
	protected void checkOpportunity() {
		
		// Create required spread for long or short
		PositionAdj.Profit myReqProfit = thePositionAdj.getReqProfit();
		double myReqLongSpread = - myReqProfit.reqLong();
		double myReqShortSpread = myReqProfit.reqShort();
		double myStopLossTrigger = thePositionAdj.getStopLossTrigger();
		double myStopLoss = thePositionAdj.getStopLoss();
		
		// Init next cumulative position
		theNextCumulativePos = theCumulativePos; 
		if (theCumulativePos == 0) { // Portfolio is flat
			if (theCurrSpread.buy() <= myReqLongSpread && theCurrSpread.isBuyTradeable()) { // Spread is cheap so enter long 
				theNextCumulativePos ++;
				thePortfolioAction = Action.Buy;
				thePlaceOrderName = PlaceOrderName.Algo;
				placePortfolioOrder(1);
			}
			else if (theCurrSpread.sell() >= myReqShortSpread && theCurrSpread.isSellTradeable()) {
				theNextCumulativePos --;
				thePortfolioAction = Action.Sell;
				thePlaceOrderName = PlaceOrderName.Algo;
				placePortfolioOrder(-1);
			}
		} else if (theCumulativePos > 0) { // Portfolio is long
			if (theCurrSpread.sell() >= myReqShortSpread && theCurrSpread.isSellTradeable()) { // Spread becomes expensive 
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Sell;
				thePlaceOrderName = PlaceOrderName.Algo;
				placePortfolioOrder(-theCumulativePos);
			}
			else if (theCurrSpread.buy() <= myReqLongSpread && theCurrSpread.isBuyTradeable() &&
					theCumulativePos < thePositionAdj.getMaxPos()) {
				theNextCumulativePos ++;
				thePortfolioAction = Action.Buy;
				thePlaceOrderName = PlaceOrderName.Algo;
				placePortfolioOrder(1);
			} else if (!theIsStopLossTriggered && theCurrSpread.buy() <= - myStopLossTrigger) { // Reached stoploss trigger
				theIsStopLossTriggered = true;
				theLogger.info("StopLoss logic is triggered at {}", -myStopLoss);
			} else if (theIsStopLossTriggered && theCurrSpread.sell() >= - myStopLoss) { // Close out all position and reset fitter
				theIsStopLossTriggered = false;
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Sell;
				thePlaceOrderName = PlaceOrderName.Algo_StopLoss;
				placePortfolioOrder(-theCumulativePos);
				theFitter.reset();
			}
		} else if (theCumulativePos < 0) { // Portfolio is short
			if (theCurrSpread.buy() <= myReqLongSpread && theCurrSpread.isBuyTradeable()) { // Spread becomes cheaper
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Buy;
				thePlaceOrderName = PlaceOrderName.Algo;
				placePortfolioOrder(theCumulativePos);
			} else if (theCurrSpread.sell() >= myReqShortSpread && theCurrSpread.isSellTradeable() &&
					Math.abs(theCumulativePos) < thePositionAdj.getMaxPos()) {
				theNextCumulativePos --;
				thePortfolioAction = Action.Sell;
				thePlaceOrderName = PlaceOrderName.Algo;
				placePortfolioOrder(-1);
			} else if (!theIsStopLossTriggered && theCurrSpread.sell() >= myStopLossTrigger) { // Reached stoploss trigger
				theIsStopLossTriggered = true;
				theLogger.info("StopLoss logic is triggered at {}", myStopLoss);
			} else if (theIsStopLossTriggered && theCurrSpread.buy() <= myStopLoss) { // Close out all position and reset fitter
				theIsStopLossTriggered = false;
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Buy;
				thePlaceOrderName = PlaceOrderName.Algo_StopLoss;
				placePortfolioOrder(theCumulativePos);
				theFitter.reset();
			}
		}
		
		// Plot for spread (not yet for traded for buy or sell)
		if (theDynamicXYPlot != null && 
				theDynamicXYPlot.theStatus == DynamicXYPlot.Status.Running &&
				(thePrevSpread != null && !thePrevSpread.equals(theCurrSpread))) {
			
			theDynamicXYPlot.addNewDataset(new Date((long)theCurrSpread.timestamp()),
					new double[] {theCurrSpread.buy(), theCurrSpread.sell(), myReqLongSpread, myReqShortSpread});
			
			if (thePremiumPlot != null && thePremiumPlot.theStatus == DynamicXYPlot.Status.Running) {
				thePremiumPlot.addNewDataset(new Date((long)theCurrSpread.timestamp()),
						new double[] {theCurrSpread.buy() + theFittedPremium, 
					theCurrSpread.sell() + theFittedPremium, theFittedPremium});
			}
		}
		
		theLogger.debug("CumulativePos: {}, BuySpread: {}, SellSpread: {}, ReqLong: {}, ReqShort: {}", 
				theCumulativePos, String.format("%.2f", theCurrSpread.buy()), String.format("%.2f", theCurrSpread.sell()), 
				String.format("%.2f", myReqLongSpread), String.format("%.2f", myReqShortSpread));
		
	}
	
	/**
	 * 
	 * @param aPortfolioOrderVolume: this is not aVolumePerTrade, it is +/- 1 or +/- CurrPortPos to close out
	 */
	@Override
	protected void placePortfolioOrder(int aPortfolioOrderVolume) {
		
		if (theStatus == Status.Pause || theStatus == Status.Done) {
			return; // Don't place order
		}
		
		thePlaceOrderStatus = PlaceOrderStatus.Close;
		
		// It is linked hashmap so order is preserved
		for (String mySymbol : theSymbolContractMap.keySet()) {
			int myOrderId = theOrderHandler.generateOrderId();
			double[] myData = theSymbolDataMap.get(mySymbol);
			double myContractSize = theContractSizeMap.get(mySymbol);
			double myTradeVolume = theRoundTradeVolumeMap.get(mySymbol);

			// Init
			double myOrderPrice = 0.0;
			double myMarketVolumeOnSide = 0;
			Action myOrderAction = null;
			if (thePortfolioAction == Action.Buy) { // Portfolio buy: 
				if (myTradeVolume > 0 ) { // Place buy order 
					myOrderPrice = myData[COL_AskP];
					myMarketVolumeOnSide = myData[COL_AskV];
					myOrderAction = Action.Buy; 
				} else { // Place sell order
					myOrderPrice = myData[COL_BidP];
					myMarketVolumeOnSide = myData[COL_BidV];
					myOrderAction = Action.Sell;
				}
			} else { // Portfolio sell 
				if (myTradeVolume > 0 ) { // Place sell order
					myOrderPrice = myData[COL_BidP];
					myMarketVolumeOnSide = myData[COL_BidV];
					myOrderAction = Action.Sell;
				} else {					// Place buy order
					myOrderPrice = myData[COL_AskP];
					myMarketVolumeOnSide = myData[COL_AskV];
					myOrderAction = Action.Buy;
				}
			}
			myOrderPrice = myOrderPrice / myContractSize;
			int myOrderVolume = Math.abs((int) myTradeVolume * aPortfolioOrderVolume);
			
			SpreadOrder mySpreadOrder = 
					new SpreadOrder(myOrderId, theOrderType, myOrderPrice, myOrderAction, myOrderVolume);
			mySpreadOrder.setMarketVolumeOnSide(myMarketVolumeOnSide);
			mySpreadOrder.m_placeTime = (long) myData[Col_Timestamp];
			
			if (myOrderAction == Action.Buy)
				theLogger.info("{} Placing [{}] {} order: {} @ {}", thePlaceOrderName.name(), mySymbol, 
						theOrderType.name(), myOrderVolume, myOrderPrice);
			else
				theLogger.info("{} Placing [{}] {} order: {} @ {}", thePlaceOrderName.name(), mySymbol,
						theOrderType.name(), -myOrderVolume, myOrderPrice);
			
			theOrderHandler.placeOrder(myOrderId, theStrategyName, 
					theSymbolContractMap.get(mySymbol), mySpreadOrder, this);
		}
	}
	
	// ------------------------------------------------------------------------------
	// Private methods
	
	/**
	 * Spread is per 1 portfolio volume
	 * @return
	 */
	private Spread getSpread() {
		
		double myBuySpread = 0;
		double mySellSpread = 0;
		boolean myIsBuyTradeable = true;
		boolean myIsSellTradeable = true;
		int myCount = 0;
		double myTimestamp = Double.MIN_VALUE;
		for (double[] myData : theSymbolDataMap.values()) {
			if (myData[COL_BidP] == 0 || myData[COL_AskP] == 0) {// Invalid data
				return new Spread(0, 0, 0, 0, false, false);
			}
			myTimestamp = Math.max(myTimestamp, myData[Col_Timestamp]);
			double myWeight = theWeights[myCount];
			double myMinMarketVolume = theMinMarketVolume[myCount];
			
			if (myWeight > 0) {
				myBuySpread = myBuySpread + myData[COL_AskP] * myWeight;
				myIsBuyTradeable = myIsBuyTradeable && (myData[COL_AskV] >= myMinMarketVolume);
				mySellSpread = mySellSpread + myData[COL_BidP] * myWeight;
				myIsSellTradeable = myIsSellTradeable && (myData[COL_BidV] >= myMinMarketVolume);
			} else {
				myBuySpread = myBuySpread + myData[COL_BidP] * myWeight;
				myIsBuyTradeable = myIsBuyTradeable && (myData[COL_BidV] >= myMinMarketVolume);
				mySellSpread = mySellSpread + myData[COL_AskP] * myWeight;
				myIsSellTradeable = myIsSellTradeable && (myData[COL_AskV] >= myMinMarketVolume);
			}
			myCount ++;
		}
		
		myBuySpread = myBuySpread - theFittedPremium;
		mySellSpread = mySellSpread - theFittedPremium;
		
		return new Spread(myTimestamp, myBuySpread, mySellSpread, (myBuySpread + mySellSpread) * 0.5, 
				myIsBuyTradeable, myIsSellTradeable);
	}
	
	// ------------------------------------------------------------------------------
	// Fields
	public Logger theLogger = (Logger) LogManager.getLogger();
	
	protected double theFittedPremium = 0;
	protected double[] theWeights;
	
	
	// FitterAdj
	protected FitterAdj theFitterAdj = null;
	protected double theMaxMultiplier = 2.0;
	
	protected String theStrategyName;
	
	// This is updated when you place the order for portfolio
	protected Spread theCurrSpread = null;
	protected Spread thePrevSpread = null;
	
	private double thePortfolioRealizedPnL = 0;
	private boolean theNotifyCloseOut = true;
	
	// Premium plot
	public boolean theShowPremiumPlot = false;
	public DynamicXYPlot thePremiumPlot = null;
	
	// Data map indexing
	private static int Col_Timestamp = 0;
	private static int COL_Time = 1;
	private static int COL_BidP = 2;
	private static int COL_BidV = 3;
	private static int COL_AskP = 4;
	private static int COL_AskV = 5;
	private static int COL_MidP = 6;
	
	
}

package strategy.spreadtrade;

import com.ib.client.Contract;


public class SpreadTradeBuilder {
	
	public SpreadTradeBuilder() {
		
	}
	
	public SpreadTradeBuilder contract(Contract[] aContract) {
		theContract = aContract;
		return this;
	}
	
	public SpreadTradeBuilder weight(double[] aWeights) {
		theWeight = aWeights;
		return this;
	}
	
	public SpreadTradeBuilder volumePerTrade(int aVolumePerTrade) {
		theVolumePerTrade = aVolumePerTrade;
		return this;
	}
	
	public SpreadTradeBuilder minMarketVolume(int[] aMinMarketValume) {
		theMinMarketVolume = aMinMarketValume;
		return this;
	}
	
	public SpreadTrade build () throws Exception{
		return new SpreadTrade(theContract, theWeight, theVolumePerTrade, theMinMarketVolume);
	}
	
	private Contract[] theContract;
	private double[] theWeight;
	private int theVolumePerTrade = 10;
	private int[] theMinMarketVolume = null;

}

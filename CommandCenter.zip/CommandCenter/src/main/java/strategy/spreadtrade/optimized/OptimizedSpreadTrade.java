package strategy.spreadtrade.optimized;

import order.OrderHandler;
import plot.DynamicXYPlot;

import com.ib.client.Contract;

import control.Controller;
import feed.FeedHandler;
import fit.EMAFitter;
import fit.FitterAdj;
import report.Reporter;
import strategy.PositionAdj;
import strategy.AbstractStrategy.Type;
import strategy.spreadtrade.SpreadTrade;
import strategy.spreadtrade.SpreadTradeBuilder;

public class OptimizedSpreadTrade {
	
	public static SpreadTrade OpeningHour_ES_NQ(
			Contract[] aContracts, FeedHandler aFeedHandler, OrderHandler aOrderHandler,
			Reporter aReporter, Controller aController) throws Exception{
		
		// Fitter
		double myHalflife = 300 * 1e3;
		long myInitFitTime = 30000;
		EMAFitter myFitter = new EMAFitter(myHalflife, myInitFitTime);
		myFitter.setAbsUpdateVal(0);
		
		// PositionAdj
		double myOpenMinProfit = 75;
		double myCloseMinProfit = 0;
		double myAdjustment = 50;
		int myMaxPos = 1;
		double myStopLossTrigger = 200;
		double myStopLoss = 150;
		PositionAdj myPositionAdj = new PositionAdj(myOpenMinProfit, myCloseMinProfit, 
				myAdjustment, myMaxPos);

		myPositionAdj.setStopLoss(myStopLossTrigger, myStopLoss);

		// SpreadTrade
		double [] myWeights = new double[] {2, -1};
		int myPortfolioVolume = 1;
		SpreadTradeBuilder mySTB = new SpreadTradeBuilder();
		SpreadTrade mySpreadTrade = mySTB.contract(aContracts).weight(myWeights)
				.volumePerTrade(myPortfolioVolume)
				.minMarketVolume(new int[] {50, 5}).build();

		// FitterAdj
		EMAFitter myBaseFitter = new EMAFitter(2 * 1e3, myInitFitTime);
		myBaseFitter.setAbsUpdateVal(0);
		FitterAdj myFitterAdj = new FitterAdj(myBaseFitter);
		myFitterAdj.addAdjMomentTrigger(30, 10 * 1e3);

		mySpreadTrade.init(aFeedHandler, aOrderHandler, myFitter, myPositionAdj);
		mySpreadTrade.setReporter(aReporter);
		mySpreadTrade.setController(aController);
		mySpreadTrade.setDynamicXYPlot(DynamicXYPlot.PlotType.SpreadTrade);
		mySpreadTrade.setOrderType(Type.MKT);
		mySpreadTrade.setCloseOutPosTime(103000.0);
		mySpreadTrade.setLoadTradeToDatbase(false);
		mySpreadTrade.setFitOnlyOnFlat(true);
		mySpreadTrade.setFitterResetOnClose(true);
		mySpreadTrade.setShowPremiumPlot(true);
		mySpreadTrade.setFitterAdj(myFitterAdj, 2.0);
				
		return mySpreadTrade;		
	}
	
}

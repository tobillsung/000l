package strategy.spreadtrade;

import order.BaseOrder;
import strategy.AbstractStrategy;
import strategy.AbstractStrategy.Action;

public class SpreadOrder extends BaseOrder {
	
	// Limit order
	public SpreadOrder(int aOrderId, AbstractStrategy.Type aOrderType, double aPrice, Action aAction, int aVolume) {
		
		m_orderId = aOrderId;
		m_orderType = aOrderType.name();
		
		if (aOrderType == AbstractStrategy.Type.LMT)
			m_lmtPrice = aPrice;
		
		m_placedPrice = aPrice;		
		
		m_action = aAction.name();
		m_totalQuantity = aVolume;
	}
	
	public void setMarketVolumeOnSide(double aMarketVolumeOnSide) {
		m_marketVolumeOnSide = aMarketVolumeOnSide;
	}
}

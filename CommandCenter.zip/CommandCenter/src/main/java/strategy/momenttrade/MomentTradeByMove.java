package strategy.momenttrade;

import java.util.Date;
import java.util.LinkedList;

import order.OrderHandler;
import order.OrderManager;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

import plot.DynamicXYPlot;
import product.FeeManager;
import product.ProductManager;
import report.Reporter;
import strategy.AbstractStrategy;
import strategy.PositionAdj;
import strategy.spreadtrade.SpreadOrder;
import util.CSVHelper;
import util.MySqlHelper;
import util.TimeConv;

import com.ib.client.Contract;

import feed.FeedHandler;
import feed.RetailState.Data;
import fit.Fittable;

public class MomentTradeByMove extends AbstractStrategy {

	public MomentTradeByMove() {
		
	}
	
	public MomentTradeByMove(Contract aContract, int aVolumePerTrade, int aMinMarketVolume, double aCheckHorizon) {
		theVolumePerTrade = aVolumePerTrade;
		theMinMarketVolume = new int[] {aMinMarketVolume};
		theCheckHorizon = aCheckHorizon;
		
		// Init all maps
		theMySqlHelper = new MySqlHelper();
		
		theTradeSymbol = ProductManager.getSymbolByContract(aContract);
		theSymbolContractMap.put(theTradeSymbol, aContract);

		String[][] myRes = theMySqlHelper.select("Product", "Detail", 
				new String[] {"Multiplier"}, "Symbol = '" + theTradeSymbol +"';" );

		theContractSizeMap.put(theTradeSymbol, Double.valueOf(myRes[0][0]));

		// theSymbolDataMap(timestamp, time, bidP, bidV, askP, askV, midP)
		// bidP, askP, midP are with the contract size
		theSymbolDataMap.put(theTradeSymbol, new double[] {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0});
		theOrderFilled.add(true);
		theSymbolOrderFilledMap.put(theTradeSymbol, false);

		theRoundTradeVolumeMap.put(theTradeSymbol, (double) theVolumePerTrade);
		
		double myFeePerTrade = FeeManager.getFeeStructure(
				ProductManager.getTickerBySymbol(theTradeSymbol)).getTotFee() * Math.abs(theRoundTradeVolumeMap.get(theTradeSymbol));
		theFeePerPortfolioTrade = theFeePerPortfolioTrade + myFeePerTrade; 
		theSymbolFeeMap.put(theTradeSymbol, myFeePerTrade);

		// Logs
		theLogger.info("{} - TradeVolume: {}", theTradeSymbol, theRoundTradeVolumeMap.get(theTradeSymbol));
		theLogger.info("{} - MinMarketVolume: {}", theTradeSymbol, theMinMarketVolume[0]);
		theLogger.info("{} - Contract size: {}", theTradeSymbol, theContractSizeMap.get(theTradeSymbol));
		theLogger.info("{} - Fee per trade: {}", theTradeSymbol, myFeePerTrade);
	}
	
	@Override
	public void init(FeedHandler aFeedHandler, OrderHandler aOrderHandler,
			Fittable aFitter, PositionAdj aPositionAdj) {
		synchronized (this) {
			
			theFeedHandler = aFeedHandler;
			theOrderHandler = aOrderHandler;	
			theStrategyName = getStrategyName();
			
			// Request data from FeedHandler
			theFeedHandler.reqRetailStateUpdate(
					theSymbolContractMap.values().toArray(new Contract[theSymbolContractMap.size()]), this);
			
			theFitter = aFitter;
			thePositionAdj = aPositionAdj;

			CSVHelper.write(getCSVFileName(), "Date,Time,Strategy,Pos,Ticker,"
					+ "MarketT,MarketP,MarketV,TradeP,TradeV,RealizedPnL,Fee,RealizedPnLWithFee", true);
			
		}
		
	}

	@Override
	public void run() {
		synchronized(this) {
			
			addNewItemToReporter(0, 0);
			updateItemToController();
			
			synchronized (this) {
				
				long myInitFitTime = theFitter.initFitTime();
				if (theFitter.initFitVal() == 0 && myInitFitTime > 0) {
					theLogger.info("Wait {} second for fitting", myInitFitTime / 1e3);
				} else {
					theFittedVal = new double[] {0.0, theFitter.initFitVal()};
					theStatus = Status.Running;
					theLogger.info("InitFit is finished with FitVal: {}", String.format("%.2f", theFittedVal));
					theLogger.info("Status: {}", Status.Running.name());
					updateItemToController();
				}
			}
			
			while (theStatus != Status.Done && theStatus != Status.Error) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	
		if (theStatus == Status.Done) {
			updateItemToController();
			theLogger.info(theStrategyName + " is done");
			theOrderHandler.insertOrderState(theStrategyName);
			if (theLoadTradeToDatabase) {
				theLogger.info("Loading trade csv file into database");
				theMySqlHelper.loadCSVToTable(getCSVFileName(), MySqlHelper.TradeTable, false, true);
			}
			
			Reporter.Summary mySummary = getTradeSummary();
			
			theLogger.info("Trading summary");
			theLogger.info("Remaining BuyN: {}", mySummary.theCumulativeBuyN);
			theLogger.info("Remaining SellN: {}", mySummary.theCumulativeSellN);
			theLogger.info("Remaining Pos: {}", mySummary.theCumulativePos);
			theLogger.info("FlatPnLWithFee: {}", mySummary.theCumulativeFlatPnL - mySummary.theCumulativeFee);
		}
	}

	@Override
	public void newRetailState(String aSymbol, Data aNewData) {
		synchronized (this) {
			
			double myContractSize = theContractSizeMap.get(aSymbol);
			double[] myDateArray = TimeConv.UnixT.toDateArray(aNewData.getTime());
			theSymbolDataMap.put(aSymbol, 
					new double[] {
					aNewData.getTime(), myDateArray[1],
					aNewData.getBidP() * myContractSize,
					aNewData.getBidV(),
					aNewData.getAskP() * myContractSize,
					aNewData.getAskV(),
					aNewData.getMid() * myContractSize});
			
			if (thePlotType != null) {
				if (theDynamicXYPlot == null) {
					double [] myTradeData = theSymbolDataMap.get(theTradeSymbol);
					long myTimestamp = (long) myTradeData[Col_Timestamp];
					double myMidP = myTradeData[COL_MidP] / myContractSize;
					
					double[] myTDateArray = TimeConv.UnixT.toDateArray(myTimestamp);
					theDynamicXYPlot = new DynamicXYPlot("TradeSymbol_" + theStrategyName + " [" + (int) myTDateArray[0] + "]", 
							DynamicXYPlot.PlotType.RetailState, new Date(myTimestamp - 1000), 
							new double[] {myMidP, myMidP, myMidP, myMidP, myMidP});
					theDynamicXYPlot.init();
					theLogger.info("TradeSymbolPlot is initialized");
				} else if (theDynamicXYPlot.theStatus == DynamicXYPlot.Status.Disposed) {
					thePlotType = null; // If you want to reopen the plot rerun setPlotType
				}
			}
			
			if (theStatus == Status.Done || theStatus == Status.Error) {
				return;
			}
			
			
			// Even though I have order working, I update the fit with new data
			if (thePlaceOrderStatus == PlaceOrderStatus.Close) { 
				fit(theFitter); // Run fit but don't update the theFittedConst
				
				return; // PlaceOrderStatus is closed, so don't send any orders
			}
			
			// Update fit based on theStatus
			if (theStatus == Status.Init) {
				long myCurrTime = aNewData.getTime();
				if (theInitFitStopTime == 0) {
					theInitFitStopTime = aNewData.getTime() + theFitter.initFitTime();
				} 
				// Run initFit
				if (myCurrTime <= theInitFitStopTime){
					theFittedVal = new double[] {aNewData.getTime(), fit(theFitter)};
					return; // This is init phase, so don't send any orders
				} else {
					if (theStatus == Status.Init) {
						theStatus = Status.Running;
						theLogger.info("InitFit is finished with FitVal: {}", String.format("%.2f", theFittedVal[FitterVal_Fit]));
						theLogger.info("Status: {}", Status.Running.name());
						updateItemToController();
					}
				}
			} else { // Status is Running or Pause or FinalTrade
				theFittedVal = new double[] {aNewData.getTime(), fit(theFitter)};
			}
			
			// Check for CloseOutPos
			checkCloseOutPosTime(aNewData);
			if (theStatus == Status.FinalTrade) {
				if (theCumulativePos == 0) {
					theLogger.info("Cumulative position is flat and stopping trade at {}", theCloseOutPosTime);
					setStatus(Status.Done);
					this.notify();
				} else if (theNotifyCloseOut){
					theLogger.info("Starting to close out position at {} for remaining position [{}]", 
							theCloseOutPosTime, theCumulativePos);
					theNotifyCloseOut = false;
					updateItemToController();
				}
			}

			// Calculate move
			theMove = calcMove(aNewData.getTime());

			// Check for opportunity
			checkOpportunity();


		}
		
	}

	@Override
	public void newLastDone(String aSymbol, feed.LastDone.Data aNewData) {
		// For now, MomentTrade does not use last done information
	}

	@Override
	public void newOrderManager(OrderManager aOrderManager) {
		synchronized (this) {

			if (aOrderManager.theStatus == OrderHandler.Status.Inactive || 
					aOrderManager.theStatus == OrderHandler.Status.Error) {
				theLogger.error("Order status: {}", aOrderManager.theStatus.name());
				this.setStatus(Status.Error);
				this.notify();
				return;
			}

			theSymbolOrderFilledMap.put(aOrderManager.theSymbol, true);

			String mySymbol = aOrderManager.theSymbol;
			int myVolume = 0;			
			theLastTradeTimestamp = aOrderManager.theTime;
			theLastTradeP = aOrderManager.theFilledP;
			Action myAction = Action.valueOf(aOrderManager.theOrder.m_action);

			if (myAction == Action.Buy) {
				myVolume = aOrderManager.theOrder.m_totalQuantity;
			} else {
				myVolume = - aOrderManager.theOrder.m_totalQuantity;
			}

			int myCurrPortPos = theNextCumulativePos - theCumulativePos;

			double[] myData = theSymbolDataMap.get(mySymbol);
			int myPortfolioPos = myVolume / theRoundTradeVolumeMap.get(mySymbol).intValue();

			theLogger.info("[{}] filled: {} @ {}", mySymbol, myVolume, theLastTradeP);

			double[] myDateTime = TimeConv.UnixT.toDateArray(aOrderManager.theTime);

			// Realized PnL from TradeP and TradeV
			double myRealizedPnLPerSymbol = theLastTradeP * (- myVolume) * theContractSizeMap.get(mySymbol);

			// Fee
			double myFeePerSymbol = theSymbolFeeMap.get(mySymbol);

			StringBuilder myCSVSb = new StringBuilder(); 
			myCSVSb.append(myDateTime[0] + ",");
			myCSVSb.append(myDateTime[1] + ",");
			myCSVSb.append(theStrategyName + ",");
			myCSVSb.append(myPortfolioPos + ",");
			myCSVSb.append(ProductManager.getTickerBySymbol(mySymbol) + ",");
			myCSVSb.append(myData[COL_Time] + ",");
			myCSVSb.append(aOrderManager.theOrder.m_placedPrice + ",");
			myCSVSb.append(aOrderManager.theOrder.m_marketVolumeOnSide + ",");
			myCSVSb.append(theLastTradeP + ",");
			myCSVSb.append(myVolume + ",");
			myCSVSb.append(myRealizedPnLPerSymbol + ",");
			myCSVSb.append(myFeePerSymbol + ",");
			myCSVSb.append(myRealizedPnLPerSymbol - myFeePerSymbol + "\n");

			CSVHelper.write(getCSVFileName(), myCSVSb.toString(), true);

			// Check for all filled
			if (CollectionUtils.isEqualCollection(theOrderFilled, theSymbolOrderFilledMap.values())) {
				for (String mySymbolElem : theSymbolOrderFilledMap.keySet()) 
					theSymbolOrderFilledMap.put(mySymbolElem, false);

				// Plot the trade
				if (theDynamicXYPlot != null && theDynamicXYPlot.theStatus == DynamicXYPlot.Status.Running) {
					
					double [] myTradeData = theSymbolDataMap.get(theTradeSymbol);
					double myContractSize = theContractSizeMap.get(theTradeSymbol);
					long myTimestamp = (long) myTradeData[Col_Timestamp];
					double myBidP = myTradeData[COL_BidP] / myContractSize;
					double myAskP = myTradeData[COL_BidP] / myContractSize;
					
					if (thePortfolioAction == Action.Buy) {
						theDynamicXYPlot.addNewDataset(new Date(myTimestamp), 
								new double[] {myBidP, myAskP, theLastTradeP, theLastTradeP});
					} else {
						theDynamicXYPlot.addNewDataset(new Date(myTimestamp), 
								new double[] {myBidP, myAskP, theLastTradeP, Double.NaN, theLastTradeP});
					} 
				}


				// Update the current cumulative portfolio position
				theCumulativePos = theNextCumulativePos; 

				// Add new item to reporter
				addNewItemToReporter(myCurrPortPos, myRealizedPnLPerSymbol);

				thePositionAdj.setReqProfit(theCumulativePos); // Update the req profit

				// Update Status
				if (theStatus == Status.FinalTrade) {
					theLogger.info("Closing out the position and stopping trade");
					theStatus = Status.Done;
					thePlaceOrderStatus = PlaceOrderStatus.Close;
					this.notify();
				} else {
					thePlaceOrderStatus = PlaceOrderStatus.Open;
					if (thePlaceOrderName == PlaceOrderName.Algo_StopLoss) {
						theStatus = Status.Running;
					} else {
						theStatus = Status.Running;
					}
				}

				// Update controller (Controller needs theStatus and theCumulativePos)
				updateItemToController();

				// This allows to recenter after the closing position
				if (theFitterResetOnClose && theCumulativePos == 0) {
					theFitter.reset(); 
				}
			}
		}
	}
	

	@Override
	public String getStrategyName() {
		synchronized (this) {
			
			String myStrategyName = "MT_" + ProductManager.getTickerBySymbol(theTradeSymbol) + "_Move";
			return myStrategyName;
		}
	}

	
	
	@Override
	public void placeManualOrder(int aPortfolioVolume) {
		synchronized (this) {
			
			int myMaxPos = (int)thePositionAdj.getMaxPos();
			if (aPortfolioVolume > 0) { // try to long
				if (theCumulativePos < myMaxPos) { 
					thePortfolioAction = Action.Buy;
					theNextCumulativePos = theCumulativePos + aPortfolioVolume;
					theStatus = Status.Running;
					thePlaceOrderName = PlaceOrderName.Manual;
					placePortfolioOrder(aPortfolioVolume);
				} else
					theLogger.warn("CumulativePos({}) is at the Max position({})", theCumulativePos, myMaxPos);
			} else { // try to short
				if (theCumulativePos > - myMaxPos) { // 
					thePortfolioAction = Action.Sell;
					theNextCumulativePos = theCumulativePos + aPortfolioVolume;
					theStatus = Status.Running;
					thePlaceOrderName = PlaceOrderName.Manual;
					placePortfolioOrder(aPortfolioVolume);
				} else
					theLogger.warn("CumulativePos({}) is at the Max position({})", theCumulativePos, myMaxPos);
			}
		}
		
	}

	@Override
	protected double fit(Fittable aAbstractFitter) {
		synchronized (this) {
			
			double myData[] = theSymbolDataMap.get(theTradeSymbol);
			
			if (myData[COL_BidP] == 0 || myData[COL_AskP] == 0) // Invalid data
				return 0;
			
			return aAbstractFitter.fit(new double[] {myData[Col_Timestamp], myData[COL_MidP]});
		}
	}
	
	@Override
	protected void placePortfolioOrder(int aPortfolioOrderVolume) {
		if (theStatus == Status.Pause || theStatus == Status.Done) {
			return; // Don't place order
		}
		
		thePlaceOrderStatus = PlaceOrderStatus.Close;
		
		
		int myOrderId = theOrderHandler.generateOrderId();
		double[] myData = theSymbolDataMap.get(theTradeSymbol);
		double myContractSize = theContractSizeMap.get(theTradeSymbol);
		double myTradeVolume = theRoundTradeVolumeMap.get(theTradeSymbol);

		// Init
		double myOrderPrice = 0.0;
		double myMarketVolumeOnSide = 0;
		Action myOrderAction = null;
		if (thePortfolioAction == Action.Buy) { // Portfolio buy: 
			myOrderPrice = myData[COL_AskP];
			myMarketVolumeOnSide = myData[COL_AskV];
			myOrderAction = Action.Buy; 
		} else { // Portfolio sell 
			myOrderPrice = myData[COL_BidP];
			myMarketVolumeOnSide = myData[COL_BidV];			
			myOrderAction = Action.Sell;
		} 

		myOrderPrice = myOrderPrice / myContractSize;
		int myOrderVolume = Math.abs((int) myTradeVolume * aPortfolioOrderVolume);

		SpreadOrder mySpreadOrder = 
				new SpreadOrder(myOrderId, theOrderType, myOrderPrice, myOrderAction, myOrderVolume);
		mySpreadOrder.setMarketVolumeOnSide(myMarketVolumeOnSide);
		mySpreadOrder.m_placeTime = (long) myData[Col_Timestamp];

		if (myOrderAction == Action.Buy)
			theLogger.info("{} Placing [{}] {} order: {} @ {}", thePlaceOrderName.name(), theTradeSymbol, 
					theOrderType.name(), myOrderVolume, myOrderPrice);
		else
			theLogger.info("{} Placing [{}] {} order: {} @ {}", thePlaceOrderName.name(), theTradeSymbol,
					theOrderType.name(), -myOrderVolume, myOrderPrice);

		theOrderHandler.placeOrder(myOrderId, theStrategyName, 
				theSymbolContractMap.get(theTradeSymbol), mySpreadOrder, this);
		
	}
	
	protected void checkOpportunity() {
		PositionAdj.Profit myReqProfit = thePositionAdj.getReqProfit();
		double myReqLongProfit = myReqProfit.reqLong();
		double myReqShortProfit = - myReqProfit.reqShort(); 
		double myStopLossTrigger = thePositionAdj.getStopLossTrigger();
		double myStopLoss = thePositionAdj.getStopLoss();
		
		double[] myCurrTradeData = theSymbolDataMap.get(theTradeSymbol);
		double myContractSize = theContractSizeMap.get(theTradeSymbol);
		double myTimestamp = myCurrTradeData[Col_Timestamp];
		double myCurrBidP = myCurrTradeData[COL_BidP] / myContractSize;
		double myCurrAskP = myCurrTradeData[COL_AskP] / myContractSize;
		
		// Expected profit is the profit of trading 1 portfolio volume
		double myExpProfit = 0.0;
		
		// Init next cumulative position
		theNextCumulativePos = theCumulativePos; 
		if (theCumulativePos == 0) { // Portfolio is flat
			
			if (theMove >= myReqLongProfit && isTradeable(Action.Buy) && 
					theConsecutiveOpenBuyN < theMaxConsecutiveOpenTradeN) {
				theNextCumulativePos ++;
				thePortfolioAction = Action.Buy;
				thePlaceOrderName = PlaceOrderName.Algo;
				placePortfolioOrder(1);
				theConsecutiveOpenBuyN++;
				theConsecutiveOpenSellN = 0;
			}
			else if (theMove <= myReqShortProfit && isTradeable(Action.Sell) &&
					theConsecutiveOpenSellN < theMaxConsecutiveOpenTradeN) {
				theNextCumulativePos --;
				thePortfolioAction = Action.Sell;
				thePlaceOrderName = PlaceOrderName.Algo;
				placePortfolioOrder(-1);
				theConsecutiveOpenBuyN = 0;
				theConsecutiveOpenSellN++;
			}
		} else if (theCumulativePos > 0) { // Portfolio is long
			myReqShortProfit = - myReqShortProfit; // Make required short positive
			
			myExpProfit = (myCurrBidP - theLastTradeP) * myContractSize;
			if (myExpProfit >= myReqShortProfit && isTradeable(Action.Sell)) {
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Sell;
				thePlaceOrderName = PlaceOrderName.Algo;
				placePortfolioOrder(-1);
				//theFitterValList.clear();
				theConsecutiveOpenSellN++; // Open trade should be sell
			} else if (theMove <= - myReqShortProfit) { // Now momentum change
				theIsStopLossTriggered = false;
				theLogger.info("Moment is change from Buy to Sell");
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Sell;
				thePlaceOrderName = PlaceOrderName.Algo_StopLoss;
				placePortfolioOrder(-1);
				//theFitterValList.clear();
				theConsecutiveOpenSellN++; // Open trade should be sell
			} else if (!theIsStopLossTriggered && myExpProfit <= - myStopLossTrigger) {
				theIsStopLossTriggered = true;
				theLogger.info("StopLoss logic is triggered at {}", - myStopLoss);
			} else if (theIsStopLossTriggered && myExpProfit >= -myStopLoss) { // Reached stoploss, so close out all position and reset fitter
				theIsStopLossTriggered = false;
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Sell;
				thePlaceOrderName = PlaceOrderName.Algo_StopLoss;
				placePortfolioOrder(-1);
				//theFitterValList.clear();
				theConsecutiveOpenSellN++; // Open trade should be sell
			} else if (myTimestamp - theLastTradeTimestamp >= theTimeOutHorizon) {
				theIsStopLossTriggered = false;
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Sell;
				thePlaceOrderName = PlaceOrderName.Algo_TimeOut;
				placePortfolioOrder(-1);
				//theFitterValList.clear();
			}
		} else if (theCumulativePos < 0) { // Portfolio is short

			myExpProfit = (theLastTradeP - myCurrAskP) * myContractSize;			

			if (myExpProfit >= myReqLongProfit && isTradeable(Action.Buy)) { // Spread becomes cheaper
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Buy;
				thePlaceOrderName = PlaceOrderName.Algo;
				placePortfolioOrder(1);
				//theFitterValList.clear();
			} else if (theMove >= myReqLongProfit) {
				theIsStopLossTriggered = false;
				theLogger.info("Moment is change from Sell to Buy");
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Buy;
				thePlaceOrderName = PlaceOrderName.Algo_StopLoss;
				placePortfolioOrder(1);
				//theFitterValList.clear();
				theConsecutiveOpenBuyN++; // The open trade should be buy
			} else if (!theIsStopLossTriggered && myExpProfit <= - myStopLossTrigger) { // Reached stoploss, so close out all position and reset fitter
				theIsStopLossTriggered = true;
				theLogger.info("StopLoss logic is triggered at {}", myStopLoss);
			} else if(theIsStopLossTriggered && myExpProfit >= -myStopLoss) {
				theIsStopLossTriggered = false;
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Buy;
				thePlaceOrderName = PlaceOrderName.Algo_StopLoss;
				placePortfolioOrder(1);
				//theFitterValList.clear();
				theConsecutiveOpenBuyN++; // The open trade should be buy
			} else if (myTimestamp - theLastTradeTimestamp >= theTimeOutHorizon) {
				theIsStopLossTriggered = false;
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Buy;
				thePlaceOrderName = PlaceOrderName.Algo_TimeOut;
				placePortfolioOrder(1);
				//theFitterValList.clear();
			}
		}
		
		if (theDynamicXYPlot != null && theDynamicXYPlot.theStatus == DynamicXYPlot.Status.Running) {
			
			if (theCumulativePos == 0) {
				theDynamicXYPlot.addNewDataset(new Date((long)myTimestamp), new double[] {myCurrBidP, myCurrAskP});
			} else if (theCumulativePos > 0) {
				double myNextTradeP = myReqShortProfit / myContractSize + theLastTradeP;
				theDynamicXYPlot.addNewDataset(new Date((long)myTimestamp), new double[] {myCurrBidP, myCurrAskP, myNextTradeP});
			} else if (theCumulativePos < 0) {
				double myNextTradeP = theLastTradeP - myReqLongProfit / myContractSize;
				theDynamicXYPlot.addNewDataset(new Date((long)myTimestamp), new double[] {myCurrBidP, myCurrAskP, myNextTradeP});
			}
		}
	}
	
	private double calcMove(double aCurrTime) {
		
		theFitterValList.addFirst(theFittedVal);
		
		for (int i = theFitterValList.size() - 1 ; i >= 0; i-- ) {
			
			if (theFitterValList.get(i)[FitterVal_Time] < aCurrTime - theCheckHorizon) {
				theFitterValList.remove(i);
			} else {
				break;
			}
		}
		
		double myFitterValRecordTime = 
				theFitterValList.getFirst()[FitterVal_Time] - theFitterValList.getLast()[FitterVal_Time];
		if (myFitterValRecordTime >= theCheckHorizon * 0.8) {
			return theFitterValList.getFirst()[FitterVal_Fit] - theFitterValList.getLast()[FitterVal_Fit];
		} else {
			return 0;
		}
		
	}
	
	private boolean isTradeable(AbstractStrategy.Action aTargetAction) {
		
		double myCurrBidV = theSymbolDataMap.get(theTradeSymbol)[COL_BidV];
		double myCurrAskV = theSymbolDataMap.get(theTradeSymbol)[COL_AskV];
		
		// Init
		boolean myIsTradeable = true;
		if (theOrderType ==  AbstractStrategy.Type.LMT) {
			if (aTargetAction == AbstractStrategy.Action.Buy) {
				myIsTradeable = myCurrBidV >= theMinMarketVolume[0];
			} else {
				myIsTradeable = myCurrAskV >= theMinMarketVolume[0];
			}
		} else {				
			if (aTargetAction == AbstractStrategy.Action.Buy) {
				myIsTradeable = myCurrAskV >= theMinMarketVolume[0];
			} else {
				myIsTradeable = myCurrBidV >= theMinMarketVolume[0];
			}
		}
		
		return myIsTradeable;
	}

	// ------------------------------------------------------------------------------
	// Fields
	public Logger theLogger = (Logger) LogManager.getLogger();
	
	public String theTradeSymbol = "";
	
	protected String theStrategyName = "";
	
	protected double theCheckHorizon = 0;
	
	private boolean theNotifyCloseOut = true;
	
	// Related to Fitter
	private double[] theFittedVal = new double[2];
	private int FitterVal_Time = 0;
	private int FitterVal_Fit = 1;
	private LinkedList<double [] > theFitterValList = new LinkedList<double []>();
	
	// CheckOpportunity 
	private double theMove = 0.0;
	private double theLastTradeTimestamp = 0.0;
	private double theLastTradeP = 0.0;
	private int theConsecutiveOpenBuyN = 0;
	private int theConsecutiveOpenSellN = 0;
	
	
	// Data map indexing
	private static int Col_Timestamp = 0;
	private static int COL_Time = 1;
	private static int COL_BidP = 2;
	private static int COL_BidV = 3;
	private static int COL_AskP = 4;
	private static int COL_AskV = 5;
	private static int COL_MidP = 6;
	
}

package strategy.momenttrade;

import com.ib.client.Contract;

public class MomentTradeBySpreadBuilder {
	public MomentTradeBySpreadBuilder() {
	}
	
	public MomentTradeBySpreadBuilder contract(Contract[] aContract) {
		theContract = aContract;
		return this;
	}
	
	public MomentTradeBySpreadBuilder weight(double[] aWeights) {
		theWeight = aWeights;
		return this;
	}
	
	public MomentTradeBySpreadBuilder volumePerTrade(int aVolumePerTrade) {
		theVolumePerTrade = aVolumePerTrade;
		return this;
	}
	
	public MomentTradeBySpreadBuilder minMarketVolume(int aMinMarketValume) {
		theMinMarketVolume = aMinMarketValume;
		return this;
	}
	
	public MomentTradeBySpreadBuilder tradeIdx(int aTradeIdx) {
		theTradeIdx = aTradeIdx;
		return this;
	}
	
	
	public MomentTradeBySpread build () throws Exception{
		return new MomentTradeBySpread(theContract, theWeight, theTradeIdx, theVolumePerTrade, theMinMarketVolume);
	}
	
	private Contract[] theContract;
	private double[] theWeight;
	private int theTradeIdx = 0;
	private int theVolumePerTrade = 10;
	private int theMinMarketVolume = 10;

}

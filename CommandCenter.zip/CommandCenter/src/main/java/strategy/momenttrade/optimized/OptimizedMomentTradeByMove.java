package strategy.momenttrade.optimized;

import order.OrderHandler;
import plot.DynamicXYPlot;
import report.Reporter;
import strategy.AbstractStrategy.Type;
import strategy.PositionAdj;
import strategy.momenttrade.MomentTradeByMove;
import strategy.momenttrade.MomentTradeByMoveBuilder;

import com.ib.client.Contract;

import control.Controller;
import feed.FeedHandler;
import fit.EMAFitter;

public class OptimizedMomentTradeByMove {

	public static MomentTradeByMove ES(
			Contract aContracts, FeedHandler aFeedHandler, OrderHandler aOrderHandler,
			Reporter aReporter, Controller aController) throws Exception{
		
		// Fitter
		EMAFitter myFitter = new EMAFitter(5 * 1e3, 30000);
		myFitter.setAbsUpdateVal(0);

		// PositionAdj
		double myOpenMinProfit = 0.25 * 50 * 4; // the moment for 2-minute
		double myCloseMinProfit = 0.25 * 50 * 4;
		double myAdjustment = 50;
		double myStopLossTrigger = 150;
		double myStopLoss = 150;
		int myMaxPos = 1;
		PositionAdj myPositionAdj = new PositionAdj(myOpenMinProfit, myCloseMinProfit, 
				myAdjustment, myMaxPos);
		myPositionAdj.setStrategy(PositionAdj.Strategy.MomentTrade);
		myPositionAdj.setStopLoss(myStopLossTrigger, myStopLoss);

		// MomentTradeByMove
		int myPortfolioVolume = 1;
		double myCheckHorizon = 30 * 1e3; // 5-minute check
		double myTimeOutHorizon = 10 * 60 * 1e3; // 30 minutes
		int myMaxConsecutiveOpenTradeN = 4;
		
		MomentTradeByMoveBuilder myMTBM = new MomentTradeByMoveBuilder();
		MomentTradeByMove myMomentTradeByMove = myMTBM.contract(aContracts)
				.volumePerTrade(myPortfolioVolume).horizon(myCheckHorizon)
				.minMarketVolume(50).build();
		
		myMomentTradeByMove.init(aFeedHandler, aOrderHandler, myFitter, myPositionAdj);
		myMomentTradeByMove.setReporter(aReporter);
		myMomentTradeByMove.setController(aController);
		myMomentTradeByMove.setOrderType(Type.LMT); // Limit order to cross
		myMomentTradeByMove.setDynamicXYPlot(DynamicXYPlot.PlotType.RetailState);
		myMomentTradeByMove.setCloseOutPosTime(103000.0);
		myMomentTradeByMove.setFitterResetOnClose(false);
		myMomentTradeByMove.setFitOnlyOnFlat(false);
		myMomentTradeByMove.setTimeOutHorizon(myTimeOutHorizon);
		myMomentTradeByMove.setMaxConsecutiveOpenTradeN(myMaxConsecutiveOpenTradeN);
		
		return myMomentTradeByMove;
	}
}

package strategy.momenttrade.optimized;

import order.OrderHandler;
import plot.DynamicXYPlot;
import report.Reporter;
import strategy.AbstractStrategy.Type;
import strategy.PositionAdj;
import strategy.momenttrade.MomentTradeBySpread;
import strategy.momenttrade.MomentTradeBySpreadBuilder;

import com.ib.client.Contract;

import control.Controller;
import feed.FeedHandler;
import fit.EMAFitter;

public class OptimizedMomentTradeBySpread {

	public static MomentTradeBySpread OpeningHour_ES_NQ(
			Contract[] aContracts, FeedHandler aFeedHandler, OrderHandler aOrderHandler,
			Reporter aReporter, Controller aController) throws Exception{
		
		// Fitter
		EMAFitter myFitter = new EMAFitter(300 * 1e3, 30000);
		myFitter.setAbsUpdateVal(0);

		// PositionAdj
		double myOpenMinProfit = 75;
		double myCloseMinProfit = 50;
		double myAdjustment = 50;
		double myStopLossTrigger = 150;
		double myStopLoss = 150;
		int myMaxPos = 1;
		PositionAdj myPositionAdj = new PositionAdj(myOpenMinProfit, myCloseMinProfit, 
				myAdjustment, myMaxPos);
		myPositionAdj.setStrategy(PositionAdj.Strategy.MomentTrade);
		myPositionAdj.setStopLoss(myStopLossTrigger, myStopLoss);

		// MomentTradeBySpread
		double [] myWeights = new double[] {2, -1};
		int myPortfolioVolume = 2;
		MomentTradeBySpreadBuilder myMTBS = new MomentTradeBySpreadBuilder();
		MomentTradeBySpread myMomentTradeBySpread = myMTBS.contract(aContracts).weight(myWeights)
				.volumePerTrade(myPortfolioVolume)
				.minMarketVolume(50).tradeIdx(0).build();
		
		myMomentTradeBySpread.init(aFeedHandler, aOrderHandler, myFitter, myPositionAdj);
		myMomentTradeBySpread.setReporter(aReporter);
		myMomentTradeBySpread.setController(aController);
		myMomentTradeBySpread.setOrderType(Type.LMT); // Limit order to cross
		myMomentTradeBySpread.setDynamicXYPlot(DynamicXYPlot.PlotType.SpreadTrade);
		myMomentTradeBySpread.setCloseOutPosTime(103000.0);
		myMomentTradeBySpread.setFitterResetOnClose(false);
		myMomentTradeBySpread.setFitOnlyOnFlat(false);
		
		return myMomentTradeBySpread;
	}
}

package strategy.momenttrade;

import com.ib.client.Contract;

public class MomentTradeByMoveBuilder {
	public MomentTradeByMoveBuilder() {
	}
	
	public MomentTradeByMoveBuilder contract(Contract aContract) {
		theContract = aContract;
		return this;
	}
	
	public MomentTradeByMoveBuilder volumePerTrade(int aVolumePerTrade) {
		theVolumePerTrade = aVolumePerTrade;
		return this;
	}
	
	public MomentTradeByMoveBuilder minMarketVolume(int aMinMarketValume) {
		theMinMarketVolume = aMinMarketValume;
		return this;
	}
	
	public MomentTradeByMoveBuilder horizon(double aHorizon) {
		theHorizon = aHorizon;
		return this;
	}
	
	
	public MomentTradeByMove build () throws Exception{
		return new MomentTradeByMove(theContract, theVolumePerTrade, theMinMarketVolume, theHorizon);
	}
	
	private Contract theContract;
	private double theHorizon = 2000;
	private int theVolumePerTrade = 10;
	private int theMinMarketVolume = 10;

}

package strategy.momenttrade;

import java.util.Date;

import order.OrderHandler;
import order.OrderManager;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

import plot.DynamicXYPlot;
import product.FeeManager;
import product.ProductManager;
import strategy.PositionAdj;
import strategy.spreadtrade.SpreadOrder;
import strategy.spreadtrade.SpreadTrade;
import util.CSVHelper;
import util.MySqlHelper;
import util.TimeConv;

import com.ib.client.Contract;

/**
 * MomentTradeBySpread
 * Triggered by Spread
 * If Spread > some positive number (req short) then it is expected that Spread would be increasing
 * If weight on the trade index is positive then long for the upward momentum
 * If weight on the trade index is negative then short 
 * @author bill
 *
 */
public class MomentTradeBySpread extends SpreadTrade{

	/**
	 * Create spread from aContracts but only trade the first contract
	 * @param aContracts
	 * @param aWeights
	 * @param aVolumePerTrade
	 * @param aMinMarketVolume
	 */
	public MomentTradeBySpread(Contract[] aContracts, double[] aWeights, int aTradeIdx, int aVolumePerTrade, int aMinMarketVolume) {
		theWeights = aWeights;
		theVolumePerTrade = aVolumePerTrade;
		theMinMarketVolume = new int[aWeights.length];
		for (int i = 0 ; i < theMinMarketVolume.length ; i++) {
			theMinMarketVolume[i] = aMinMarketVolume; // It is okay, I don't even check min market volume for non-trading index
		}
		
		
		if (aContracts.length != aWeights.length)
			throw new IllegalArgumentException("length of aContracts and aWeights should be same");
		
		// Init all maps
		theMySqlHelper = new MySqlHelper();
		for (int i = 0 ; i < aContracts.length ; i++) {
			String mySymbol = ProductManager.getSymbolByContract(aContracts[i]);
			theSymbolContractMap.put(mySymbol, aContracts[i]);
			
			String[][] myRes = theMySqlHelper.select("Product", "Detail", 
					new String[] {"Multiplier"}, "Symbol = '" + mySymbol +"';" );
			
			theContractSizeMap.put(mySymbol, Double.valueOf(myRes[0][0]));
			
			// theSymbolDataMap(timestamp, time, bidP, bidV, askP, askV, midP)
			// bidP, askP, midP are with the contract size
			theSymbolDataMap.put(mySymbol, new double[] {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0});
		
			if (i == aTradeIdx) {
				theTradeSymbol = mySymbol;
				theOrderFilled.add(true);
				theSymbolOrderFilledMap.put(mySymbol, false);

				theRoundTradeVolumeMap.put(mySymbol, (double) theVolumePerTrade);
				if (theRoundTradeVolumeMap.get(mySymbol) == 0) {
					theLogger.error("Volume for contract #{} is rzero", i);
					System.exit(0); // Stop everything !!!!
				}
			
				double myFeePerTrade = FeeManager.getFeeStructure(
						ProductManager.getTickerBySymbol(mySymbol)).getTotFee() * Math.abs(theRoundTradeVolumeMap.get(mySymbol));
				theFeePerPortfolioTrade = theFeePerPortfolioTrade + myFeePerTrade; 
				theSymbolFeeMap.put(mySymbol, myFeePerTrade);
			
				// Logs
				theLogger.info("{} - TradeVolume: {}", mySymbol, theRoundTradeVolumeMap.get(mySymbol));
				theLogger.info("{} - MinMarketVolume: {}", mySymbol, theMinMarketVolume[i]);
				theLogger.info("{} - Contract size: {}", mySymbol, theContractSizeMap.get(mySymbol));
				theLogger.info("{} - Fee per trade: {}", mySymbol, myFeePerTrade);
			}
		}
	}
	
	protected void checkOpportunity() {
		
		// Create required spread for long or short
		// myReqLongSpread is positive
		// myReqShortSpread is negative
		// Hoping it will continue in that direction

		PositionAdj.Profit myReqProfit = thePositionAdj.getReqProfit();
		double myReqLongProfit = myReqProfit.reqLong();
		double myReqShortProfit = - myReqProfit.reqShort(); 
		double myStopLossTrigger = thePositionAdj.getStopLossTrigger();
		double myStopLoss = thePositionAdj.getStopLoss();
		
		double[] myCurrTradeData = theSymbolDataMap.get(theTradeSymbol);
		double myContractSize = theContractSizeMap.get(theTradeSymbol);
		double myCurrBidP = myCurrTradeData[COL_BidP] / myContractSize;
		double myCurrBidV = myCurrTradeData[COL_BidV];
		double myCurrAskP = myCurrTradeData[COL_AskP] / myContractSize;
		double myCurrAskV = myCurrTradeData[COL_AskV];
		
		// Init next cumulative position
		theNextCumulativePos = theCumulativePos; 
		if (theCumulativePos == 0) { // Portfolio is flat
			if (theCurrSpread.buy() >= myReqLongProfit && theCurrSpread.isBuyTradeable()) { // Spread is cheap so enter long 
				theNextCumulativePos ++;
				thePortfolioAction = Action.Buy;
				thePlaceOrderName = PlaceOrderName.Algo;
				placePortfolioOrder(1);
			}
			else if (theCurrSpread.sell() <= myReqShortProfit && theCurrSpread.isSellTradeable()) {
				theNextCumulativePos --;
				thePortfolioAction = Action.Sell;
				thePlaceOrderName = PlaceOrderName.Algo;
				placePortfolioOrder(-1);
			}
		} else if (theCumulativePos > 0) { // Portfolio is long
			myReqShortProfit = - myReqShortProfit; // Make required short positive
		
			double myExpProfit = (myCurrBidP - theLastTradeP)  * myContractSize;
			boolean myIsTradeable = myCurrBidV >= theMinMarketVolume[0];
			
			if (myExpProfit >= myReqShortProfit && myIsTradeable) {
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Sell;
				thePlaceOrderName = PlaceOrderName.Algo;
				placePortfolioOrder(-1);
				theFitter.reset();
			} else if (!theIsStopLossTriggered && myExpProfit <= - myStopLossTrigger) {
				theIsStopLossTriggered = true;
				theLogger.info("StopLoss logic is triggered at {}", - myStopLoss);
			} else if (theIsStopLossTriggered && myExpProfit >= -myStopLoss) { // Reached stoploss, so close out all position and reset fitter
				theIsStopLossTriggered = false;
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Sell;
				thePlaceOrderName = PlaceOrderName.Algo_StopLoss;
				placePortfolioOrder(-1);
				theFitter.reset();
			}
		} else if (theCumulativePos < 0) { // Portfolio is short
			
			double myExpProfit = (theLastTradeP - myCurrAskP)  * myContractSize;
			boolean myIsTradeable = myCurrAskV >= theMinMarketVolume[0];
			
			if (myExpProfit >= myReqLongProfit && myIsTradeable) { // Spread becomes cheaper
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Buy;
				thePlaceOrderName = PlaceOrderName.Algo;
				placePortfolioOrder(1);
				theFitter.reset();
			} else if (!theIsStopLossTriggered && myExpProfit <= - myStopLossTrigger) { // Reached stoploss, so close out all position and reset fitter
				theIsStopLossTriggered = true;
				theLogger.info("StopLoss logic is triggered at {}", myStopLoss);
			} else if(theIsStopLossTriggered && myExpProfit >= -myStopLoss) {
				theIsStopLossTriggered = false;
				theNextCumulativePos = 0;
				thePortfolioAction = Action.Buy;
				thePlaceOrderName = PlaceOrderName.Algo_StopLoss;
				placePortfolioOrder(1);
				theFitter.reset();
			}
		}

		// Plot for spread (not yet for traded for buy or sell)
		if (theDynamicXYPlot != null && 
				theDynamicXYPlot.theStatus == DynamicXYPlot.Status.Running &&
				(thePrevSpread != null && !thePrevSpread.equals(theCurrSpread))) {

			theDynamicXYPlot.addNewDataset(new Date((long)theCurrSpread.timestamp()),
					new double[] {theCurrSpread.buy(), theCurrSpread.sell(), 
				myReqLongProfit, myReqShortProfit});
		}
		
		if (theRSPlot == null) {
			
			double [] myTradeData = theSymbolDataMap.get(theTradeSymbol);
			long myTimestamp = (long) myTradeData[Col_Timestamp];
			double myMidP = myTradeData[COL_MidP] / myContractSize;
			
			double[] myTDateArray = TimeConv.UnixT.toDateArray(myTimestamp);
			theRSPlot = new DynamicXYPlot("TradeSymbol_" + theStrategyName + " [" + (int) myTDateArray[0] + "]", 
					DynamicXYPlot.PlotType.RetailState, new Date(myTimestamp - 1000), 
					new double[] {myMidP, myMidP, myMidP, myMidP, myMidP});
			theRSPlot.initToRelative(theDynamicXYPlot);
			theLogger.info("TradeSymbolPlot is initialized");
		} else if (theRSPlot != null && theRSPlot.theStatus == DynamicXYPlot.Status.Running) {
			
			double [] myTradeData = theSymbolDataMap.get(theTradeSymbol);
			long myTimestamp = (long) myTradeData[Col_Timestamp];
			
			if (myTimestamp - thePrevRSPlotUpdateTime <= theRSPlotUpdateInterval) {
				return; // Don't update plot
			}
			
			if (theCumulativePos == 0) {
				theRSPlot.addNewDataset(new Date(myTimestamp), new double[] {myCurrBidP, myCurrAskP});
			} else if (theCumulativePos > 0) {
				double myNextTradeP = myReqShortProfit / myContractSize + theLastTradeP;
				theRSPlot.addNewDataset(new Date(myTimestamp), new double[] {myCurrBidP, myCurrAskP, myNextTradeP});
			} else if (theCumulativePos < 0) {
				double myNextTradeP = theLastTradeP - myReqLongProfit / myContractSize;
				theRSPlot.addNewDataset(new Date(myTimestamp), new double[] {myCurrBidP, myCurrAskP, myNextTradeP});
			}
			thePrevRSPlotUpdateTime = myTimestamp;
		}

	}
	
	/**
	 * 
	 * @param aPortfolioOrderVolume: this is not aVolumePerTrade, it is +/- 1 or +/- CurrPortPos to close out
	 */
	@Override
	protected void placePortfolioOrder(int aPortfolioOrderVolume) {
		
		if (theStatus == Status.Pause || theStatus == Status.Done) {
			return; // Don't place order
		}
		
		thePlaceOrderStatus = PlaceOrderStatus.Close;
		
		int myOrderId = theOrderHandler.generateOrderId();
		double[] myData = theSymbolDataMap.get(theTradeSymbol);
		double myContractSize = theContractSizeMap.get(theTradeSymbol);
		double myTradeVolume = theRoundTradeVolumeMap.get(theTradeSymbol);

		// Init
		double myOrderPrice = 0.0;
		double myMarketVolumeOnSide = 0;
		Action myOrderAction = null;
		if (thePortfolioAction == Action.Buy) { // Portfolio buy: 
			if (myTradeVolume > 0 ) { // Place buy order 
				myOrderPrice = myData[COL_AskP];
				myMarketVolumeOnSide = myData[COL_AskV];
				myOrderAction = Action.Buy; 
			} else { // Place sell order
				myOrderPrice = myData[COL_BidP];
				myMarketVolumeOnSide = myData[COL_BidV];
				myOrderAction = Action.Sell;
			}
		} else { // Portfolio sell 
			if (myTradeVolume > 0 ) { // Place sell order
				myOrderPrice = myData[COL_BidP];
				myMarketVolumeOnSide = myData[COL_BidV];
				myOrderAction = Action.Sell;
			} else {					// Place buy order
				myOrderPrice = myData[COL_AskP];
				myMarketVolumeOnSide = myData[COL_AskV];
				myOrderAction = Action.Buy;
			}
		}
		myOrderPrice = myOrderPrice / myContractSize;
		int myOrderVolume = Math.abs((int) myTradeVolume * aPortfolioOrderVolume);

		SpreadOrder mySpreadOrder = 
				new SpreadOrder(myOrderId, theOrderType, myOrderPrice, myOrderAction, myOrderVolume);
		mySpreadOrder.setMarketVolumeOnSide(myMarketVolumeOnSide);
		mySpreadOrder.m_placeTime = (long) myData[Col_Timestamp];

		if (myOrderAction == Action.Buy)
			theLogger.info("{} Placing [{}] {} order: {} @ {}", thePlaceOrderName.name(), theTradeSymbol, 
					theOrderType.name(), myOrderVolume, myOrderPrice);
		else
			theLogger.info("{} Placing [{}] {} order: {} @ {}", thePlaceOrderName.name(), theTradeSymbol,
					theOrderType.name(), -myOrderVolume, myOrderPrice);

		theOrderHandler.placeOrder(myOrderId, theStrategyName, 
				theSymbolContractMap.get(theTradeSymbol), mySpreadOrder, this);

	}
	
	@Override
	public void newOrderManager(OrderManager aOrderManager) {
		synchronized (this) {
			
			if (aOrderManager.theStatus == OrderHandler.Status.Inactive || 
					aOrderManager.theStatus == OrderHandler.Status.Error) {
				theLogger.error("Order status: {}", aOrderManager.theStatus.name());
				this.setStatus(Status.Error);
				this.notify();
				return;
			}
			
			theSymbolOrderFilledMap.put(aOrderManager.theSymbol, true);
			
			String mySymbol = aOrderManager.theSymbol;
			int myVolume = 0;			
			theLastTradeP = aOrderManager.theFilledP;
			Action myAction = Action.valueOf(aOrderManager.theOrder.m_action);
			
			if (myAction == Action.Buy) {
				myVolume = aOrderManager.theOrder.m_totalQuantity;
			} else {
				myVolume = - aOrderManager.theOrder.m_totalQuantity;
			}
			
			int myCurrPortPos = theNextCumulativePos - theCumulativePos;
			
			double[] myData = theSymbolDataMap.get(mySymbol);
			int myPortfolioPos = myVolume / theRoundTradeVolumeMap.get(mySymbol).intValue();
				
			theLogger.info("[{}] filled: {} @ {}", mySymbol, myVolume, theLastTradeP);
			
			double[] myDateTime = TimeConv.UnixT.toDateArray(aOrderManager.theTime);
			
			// Realized PnL from TradeP and TradeV
			double myRealizedPnLPerSymbol = theLastTradeP * (- myVolume) * theContractSizeMap.get(mySymbol);
			thePortfolioRealizedPnL = thePortfolioRealizedPnL + myRealizedPnLPerSymbol; // This gives portfolio trade
			
			// Fee
			double myFeePerSymbol = theSymbolFeeMap.get(mySymbol);
			
			StringBuilder myCSVSb = new StringBuilder(); 
			myCSVSb.append(myDateTime[0] + ",");
			myCSVSb.append(myDateTime[1] + ",");
			myCSVSb.append(theStrategyName + ",");
			myCSVSb.append(myPortfolioPos + ",");
			myCSVSb.append(ProductManager.getTickerBySymbol(mySymbol) + ",");
			myCSVSb.append(myData[COL_Time] + ",");
			myCSVSb.append(aOrderManager.theOrder.m_placedPrice + ",");
			myCSVSb.append(aOrderManager.theOrder.m_marketVolumeOnSide + ",");
			myCSVSb.append(theLastTradeP + ",");
			myCSVSb.append(myVolume + ",");
			myCSVSb.append(myRealizedPnLPerSymbol + ",");
			myCSVSb.append(myFeePerSymbol + ",");
			myCSVSb.append(myRealizedPnLPerSymbol - myFeePerSymbol + "\n");
							
			CSVHelper.write(getCSVFileName(), myCSVSb.toString(), true);
			
			// Check for all filled
			if (CollectionUtils.isEqualCollection(theOrderFilled, theSymbolOrderFilledMap.values())) {
				for (String mySymbolElem : theSymbolOrderFilledMap.keySet()) 
					theSymbolOrderFilledMap.put(mySymbolElem, false);
				
				// Plot for spread
				PositionAdj.Profit myReqProfit = thePositionAdj.getReqProfit();
				
				double myReqLongSpread = - myReqProfit.reqLong();
				double myReqShortSpread = myReqProfit.reqShort();
				
				if (theDynamicXYPlot != null && theCurrSpread.mid() != 0 && 
						theDynamicXYPlot.theStatus == DynamicXYPlot.Status.Running) {
					
					// This spread would be different from realized pnl
					// due to filled price is better than bid / ask when we place order
					// However, this approximated spread is good for plotting
					double myOrderPlacedSpread = thePortfolioAction == Action.Buy ? theCurrSpread.buy() : theCurrSpread.sell();
					
					if (thePortfolioAction == Action.Buy) {
						theDynamicXYPlot.addNewDataset(new Date(aOrderManager.theTime),
								new double[] {theCurrSpread.buy(), theCurrSpread.sell(), myReqLongSpread, 
							myReqShortSpread, myOrderPlacedSpread});
					} else {
						theDynamicXYPlot.addNewDataset(new Date(aOrderManager.theTime),
								new double[] {theCurrSpread.buy(), theCurrSpread.sell(), myReqLongSpread, 
							myReqShortSpread, Double.NaN, myOrderPlacedSpread});
					}
				}
				
				if (theRSPlot != null && theRSPlot.theStatus == DynamicXYPlot.Status.Running) {
					
					double [] myTradeData = theSymbolDataMap.get(theTradeSymbol);
					double myContractSize = theContractSizeMap.get(theTradeSymbol);
					long myTimestamp = (long) myTradeData[Col_Timestamp];
					double myBidP = myTradeData[COL_BidP] / myContractSize;
					double myAskP = myTradeData[COL_BidP] / myContractSize;
					
					if (thePortfolioAction == Action.Buy) {
						theRSPlot.addNewDataset(new Date(myTimestamp), 
								new double[] {myBidP, myAskP, theLastTradeP, theLastTradeP});
					} else {
						theRSPlot.addNewDataset(new Date(myTimestamp), 
								new double[] {myBidP, myAskP, theLastTradeP, Double.NaN, theLastTradeP});
					} 
				}
				
				
				// Update the current cumulative portfolio position
				theCumulativePos = theNextCumulativePos; 
				
				// Add new item to reporter
				addNewItemToReporter(myCurrPortPos, thePortfolioRealizedPnL);
				
				thePortfolioRealizedPnL = 0; // Reset the portfolio realized pnl
				thePositionAdj.setReqProfit(theCumulativePos); // Update the req profit
				
				// Update Status
				if (theStatus == Status.FinalTrade) {
					theLogger.info("Closing out the position and stopping trade");
					theStatus = Status.Done;
					thePlaceOrderStatus = PlaceOrderStatus.Close;
					this.notify();
				} else {
					thePlaceOrderStatus = PlaceOrderStatus.Open;
					if (thePlaceOrderName == PlaceOrderName.Algo_StopLoss) {
						theStatus = Status.Running;
					} else {
						theStatus = Status.Running;
					}
				}
				
				// Update controller (Controller needs theStatus and theCumulativePos)
				updateItemToController();
				
				// This allows to recenter after the closing position
				if (theFitterResetOnClose && theCumulativePos == 0) {
					theFitter.reset(); 
				}
			}
		}
	}
	
	
	// ------------------------------------------------------------------------------
	// Fields
	public Logger theLogger = (Logger) LogManager.getLogger();

	private static int Col_Timestamp = 0;
	private static int COL_Time = 1;
	private static int COL_BidP = 2;
	private static int COL_BidV = 3;
	private static int COL_AskP = 4;
	private static int COL_AskV = 5;
	private static int COL_MidP = 6;

	private String theTradeSymbol;

	// This is updated when you place the order for portfolio
	protected double theLastTradeP = 0.0;

	private double thePortfolioRealizedPnL = 0;
	
	// TradeSymbol plot
	public DynamicXYPlot theRSPlot = null;
	private long thePrevRSPlotUpdateTime = 0;
	private long theRSPlotUpdateInterval = 1000; // Update every second
		

}

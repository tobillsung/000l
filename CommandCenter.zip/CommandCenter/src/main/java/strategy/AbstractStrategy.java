package strategy;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import order.OrderHandler;
import order.OrderListener;
import plot.DynamicXYPlot;
import plot.DynamicXYPlot.PlotType;
import report.Reporter;
import util.MySqlHelper;
import util.TimeConv;

import com.ib.client.Contract;

import control.Controller;
import feed.FeedHandler;
import feed.FeedListener;
import feed.RetailState.Data;
import fit.Fittable;
import fit.NullFitter;

public abstract class AbstractStrategy implements FeedListener, OrderListener, Runnable{

	// ------------------------------------------------------------------------------
	// Abstract methods
	public abstract void init(FeedHandler aFeedHandler, 
			OrderHandler aOrderHandler, Fittable aFitter, PositionAdj aPositionAdj);
	
	public abstract void run();
	
	public abstract String getStrategyName();
	
	public abstract void placeManualOrder(int aPortfolioOrderVolume);
	
	protected abstract void placePortfolioOrder(int aPortfolioOrderVolume);
	
	protected abstract double fit(Fittable aAbstractFitter);
	
	public double[] getRoundTradeVolume() {
		
		Double[] myRawVolumes =
				theRoundTradeVolumeMap.values().toArray(new Double[theRoundTradeVolumeMap.size()]);
		double[] myDoubleVolume = new double[myRawVolumes.length];
		for (int i = 0 ; i < myRawVolumes.length ; i++) {
			myDoubleVolume[i] = myRawVolumes[i];
		}
		
		return myDoubleVolume;
	}
	
	// ------------------------------------------------------------------------------
	// public
	public String getCSVFileName() {
		if (theCSVFileName == null) {
			double [] myDate = TimeConv.UnixT.toDateArray(System.currentTimeMillis());
			theCSVFileName = "Trade_" +  getStrategyName() + "_" + (int)myDate[0] + ".csv";
		}
		return theCSVFileName; 
	}
	
	public int getCumulativePos() {
		return theCumulativePos;
	}
	
	public void manuallyUpdateReqProfit(double aReqLongProfit, double aReqShortProfit) {
		thePositionAdj.setReqProfit(aReqLongProfit, aReqShortProfit);
		updateItemToController();
	}
	
	public void setFitOnlyOnFlat(boolean aFitOnlyOnFlat) {
		theFitOnlyOnFlat = aFitOnlyOnFlat;
	}
	
	public void setFitterResetOnClose (boolean aFitterResetOnClose) {
		theFitterResetOnClose = aFitterResetOnClose;
	}
	
	public void setCloseOutPosTime(double aCloseOutPosTime) {
		theCloseOutPosTime = aCloseOutPosTime;
	}
	
	public void setStatus(Status aStatus) {
		theStatus = aStatus;
	}
	
	public void setOrderType(Type aType) {
		theOrderType = aType;
	}
	
	public void setDynamicXYPlot(PlotType aPlotType) {
		thePlotType = aPlotType;
	}
	
	public void setReporter(Reporter aReporter) {
		synchronized (this) {
			theReporter = aReporter;
		}
	}
	
	public void setController(Controller aController) {
		synchronized(this) {
			theController = aController;
		}
	}
	
	public void addNewItemToReporter(int aCurrPos, double aPnL) {
		synchronized(this) {
			if (theReporter != null) {
				theReporter.addRecord(this, aCurrPos, aPnL, theFeePerPortfolioTrade);
			}
		}
	}
	
	public void updateItemToController() {
		synchronized(this) {
			if (theController != null) {
				theController.updateStatus(this);
			}
		}
	}
	
	public void setLoadTradeToDatbase(boolean aLoadTradeToDatabase) {
		theLoadTradeToDatabase = aLoadTradeToDatabase;
	}
	
	public void setTimeOutHorizon (double aTimeOutHorizon) {
		theTimeOutHorizon = aTimeOutHorizon;
	}
	
	public void setMaxConsecutiveOpenTradeN(int aMaxConsecutiveOpenTradeN) {
		theMaxConsecutiveOpenTradeN = aMaxConsecutiveOpenTradeN;
	}

	// ------------------------------------------------------------------------------
	// protected
	protected void checkCloseOutPosTime(Data aRS) {
		if ( theStatus != Status.FinalTrade) {
			double[] myDateTime = TimeConv.UnixT.toDateArray(aRS.getTime());
			if (myDateTime[1] >= theCloseOutPosTime && theStatus != Status.Pause) {
				theStatus = Status.FinalTrade;
			} 
		}
	}
	
	protected Reporter.Summary getTradeSummary() {
		if (theReporter != null) {
			return theReporter.getSummary(this);
		} else {
			return new Reporter().new Summary(0, 0, 0);
		}
	}

	// ------------------------------------------------------------------------------
	// Fields
	public enum Action {Buy, Sell};
	public enum Status {Init, Running, FinalTrade, Done, Pause, Error};
	public enum PlaceOrderName {Algo, Manual, Algo_StopLoss, Algo_TimeOut};
	public enum PlaceOrderStatus {Open, Close};
	public enum Type {LMT, MKT};

	// fields related to init
	public Status theStatus = Status.Init;
	public PlaceOrderStatus thePlaceOrderStatus = PlaceOrderStatus.Open;
	public PlaceOrderName thePlaceOrderName = PlaceOrderName.Algo;
	public FeedHandler theFeedHandler;
	public OrderHandler theOrderHandler;
	public Fittable theFitter = new NullFitter(); // If it is NullFitter, it will not do anything
	public PositionAdj thePositionAdj;
	public Reporter theReporter = null;
	public Controller theController = null;
	public DynamicXYPlot theDynamicXYPlot = null;
	public PlotType thePlotType = null;
	public double theFeePerPortfolioTrade = 0;

	protected MySqlHelper theMySqlHelper;
	protected Type theOrderType = Type.LMT;
	protected double theInitFitStopTime = 0;
	protected boolean theFitOnlyOnFlat = true;
	protected boolean theFitterResetOnClose = false;
	
	// fields related to checkOpportunity
	protected Action thePortfolioAction;
	protected int theCumulativePos = 0;
	protected int theNextCumulativePos = 0; // To compare with PositionAdj max position
	protected int theVolumePerTrade = 1; // Per portfolio
	protected int[] theMinMarketVolume = null; // Minimum market volume on the side you enter
	protected boolean theIsStopLossTriggered = false;
	protected double theTimeOutHorizon = Double.MAX_VALUE; // TimeOut to place Algo_TimeOut order to force close out position
	protected int theMaxConsecutiveOpenTradeN = Integer.MAX_VALUE; // Maximum consecutive # of open trade for the given side
	
	// fields related to close the strategy
	protected double theCloseOutPosTime = 150000.0;
	
	protected boolean theLoadTradeToDatabase = true;
	
	// I want to preserve insertion index
	protected Map<String, double[]> theSymbolDataMap = new LinkedHashMap<String, double[]>();
	protected Map<String, Contract> theSymbolContractMap = new LinkedHashMap<String, Contract>();
	protected Map<String, Boolean> theSymbolOrderFilledMap = new LinkedHashMap<String, Boolean>();
	protected Map<String, Double> theSymbolFeeMap = new LinkedHashMap<String, Double>();
	protected Map<String, Double> theRoundTradeVolumeMap = new LinkedHashMap<String, Double>();
	protected Map<String, Double> theContractSizeMap = new LinkedHashMap<String, Double>();
	protected List<Boolean> theOrderFilled = new ArrayList<Boolean> ();
	
	protected String theCSVFileName = null;
}

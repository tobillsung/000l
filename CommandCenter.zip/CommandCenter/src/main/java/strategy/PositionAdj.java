package strategy;

public class PositionAdj {
	
	
	public PositionAdj(double aOpenMinProfit, double aCloseMinProfit){
		this(aOpenMinProfit, aCloseMinProfit, aOpenMinProfit, 1);
	}
	
	public PositionAdj(double aOpenMinProfit, double aCloseMinProfit, double aAdjustment){
		this(aOpenMinProfit, aCloseMinProfit, aAdjustment, 1);
	}
	
	public PositionAdj(double aOpenMinProfit, double aCloseMinProfit, double aAdjustment, double aMaxPos) {
		theOpenMinProfit = aOpenMinProfit;
		theCloseMinProfit = aCloseMinProfit;
		theAdjustment = aAdjustment;
		theMaxPos = aMaxPos;
		setReqProfit(0); // Assume the initial position is zero
	}
	
	public void setStopLoss(double aStopLossTrigger, double aStopLoss) {
		theStopLossTrigger = aStopLossTrigger;
		theStopLoss = aStopLoss;
	}
	
	public class Profit {
		public Profit(double aLongProfit, double aShortProfit){
			theLongProfit = aLongProfit;
			theShortProfit = aShortProfit;
		}
		public double reqLong() {return theLongProfit;}
		public double reqShort() {return theShortProfit;}
		
		private double theLongProfit;
		private double theShortProfit;
	}
	
	public void setStrategy(Strategy aStrategy) {
		theStrategy = aStrategy;
	}
	
	public double getOpenMinProfit() {return theOpenMinProfit;}
	
	public double getCloseMinProfit() {return theCloseMinProfit;}
	
	public double getAdjustment() {return theAdjustment;}
	
	public double getMaxPos() {return theMaxPos;}
	
	public double getStopLossTrigger() {return theStopLossTrigger;}
	
	public double getStopLoss() {return theStopLoss;}
	
	/**
	 * 
	 * @return theProfit long or short is always positive
	 */
	public Profit getReqProfit() {
		return theProfit;
	}
	
	public void setReqProfit(int aCurrPos) {
		
		switch (theStrategy) {
			case MomentTrade:
				if (aCurrPos == 0) { // Current position is flat
					setReqProfit(theOpenMinProfit, theOpenMinProfit); 
				} else if (aCurrPos < 0) { // Current position is short
					setReqProfit(theCloseMinProfit, 0); 					
				} else { // Current position is long
					setReqProfit(0, theCloseMinProfit);
				}
				break;
			default:
				if (aCurrPos == 0) { // Current position is flat
					setReqProfit(theOpenMinProfit, theOpenMinProfit); 
				} else if (aCurrPos < 0) { // Current position is short
					double myAbsPos = - aCurrPos;
					setReqProfit(theCloseMinProfit - theAdjustment * (myAbsPos - 1),
							theOpenMinProfit + theAdjustment * myAbsPos);
				} else { // Current position is long
					setReqProfit(theOpenMinProfit + theAdjustment * aCurrPos, 
							theCloseMinProfit - theAdjustment * (aCurrPos - 1));
				}
		}
	}
	
	public void setReqProfit(double aReqLongProfit, double aReqShortProfit) {
		theProfit = new Profit(aReqLongProfit, aReqShortProfit); 
	}
	
	public enum Strategy{Default, SpreadTrade, MomentTrade};
	
	private Strategy theStrategy = Strategy.Default;
	private double theOpenMinProfit = 0;
	private double theCloseMinProfit = 0;
	private double theAdjustment;
	private double theMaxPos = 1;
	private double theStopLossTrigger = Double.MAX_VALUE;
	private double theStopLoss = Double.MAX_VALUE;
	private Profit theProfit = new Profit(0, 0);
}

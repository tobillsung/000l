package control;

import java.util.ArrayList;
import java.util.List;

import strategy.AbstractStrategy;

public class Controller {
	public Controller() {
		
	}
	
	public void addControllerListener(ControllerListener aControllerListener) {
		theControllerListeners.add(aControllerListener);
	}
	
	public void updateStatus(AbstractStrategy aStrategy) {
		for (ControllerListener myListenr : theControllerListeners) {
			myListenr.updateItem(aStrategy);
		}
	}

	private List<ControllerListener> theControllerListeners = new ArrayList<ControllerListener>();
}

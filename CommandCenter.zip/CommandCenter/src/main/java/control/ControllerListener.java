package control;

import strategy.AbstractStrategy;

public interface ControllerListener {
	public void updateItem(AbstractStrategy aStrategy);
}

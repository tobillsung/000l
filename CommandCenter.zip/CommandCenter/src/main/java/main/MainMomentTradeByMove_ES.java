package main;

import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import order.OrderHandler;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

import product.ProductManager;
import report.Reporter;
import strategy.AbstractStrategy;
import strategy.momenttrade.MomentTradeByMove;
import strategy.momenttrade.optimized.OptimizedMomentTradeByMove;

import com.ib.client.Contract;

import control.Controller;
import feed.FeedHandler;
import gui.controller.ControllerMain;
import gui.report.ReporterMain;

public class MainMomentTradeByMove_ES {
	public MainMomentTradeByMove_ES (AbstractStrategy[] aAbstractStrategy, FeedHandler aFeedHander, OrderHandler aOrderHandler, 
			int aStopHour, int aStopMin, int aStopSec) {
		
		theAbstractStrategy = aAbstractStrategy;
		theFeedHandler = aFeedHander;
		theOrderHanlder = aOrderHandler;
		Calendar myCal = Calendar.getInstance();
		
		theLogger.info("Timer is started at {}", myCal.getTime());
		myCal.set(myCal.get(Calendar.YEAR), myCal.get(Calendar.MONTH), myCal.get(Calendar.DAY_OF_MONTH), 
				aStopHour, aStopMin, aStopSec);
		
		theLogger.info("Timer is set to stop trading at {}", myCal.getTime());
		theTimer.schedule(new StopTradingTask(), myCal.getTime());
	}
	
	public class StopTradingTask extends TimerTask {

		@Override
		public void run() {
			theLogger.info("Stopping MomentTradeByMove");
			
			for (AbstractStrategy myStrategy : theAbstractStrategy) {
				synchronized (myStrategy) {
					myStrategy.setStatus(AbstractStrategy.Status.Done);
					myStrategy.notify();
				}
			}
			theOrderHanlder.setStatus(OrderHandler.Status.Done);
			theFeedHandler.setStatus(FeedHandler.Status.Done);
			//theTimer.cancel();
			System.exit(0); // To kill nondaemon thread
		}
	}
	
	
	public static void main(String[] args) throws Exception{
		
		String myTicker = "ESM4";
		Contract myESContract = ProductManager.getContractByTicker(myTicker);
		
		// FeedHandler
		FeedHandler myFeedHandler = new FeedHandler();
		myFeedHandler.init(FeedHandler.InsertType.No);
		new Thread(myFeedHandler).start();
		
		// OrderHandler
		OrderHandler myOrderHandler = new OrderHandler();
		myOrderHandler.init();
		new Thread(myOrderHandler).start();
		
		// Reporter
		Reporter myReporter = new Reporter();
		myReporter.addReporterListener(new ReporterMain("Reporter", true));
		
		// Controller
		Controller myController = new Controller();
		myController.addControllerListener(new ControllerMain("Controller"));
						
		// Set up MomentTradeByMove
		MomentTradeByMove myMomentTradeByMove = 
				OptimizedMomentTradeByMove.ES(
						myESContract, myFeedHandler, myOrderHandler, myReporter, myController);
		
		new Thread(myMomentTradeByMove).start();
		
		// Start the timer
		new MainMomentTradeByMove_ES(new AbstractStrategy[]{myMomentTradeByMove}, 
				myFeedHandler, myOrderHandler, 15, 0, 0);
	}
	
	private final Timer theTimer = new Timer();	
	private final AbstractStrategy[] theAbstractStrategy;
	private final FeedHandler theFeedHandler;
	private final OrderHandler theOrderHanlder;
	private Logger theLogger = (Logger) LogManager.getLogger(getClass());

}

package main.sim;

import order.SimOrderHandler;
import product.ProductManager;
import report.Reporter;
import strategy.momenttrade.MomentTradeByMove;
import strategy.momenttrade.optimized.OptimizedMomentTradeByMove;

import com.ib.client.Contract;

import control.Controller;
import feed.SimFeedHandler;
import gui.controller.ControllerMain;
import gui.report.ReporterMain;

public class SimMomentTradeByMove_ES {
	public static void main(String[] args) throws Exception{
		
		String myESTicker = "ESM4";
		
		Contract myESContract = ProductManager.getContractByTicker(myESTicker);
		
		int mySimDate = 20140429;
		double mySimSTime = 090000.0;
		double mySimETime = 150000.0;
		
		// FeedHandler
		SimFeedHandler myFeedHandler = new SimFeedHandler();
		myFeedHandler.init(mySimDate, mySimSTime, mySimETime);
		
		// OrderHandler
		SimOrderHandler myOrderHandler = new SimOrderHandler();
		myOrderHandler.init();
		new Thread(myOrderHandler).start();
		
		// Reporter
		Reporter myReporter = new Reporter();
		myReporter.addReporterListener(new ReporterMain("Reporter", false));

		// Controller
		Controller myController = new Controller();
		myController.addControllerListener(new ControllerMain("Controller"));
		
		MomentTradeByMove myMomentTradeByMove = 
				OptimizedMomentTradeByMove.ES(
						myESContract, myFeedHandler, myOrderHandler, myReporter, myController);
		
		new Thread(myMomentTradeByMove).start();
		new Thread(myFeedHandler).start(); // Start the feed
		
	}


}

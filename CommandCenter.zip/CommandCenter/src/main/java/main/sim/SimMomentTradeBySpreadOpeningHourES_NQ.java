package main.sim;

import order.SimOrderHandler;
import product.ProductManager;
import report.Reporter;
import strategy.momenttrade.MomentTradeBySpread;
import strategy.momenttrade.optimized.OptimizedMomentTradeBySpread;

import com.ib.client.Contract;

import control.Controller;
import feed.SimFeedHandler;
import gui.controller.ControllerMain;
import gui.report.ReporterMain;

public class SimMomentTradeBySpreadOpeningHourES_NQ {
	
	public static void main(String[] args) throws Exception{
		
		String [] myTickers = new String[] {"ESM4", "NQM4"};
		
		Contract myESContract = ProductManager.getContractByTicker(myTickers[0]);
		Contract myNQContract = ProductManager.getContractByTicker(myTickers[1]);
		Contract[] myContracts = new Contract[] {myESContract, myNQContract};
		
		int mySimDate = 20140429;
		double mySimSTime = 084000.0;
		double mySimETime = 150000.0;
		
		// FeedHandler
		SimFeedHandler myFeedHandler = new SimFeedHandler();
		myFeedHandler.init(mySimDate, mySimSTime, mySimETime);
		
		// OrderHandler
		SimOrderHandler myOrderHandler = new SimOrderHandler();
		myOrderHandler.init();
		new Thread(myOrderHandler).start();
		
		// Reporter
		Reporter myReporter = new Reporter();
		myReporter.addReporterListener(new ReporterMain("Reporter", false));

		// Controller
		Controller myController = new Controller();
		myController.addControllerListener(new ControllerMain("Controller"));
		
		MomentTradeBySpread myMomentTradeBySpread = 
				OptimizedMomentTradeBySpread.OpeningHour_ES_NQ(
						myContracts, myFeedHandler, myOrderHandler, myReporter, myController);
		
		new Thread(myMomentTradeBySpread).start();
		new Thread(myFeedHandler).start(); // Start the feed
		
	}

}

package main.sim;

import order.SimOrderHandler;
import product.ProductManager;
import report.Reporter;
import strategy.manual.PremiumManualTrade;
import strategy.manual.optimized.OptimizedPremiumManual;
import strategy.spreadtrade.SpreadTrade;
import strategy.spreadtrade.optimized.OptimizedSpreadTrade;

import com.ib.client.Contract;

import control.Controller;
import feed.SimFeedHandler;
import gui.controller.ControllerMain;
import gui.report.ReporterMain;

/**
 * Simulate using recorded data
 * Do not need to have TWS running
 * @author bill
 *
 */
public class SimOpeningHourES_NQ {
	
	public static void main(String[] args) throws Exception{
		
		String [] myTickers = new String[] {"ESM4", "NQM4"};
		
		Contract myES = ProductManager.getContractByTicker(myTickers[0]);
		Contract myNQ = ProductManager.getContractByTicker(myTickers[1]);
		Contract[] myContracts = new Contract[] {myES, myNQ};
		
		int mySimDate = 20140430;
		double mySimSTime = 084000.0;
		double mySimETime = 150000.0;
		
		// FeedHandler
		SimFeedHandler myFeedHandler = new SimFeedHandler();
		myFeedHandler.init(mySimDate, mySimSTime, mySimETime);
		
		// OrderHandler
		SimOrderHandler myOrderHandler = new SimOrderHandler();
		myOrderHandler.init();
		new Thread(myOrderHandler).start();
		
		// Reporter
		Reporter myReporter = new Reporter();
		myReporter.addReporterListener(new ReporterMain("Reporter", false));

		// Controller
		Controller myController = new Controller();
		myController.addControllerListener(new ControllerMain("Controller"));
		
		SpreadTrade mySpreadTrade = 
				OptimizedSpreadTrade.OpeningHour_ES_NQ(
						myContracts, myFeedHandler, myOrderHandler, myReporter, myController);
		
		PremiumManualTrade myPremiumManualTrade = 
				OptimizedPremiumManual.OpeningHour_ES_NQ(
						myContracts, myFeedHandler, myOrderHandler, myReporter, myController);

		new Thread(mySpreadTrade).start();
		new Thread(myPremiumManualTrade).start();
		new Thread(myFeedHandler).start(); // Start the feed
		
	}

}

package main;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

import com.ib.client.Contract;

import product.ProductManager;
import util.ConfigManager;
import feed.FeedHandler;
import feed.NullFeedListener;

public class FeedRecorderMain {
	
	public FeedRecorderMain (FeedHandler aFeedHander, int aStopHour, int aStopMin, int aStopSec) {
		theFeedHandler = aFeedHander;
		Calendar myCal = Calendar.getInstance();
		
		theLogger.info("Timer is started at {}", myCal.getTime());
		myCal.set(myCal.get(Calendar.YEAR), myCal.get(Calendar.MONTH), myCal.get(Calendar.DAY_OF_MONTH), 
				aStopHour, aStopMin, aStopSec);
		
		theLogger.info("Timer is set to stop recoding at {}", myCal.getTime());
		theTimer.schedule(new StopRecordingTask(), myCal.getTime());
	}
	
	public class StopRecordingTask extends TimerTask {

		@Override
		public void run() {
			theLogger.info("Stopping the FeedRecorder");
			theFeedHandler.setStatus(FeedHandler.Status.Done);
			theTimer.cancel();
		}
	}
	
	
	public static void main(String[] args) throws Exception{
		
		FeedHandler myFH = new FeedHandler(theHost, thePort, theClientId);
		myFH.init(FeedHandler.InsertType.LoadCSV);
		
		
		String[] myTickers = theTickers.split(",");
		System.out.println("Recording tickers: " + Arrays.toString(myTickers));
		
		Contract[] myContracts = new Contract[myTickers.length];
		for (int i = 0 ; i < myTickers.length ; i++) {
			myContracts[i] = ProductManager.getContractByTicker(myTickers[i]);
		}
		
		myFH.reqRetailStateUpdate(myContracts, new NullFeedListener());
		
		// Start the timer
		new FeedRecorderMain(myFH, 15, 15, 0);
		
		myFH.run();

	}

	private static String theHost = ConfigManager.parseConfig(FeedRecorderMain.class, "host", "127.0.0.1");
	private static int thePort = ConfigManager.parseConfig(FeedRecorderMain.class, "port", 7496);
	private static int theClientId = ConfigManager.parseConfig(FeedRecorderMain.class, "clientid", 9999);
	private static String theTickers = ConfigManager.parseConfig(FeedRecorderMain.class, "tickers", "GLD");
	
	private final Timer theTimer = new Timer();	
	private final FeedHandler theFeedHandler;
	private Logger theLogger = (Logger) LogManager.getLogger(getClass());
}

package sound;

import java.net.URL;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class SoundDrive extends Thread{
	
	public SoundDrive() {
	}
	
	public void setAudioFile(String[] aFileNames) {
		theFileNames = new String[aFileNames.length];
		for (int i = 0 ; i < aFileNames.length ; i++) {
			theFileNames[i] = aFileNames[i];
		}
	}
	
	public void setAudioFile(String aFileName) {
		theFileNames = new String[] {aFileName};
	}
	
	@Override
	public void run() {
		playSound();
	}
	
		
	private void playSound(){
		
		if (theFileNames == null) {
			return;
		}

		Clip myClip = null;
		for (String myFileName : theFileNames) {
		
			URL myAudioFile = getClass().getClassLoader().getResource(myFileName);
			
			try {
				AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(myAudioFile);
		        // Get a clip resource.
				myClip = AudioSystem.getClip();
		        // Open audio clip and load samples from the audio input stream.
		        myClip.open(audioInputStream);
		        
		        myClip.start();
		        // Simple way to wait for myClip to finish
		        while(myClip.getMicrosecondLength() != myClip.getMicrosecondPosition()) {
		        }
		        
			} catch (Exception e){
				e.printStackTrace();
			}
		}
	}
	    
	private String[] theFileNames = null;
	

}

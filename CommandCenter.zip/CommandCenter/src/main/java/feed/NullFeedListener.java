package feed;

import feed.RetailState.Data;

public class NullFeedListener implements FeedListener{

	@Override
	public void newRetailState(String aSymbol, Data aNewData) {
		// Doing nothing
	}

	@Override
	public void newLastDone(String aSymbol, feed.LastDone.Data aNewData) {
		// Doing nothing
	}

}

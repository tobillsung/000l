package feed;



public interface FeedListener {
	
	public void newRetailState(String aSymbol, RetailState.Data aNewData);
	
	public void newLastDone(String aSymbol, LastDone.Data aNewData);
	
	
	
}


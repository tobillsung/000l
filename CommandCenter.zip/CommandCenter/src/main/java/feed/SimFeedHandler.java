package feed;

import java.util.ArrayList;
import java.util.List;

import product.ProductManager;
import strategy.AbstractStrategy;
import util.MySqlHelper;

import com.ib.client.Contract;

/**
 * Simulated feed from database
 * @author bill
 *
 */
public class SimFeedHandler extends FeedHandler{
	
	public SimFeedHandler() {
		
	}
	
	public void init(int aDate) {
		init(aDate, 83000.00, 150000.00);
	}
	
	public void init(int aDate, double aSTime, double aETime) {
		theMySqlHelper = new MySqlHelper();
		theDate = aDate;
		theSTime = aSTime;
		theETime = aETime;
	}
	
	public void reqRetailStateUpdate(Contract[] aContracts, FeedListener aFeedListener) {
		
		synchronized (this) {
			for (Contract myContract : aContracts) {
				String mySymbol = ProductManager.getSymbolByContract(myContract);
				theLogger.info("Validating data [{}]", mySymbol);
				double[][] myData = theMySqlHelper.getTickRetailState(ProductManager.getTickerBySymbol((String) mySymbol), 
						theDate, theSTime, theETime);
				
				if (myData == null) {
					theLogger.error("No data for [{}]", mySymbol);
					theLogger.info("SimFeedHandler is closed and exit the simulation");
					System.exit(0);
				}
				
				// New contract so add to theContractToFeedId map
				if (!theSymbolToFeedId.containsKey(mySymbol)) {
					int myFeedId = (int) myData[0][7];
					theSymbolToFeedId.put(mySymbol, myFeedId);
					
					// Map new feedId to theFeedIdToFeedListeners
					List<FeedListener> myListeners = new ArrayList<FeedListener>();
					myListeners.add(aFeedListener);
					theFeedIdToFeedListeners.put(myFeedId, myListeners);
				}
				else { // Already myContract is subscribed by FeedHandler
					int myExistingFeedId = (Integer) theSymbolToFeedId.get(mySymbol);

					// Add FeedListener to the already existing map
					List<FeedListener> myListeners = theFeedIdToFeedListeners.get(myExistingFeedId);
					myListeners.add(aFeedListener);
					theFeedIdToFeedListeners.put(myExistingFeedId, myListeners);
				}
			}
			
			theLogger.info("New feed listerner ({}) is added", aFeedListener.toString());
		}
	}

	@Override
	public void run() {
				
		List<String> myTickerList = new ArrayList<String>();
		for (Object mySymbol : theSymbolToFeedId.keySet()) {
			myTickerList.add(ProductManager.getTickerBySymbol((String) mySymbol));
		}
		theData = theMySqlHelper.getTickRetailState(myTickerList.toArray(new String[myTickerList.size()]), 
				theDate, theSTime, theETime);

		int myFeedId = 0;
		theLogger.info("SimFeedHandler is started");
		for (double[] myDataPerRow : theData) {
			
			synchronized (this) {
				try {
					this.wait(1);
				} catch (Exception e){
					e.printStackTrace();
				}
			}
			
			myFeedId = (int) myDataPerRow[7];
			String mySymbol = (String) theSymbolToFeedId.inverseBidiMap().get(myFeedId);
			RetailState.Data myRS = new RetailState(mySymbol).
					new Data((long)myDataPerRow[0], myDataPerRow[3], (int)myDataPerRow[4], myDataPerRow[5], (int)myDataPerRow[6]);

			// Check which FeedListener to publish
			List<FeedListener> myListeners = theFeedIdToFeedListeners.get(myFeedId);
			for (FeedListener myFeedListener : myListeners) {
				myFeedListener.newRetailState(mySymbol, myRS);
			}
		}
		
		theLogger.info("SimFeedHandler is finished");
		theStatus = Status.Done;
		
		// Notify to all Feed listener (instance of AbstractStrategy) to have Status.Done
		for (Integer myFeed : theFeedIdToFeedListeners.keySet()) {
			List<FeedListener> myListeners = theFeedIdToFeedListeners.get(myFeed);
			for (FeedListener myFeedListener : myListeners) {
				if (myFeedListener instanceof AbstractStrategy) {
					synchronized (myFeedListener) {
						((AbstractStrategy) myFeedListener).setStatus(AbstractStrategy.Status.Done);
						myFeedListener.notify();
					}
				}
			}
			
		}
		
	}
	
	private int theDate;
	private double theSTime;
	private double theETime;
	private double[][] theData;
			
}

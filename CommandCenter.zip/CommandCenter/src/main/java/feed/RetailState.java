package feed;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import product.ProductManager;

public class RetailState {
	
	public RetailState(String aSymbol) {
		theSymbol = aSymbol;
		theTicker = ProductManager.getTickerBySymbol(theSymbol);
	}
	
	public synchronized boolean update(long aUnixT, double aBidP, int aBidV, double aAskP, int aAskV) {
		
		boolean myIsUpdated = false;
		Data myNewData = new Data(aUnixT, aBidP, aBidV, aAskP, aAskV, theLastUpdatedData);
		
		if (! myNewData.equals(theLastUpdatedData)) { // The data has been updated
			theLastUpdatedData = (Data) myNewData.clone();
			myIsUpdated = true;
		} 
		return myIsUpdated;
	}
	
	public synchronized Data getLastUpdatedData() {
		return theLastUpdatedData;
	}
	
	
	public class Data implements Cloneable{
		
		public Data() {
		}
		
		public Data(long aTime, double aBidP, int aBidV, double aAskP, int aAskV) {
			this(aTime, aBidP, aBidV, aAskP, aAskV, new Data());
		}
		
		public Data(long aTime, double aBidP, int aBidV, double aAskP, int aAskV, Data aPrevData) {
			theTime = aTime;
			theBidP = aBidP > 0 ? aBidP : aPrevData.getBidP();
			theBidV = aBidV > 0 ? aBidV : aPrevData.getBidV();
			theAskP = aAskP > 0 ? aAskP : aPrevData.getAskP();
			theAskV = aAskV > 0 ? aAskV : aPrevData.getAskV();
		}
		
		public boolean isValid() {
			return theBidV > 0 && theAskV > 0 && (theBidP < theAskP) && theTime > 0;
		}
		
		public double getMid() {
			return (theBidP + theAskP) / 2;
		}
		
		public double getRWS() {
			return (theBidP * theAskV + theAskP * theBidV) / (theBidV + theAskV);
		}
		
		public Object clone(){  
		    try{  
		        return super.clone();  
		    }catch(Exception e){ 
		        return null; 
		    }
		}
		
		
		@Override
		public int hashCode() {
	        return new HashCodeBuilder(17, 31).
	            append(theTime).append(theBidP).append(theBidV).
	            append(theAskP).append(theAskV).toHashCode();
	    }

		@Override
	    public boolean equals(Object aObj) {
	        if (aObj == null)
	            return false;
	        if (aObj == this)
	            return true;
	        if (!(aObj instanceof Data))
	            return false;

	        Data myData = (Data) aObj;
	        return new EqualsBuilder().
	            append(theTime, myData.theTime).
	            append(theBidP, myData.theBidP).
	            append(theBidV, myData.theBidV).
	            append(theAskP, myData.theAskP).
	            append(theAskV, myData.theAskV).
	            isEquals();
	    }
		
		
		public long getTime() {return theTime;}
		public double getBidP() {return theBidP;}
		public int getBidV() {return theBidV;}
		public double getAskP() {return theAskP;}
		public int getAskV() {return theAskV;}
		public double[] getTick() {return new double[] {theTime, theBidP, theBidV, theAskP, theAskV};}
		
		private long theTime = 0;
		private double theBidP = 0.0;
		private int theBidV = 0;
		private double theAskP = 0.0;
		private int theAskV = 0;
		
	}
	
	public String getSymbol() {
		return theSymbol; 
	}
	public String getTicker() {
		return theTicker;
	}

	// Fields
	public static int Time = 0;
	public static int BidP = 1;
	public static int BidV = 2;
	public static int AskP = 3;
	public static int AskV = 4;
	
	public String theSymbol;
	public String theTicker;
	
	private Data theLastUpdatedData = new Data();
}

package feed;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import product.ProductManager;


public class LastDone {
	public LastDone(String aSymbol) {
		theSymbol = aSymbol;
		theTicker = ProductManager.getTickerBySymbol(theSymbol);
	}
	
	public synchronized void update(long aUnixT, double aLastP, int aLastV) {
		
		Data myNewData = new Data(aUnixT, aLastP, aLastV, theLastUpdatedData);
		
		if (! myNewData.equals(theLastUpdatedData)) { // The data has been updated
			theLastUpdatedData = (Data) myNewData.clone();
		} 
	}
	
	public synchronized Data getLastUpdatedData() {
		return theLastUpdatedData;
	}
	
	public class Data implements Cloneable{
		
		public Data() {
		}
		
		public Data(long aTime, double aLastP, int aLastV) {
			this(aTime, aLastP, aLastV, new Data());
		}
		
		public Data(long aTime, double aLastP, int aLastV, Data aPrevData) {
			theTime = aTime;
			theLastP = aLastP > 0 ? aLastP : aPrevData.getLastP();
			theLastV = aLastV > 0 ? aLastV : aPrevData.getLastV();
		}
		
		public boolean isValid() {
			return theLastP > 0 && theLastV > 0;
		}
		
		public Object clone(){  
		    try{  
		        return super.clone();  
		    }catch(Exception e){ 
		        return null; 
		    }
		}
		
		
		@Override
		public int hashCode() {
	        return new HashCodeBuilder(17, 31).
	            append(theTime).append(theLastP).append(theLastV).toHashCode();
	    }

		@Override
	    public boolean equals(Object aObj) {
	        if (aObj == null)
	            return false;
	        if (aObj == this)
	            return true;
	        if (!(aObj instanceof Data))
	            return false;

	        Data myData = (Data) aObj;
	        return new EqualsBuilder().
	            append(theTime, myData.theTime).
	            append(theLastP, myData.theLastP).
	            append(theLastV, myData.theLastV).isEquals();
	    }
		
		
		public long getTime() {return theTime;}
		public double getLastP() {return theLastP;}
		public int getLastV() {return theLastV;}
		
		public double[] getTick() {return new double[] {theTime, theLastP, theLastV};}
		
		private long theTime = 0;
		private double theLastP = 0.0;
		private int theLastV = 0;
	}
	
	public String getSymbol() {
		return theSymbol; 
	}
	
	public String getTicker() {
		return theTicker;
	}

	// Fields
	public static int Time = 0;
	public static int LastP = 1;
	public static int LastV = 2;
	
	private String theSymbol;
	private String theTicker;
	private Data theLastUpdatedData = new Data();

}

package feed;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.BidiMap;
import org.apache.commons.collections.bidimap.DualHashBidiMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

import product.ProductManager;
import sound.SoundDrive;
import util.ConfigManager;
import util.MySqlHelper;
import util.TimeConv;

import com.ib.client.Contract;
import com.ib.client.EClientSocket;
import com.ib.client.TickType;

import core.CoreWrapper;


public class FeedHandler extends CoreWrapper implements Runnable{
	
	
	public FeedHandler() {
	}
	
	public FeedHandler(String aHost, int aPort, int aClientId) {
		theHost = aHost;
		thePort = aPort;		
		theClientId = aClientId;
	}
	
	public void init() {
		init(InsertType.No);
	}
	
	public void init(InsertType aInsertType) {
		
		if (theIsLaunchingSoundOn) {
			SoundDrive mySD = new SoundDrive();
			mySD.setAudioFile("sounddrive/feed/FH_Launch.wav");
			new Thread(mySD).start();
		}
		theClient = super.connect(theHost, thePort, theClientId);
		
		theInsertType = aInsertType;
		switch (theInsertType) {
			case No:
				break;
			case Batch:
				theMySqlHelper = new MySqlHelper();
				break;
			case LoadCSV:
				theMySqlHelper = new MySqlHelper();
				initLoadByCSV("tempRS.csv", true);
				initLoadByCSV("tempLD.csv", false);
		}
			
	}
	
	public void reqRetailStateUpdate(Contract aContracts, FeedListener aFeedListener) {
		
		synchronized (this) {
			reqRetailStateUpdate(new Contract[] {aContracts}, aFeedListener);
		}
		
	}

	/**
	 * FeedHandler only request unique contracts (or symbols) for all FeedListener
	 * That is the reason why I need to have map for Symbol to FeedHandlerTickerId
	 * Then, FeedHandlerTickerId to FeedLister, so that they can only subscribe to the
	 * feed they were wishing for
	 * 
	 * @param aContracts
	 * @param aFeedListener
	 */
	public void reqRetailStateUpdate(Contract[] aContracts, FeedListener aFeedListener) {
		
		synchronized (this) {
			for (Contract myContract : aContracts) {
				String mySymbol = ProductManager.getSymbolByContract(myContract);
				// New contract so add to theContractToFeedId map
				if (!theSymbolToFeedId.containsKey(mySymbol)) {
					int myFeedId = theRetailStates.size(); // This allows feedId to start from 0
					theSymbolToFeedId.put(mySymbol, myFeedId);
					theRetailStates.add(new RetailState(mySymbol));
					theLastDones.add(new LastDone(mySymbol));
					theClient.reqMktData(myFeedId, myContract, "233", false);

					// Map new feedId to theFeedIdToFeedListeners
					List<FeedListener> myListeners = new ArrayList<FeedListener>();
					myListeners.add(aFeedListener);
					theFeedIdToFeedListeners.put(myFeedId, myListeners);
				}
				else { // Already myContract is subscribed by FeedHandler
					int myExistingFeedId = (Integer) theSymbolToFeedId.get(mySymbol);

					// Add FeedListener to the already existing map
					List<FeedListener> myListeners = theFeedIdToFeedListeners.get(myExistingFeedId);
					myListeners.add(aFeedListener);
					theFeedIdToFeedListeners.put(myExistingFeedId, myListeners);
				}
			}
			
			theLogger.info("New feed listerner ({}) is added", aFeedListener.toString());
			this.notify();
		}
		
	}

	@Override
	public void run() {
		
		synchronized(this) {
			theStatus = Status.Running;

			while (theStatus != Status.Done && theStatus != Status.Error) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			if (theStatus == Status.Done || theStatus == Status.Error) {
				theLogger.info("Feed handler is close");
				
				if (theInsertType == InsertType.Batch) {
					// Bach insert what is left over
					theMySqlHelper.insertTickRetailState(null, null, 0, true);
					theMySqlHelper.insertTickLastDone(null, null, 0, true);
				} else if (theInsertType == InsertType.LoadCSV) {
					if (theRSBufferedWriter != null) {
						try {
							theRSBufferedWriter.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
						theLogger.info("Loading retail state into table");
						theMySqlHelper.loadCSVToTable("tempRS.csv", MySqlHelper.TickRSTable, true, false);
					}
					
					if (theLDBufferedWriter != null) {
						try {
							theLDBufferedWriter.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
						theLogger.info("Loading last dones into table");
						theMySqlHelper.loadCSVToTable("tempLD.csv", MySqlHelper.TickLDTable, true, false);
					}
				}
				super.disconnect(theClientId);
			}
			
		}
	}
	
	public void setStatus(Status aStatus) {
		synchronized(this) {
			theStatus = aStatus;
			this.notify();
		}
	}
	
	/**
	 * tickPrice event is always followed by tickSize event
	 * So, I don't update based on tickPrice event
	 * E.g. (10) 100.00 @ 100.01 (20) --> (500) 99.99 @ 100.01 (20)
	 * IB event may generate two events as follows
	 * 99.99 (tickPrice) then 500 (tickSize)
	 * You should only update when there is update in tickSize for retail state update
	 * Lastdone is different
	 */
	public void tickPrice(int aFeedId, int field, double price,
			int canAutoExecute) {
		
		synchronized (this) {
			
			if (theStatus == Status.Running) {
				if (field == TickType.BID) {
					theRetailStates.get(aFeedId).update(System.currentTimeMillis(), price, 0, 0.0, 0);
					RetailState.Data myData = theRetailStates.get(aFeedId).getLastUpdatedData();
					if (myData.isValid()) {
						theLogger.debug("FeedHandler [{}] {} [BidP]",
								aFeedId, Arrays.toString(theRetailStates.get(aFeedId).getLastUpdatedData().getTick()));
					}
				} else if (field == TickType.ASK) {
					theRetailStates.get(aFeedId).update(System.currentTimeMillis(), 0.0, 0, price, 0);
					RetailState.Data myData = theRetailStates.get(aFeedId).getLastUpdatedData();
					if (myData.isValid()) {
						theLogger.debug("FeedHandler [{}] {} [AskP]",
								aFeedId, Arrays.toString(theRetailStates.get(aFeedId).getLastUpdatedData().getTick()));
					}
				} 
			}
		}
	}

	public void tickSize(int aFeedId, int field, int size) {
		
		synchronized (this) {
			
			if (theStatus == Status.Running) {
				if (field == TickType.BID_SIZE) {
					boolean myIsUpdated = theRetailStates.get(aFeedId).update(System.currentTimeMillis(), 0.0, size, 0.0, 0);
					RetailState.Data myData = theRetailStates.get(aFeedId).getLastUpdatedData();
					if (myData.isValid() && myIsUpdated) {
						publishRetailStateUpdate(aFeedId, myData);
						theLogger.debug("FeedHandler [{}] {} [BidV]", aFeedId, Arrays.toString(myData.getTick()));
					}
				} else if (field == TickType.ASK_SIZE) {
					boolean myIsUpdated = theRetailStates.get(aFeedId).update(System.currentTimeMillis(), 0, 0, 0, size);
					RetailState.Data myData = theRetailStates.get(aFeedId).getLastUpdatedData();
					if (myData.isValid() && myIsUpdated) {
						publishRetailStateUpdate(aFeedId, myData);
						theLogger.debug("FeedHandler [{}] {} [AskV]", aFeedId, Arrays.toString(myData.getTick()));
					}
				} 
			}
		}
	}
	
	@Override
	public void tickString(int aFeedId, int tickType, String value) {
		if (theStatus == Status.Running) {
			if (tickType ==TickType.RT_VOLUME) { // RTVolume
				if (value.startsWith(";")) { // odd lot trading
					return;
				}
				String[] mySplit = value.split(";");
				theLastDones.get(aFeedId).update(System.currentTimeMillis(),
						Double.valueOf(mySplit[0]), Integer.valueOf(mySplit[1]));
				LastDone.Data myData = theLastDones.get(aFeedId).getLastUpdatedData();
				
				publishLastDoneUpdate(aFeedId, myData);
				theLogger.debug("FeedHandler [{}] {} [Last]", aFeedId, Arrays.toString(myData.getTick()));
			}			
		}
	}
	
	private void publishRetailStateUpdate(int aFeedId, RetailState.Data aRS) {
		
		synchronized(this) {
			
			String mySymbol = theRetailStates.get(aFeedId).getSymbol();
			
			// Check which FeedLister to publish
			List<FeedListener> myListeners = theFeedIdToFeedListeners.get(aFeedId);
			for (FeedListener myFeedListener : myListeners) {
				myFeedListener.newRetailState(mySymbol, aRS);
			}
			
			if (theInsertType == InsertType.Batch) {
				theTickRSBatchCount ++;
				if (theTickRSBatchCount % theInsertBatchSize == 0)
					theMySqlHelper.insertTickRetailState(mySymbol, aRS, aFeedId, true);
				else
					theMySqlHelper.insertTickRetailState(mySymbol, aRS, aFeedId, false);
			} else if (theInsertType == InsertType.LoadCSV) {
				long myTime = aRS.getTime();
				double[] myTimeArray = TimeConv.UnixT.toDateArray(myTime);
				StringBuilder mySB = new StringBuilder();
				mySB.append(mySymbol + ",");				// Symbol
				mySB.append(myTime + ",");					// Timestamp
				mySB.append(myTimeArray[0] + ",");			// Date
				mySB.append(myTimeArray[1] + ",");			// Time
				mySB.append(aRS.getBidP() + ",");			// Bid price
				mySB.append(aRS.getBidV() + ",");			// Bid volume
				mySB.append(aRS.getAskP() + ",");			// Ask price
				mySB.append(aRS.getAskV() + ",");			// Ask volume
				mySB.append(aFeedId + "\n");				// Feed id
				
				try {
					theRSBufferedWriter.write(mySB.toString());
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
	}
	
	private void publishLastDoneUpdate(int aFeedId, LastDone.Data aLD) {
		
		synchronized(this) {
			
			String mySymbol = theLastDones.get(aFeedId).getSymbol();

			// Check which FeedLister to publish
			List<FeedListener> myListeners = theFeedIdToFeedListeners.get(aFeedId);
			for (FeedListener myFeedListener : myListeners) {
				myFeedListener.newLastDone(mySymbol, aLD);
			}
			
			if (theInsertType == InsertType.Batch) {
				theTickLDBatchCount ++;
				if (theTickLDBatchCount % theInsertBatchSize == 0)
					theMySqlHelper.insertTickLastDone(mySymbol, aLD, aFeedId, true);
				else
					theMySqlHelper.insertTickLastDone(mySymbol, aLD, aFeedId, false);
			} else if (theInsertType == InsertType.LoadCSV) {
				long myTime = aLD.getTime();
				double[] myTimeArray = TimeConv.UnixT.toDateArray(myTime);
				StringBuilder mySB = new StringBuilder();
				mySB.append(mySymbol + ",");				// Symbol
				mySB.append(myTime + ",");					// Timestamp
				mySB.append(myTimeArray[0] + ",");			// Date
				mySB.append(myTimeArray[1] + ",");			// Time
				mySB.append(aLD.getLastP() + ",");			// Last price
				mySB.append(aLD.getLastV() + ",");			// Last volume
				mySB.append(aFeedId + "\n");				// FeedId
				
				try {
					theLDBufferedWriter.write(mySB.toString());
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	private void initLoadByCSV(String aFileName, boolean aIsRS) {
		try {
			File myFile =new File(aFileName);
			if(! myFile.exists()) {
				myFile.createNewFile();
			}
			if (aIsRS)
				theRSBufferedWriter = new BufferedWriter(new FileWriter(myFile.getName(), true));
			else
				theLDBufferedWriter = new BufferedWriter(new FileWriter(myFile.getName(), true));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
	// Fields
	public EClientSocket theClient;
	public enum Status {Init, Running, Done, Error};
	public Status theStatus = Status.Init;
	public enum InsertType {No, Batch, LoadCSV};
	public InsertType theInsertType = InsertType.No;
	
	protected MySqlHelper theMySqlHelper = null;
	BufferedWriter theRSBufferedWriter = null;
	BufferedWriter theLDBufferedWriter = null;
	
	private String theHost = ConfigManager.parseConfig(getClass(), "host", "127.0.0.1");
	private int thePort = ConfigManager.parseConfig(getClass(), "port", 7496);
	private int theClientId = ConfigManager.parseConfig(getClass(), "clientid", 100);
	public Logger theLogger = (Logger) LogManager.getLogger(getClass().getName());
	
	private boolean theIsLaunchingSoundOn = 
			ConfigManager.parseConfig(FeedHandler.class, "launchingSoundOn", true);
	
	protected BidiMap theSymbolToFeedId = new DualHashBidiMap();
	protected Map <Integer, List<FeedListener>> theFeedIdToFeedListeners = new HashMap<Integer, List<FeedListener>>();
	
	protected List<RetailState> theRetailStates = new ArrayList<RetailState> ();
	protected List<LastDone> theLastDones = new ArrayList<LastDone> ();
	
	private int theTickRSBatchCount = 0;
	private int theTickLDBatchCount = 0;
	private int theInsertBatchSize = ConfigManager.parseConfig(MySqlHelper.class, "insertBatchSize", 300);
}
